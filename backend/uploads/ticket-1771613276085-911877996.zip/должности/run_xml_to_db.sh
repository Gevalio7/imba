#!/bin/bash
# Скрипт запуска XmlToDbProcessor для загрузки данных из XML в базу данных

JAR_FILE="XmlToDbProcessor-1.0.0-20250603102613-all.jar"

# Проверка наличия Java
if ! command -v java &> /dev/null; then
    echo "Ошибка: Java не установлена. Установите JRE:"
    echo "  sudo apt install openjdk-17-jre-headless"
    exit 1
fi

# Проверка наличия JAR файла
if [ ! -f "$JAR_FILE" ]; then
    echo "Ошибка: Файл $JAR_FILE не найден"
    exit 1
fi

echo "Запуск XmlToDbProcessor..."
java -jar "$JAR_FILE"

# Код завершения
EXIT_CODE=$?
if [ $EXIT_CODE -eq 0 ]; then
    echo "Завершено успешно"
else
    echo "Ошибка выполнения. Код завершения: $EXIT_CODE"
fi

exit $EXIT_CODE
