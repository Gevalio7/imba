--
-- PostgreSQL database dump
--

\restrict iiWSqwVoThpj2zjxiaKAI9creY5L0J6NRQ7sMPWsSWKp5vDMLQkUfY2fYGhVUAW

-- Dumped from database version 18.3 (Ubuntu 18.3-1.pgdg22.04+1)
-- Dumped by pg_dump version 18.3 (Ubuntu 18.3-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_acl_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_acl_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_acl_updated_at() OWNER TO postgres;

--
-- Name: update_acls_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_acls_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_acls_updated_at() OWNER TO postgres;

--
-- Name: update_admin_notification_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_admin_notification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_admin_notification_updated_at() OWNER TO postgres;

--
-- Name: update_admin_notifications_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_admin_notifications_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_admin_notifications_updated_at() OWNER TO postgres;

--
-- Name: update_agents_groups_agents_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agents_groups_agents_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agents_groups_agents_updated_at() OWNER TO postgres;

--
-- Name: update_agents_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agents_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agents_groups_updated_at() OWNER TO postgres;

--
-- Name: update_agents_roles_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agents_roles_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agents_roles_updated_at() OWNER TO postgres;

--
-- Name: update_agents_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agents_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agents_updated_at() OWNER TO postgres;

--
-- Name: update_appointment_notifications_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_appointment_notifications_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_appointment_notifications_updated_at() OWNER TO postgres;

--
-- Name: update_attachments_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_attachments_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_attachments_updated_at() OWNER TO postgres;

--
-- Name: update_auto_responses_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_auto_responses_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_auto_responses_updated_at() OWNER TO postgres;

--
-- Name: update_calendar_events_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_calendar_events_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_calendar_events_updated_at() OWNER TO postgres;

--
-- Name: update_calendars_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_calendars_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_calendars_updated_at() OWNER TO postgres;

--
-- Name: update_communication_log_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_communication_log_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_communication_log_updated_at() OWNER TO postgres;

--
-- Name: update_communication_notifications_settings_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_communication_notifications_settings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_communication_notifications_settings_updated_at() OWNER TO postgres;

--
-- Name: update_customer_users_customers_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customer_users_customers_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_users_customers_updated_at() OWNER TO postgres;

--
-- Name: update_customer_users_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customer_users_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_users_groups_updated_at() OWNER TO postgres;

--
-- Name: update_customer_users_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customer_users_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_users_services_updated_at() OWNER TO postgres;

--
-- Name: update_customer_users_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customer_users_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_users_updated_at() OWNER TO postgres;

--
-- Name: update_customers_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customers_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customers_groups_updated_at() OWNER TO postgres;

--
-- Name: update_customers_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customers_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customers_services_updated_at() OWNER TO postgres;

--
-- Name: update_customers_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customers_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customers_updated_at() OWNER TO postgres;

--
-- Name: update_dynamic_fields_screens_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_dynamic_fields_screens_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_dynamic_fields_screens_updated_at() OWNER TO postgres;

--
-- Name: update_dynamic_fields_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_dynamic_fields_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_dynamic_fields_updated_at() OWNER TO postgres;

--
-- Name: update_email_addresses_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_email_addresses_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_email_addresses_updated_at() OWNER TO postgres;

--
-- Name: update_general_catalog_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_general_catalog_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_general_catalog_updated_at() OWNER TO postgres;

--
-- Name: update_generic_agent_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_generic_agent_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_generic_agent_updated_at() OWNER TO postgres;

--
-- Name: update_greetings_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_greetings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_greetings_updated_at() OWNER TO postgres;

--
-- Name: update_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_groups_updated_at() OWNER TO postgres;

--
-- Name: update_oauth2_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_oauth2_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_oauth2_updated_at() OWNER TO postgres;

--
-- Name: update_package_manager_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_package_manager_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_package_manager_updated_at() OWNER TO postgres;

--
-- Name: update_performance_log_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_performance_log_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_performance_log_updated_at() OWNER TO postgres;

--
-- Name: update_pgp_keys_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_pgp_keys_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_pgp_keys_updated_at() OWNER TO postgres;

--
-- Name: update_post_master_filters_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_post_master_filters_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_post_master_filters_updated_at() OWNER TO postgres;

--
-- Name: update_post_master_mail_accounts_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_post_master_mail_accounts_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_post_master_mail_accounts_updated_at() OWNER TO postgres;

--
-- Name: update_priorities_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_priorities_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_priorities_updated_at() OWNER TO postgres;

--
-- Name: update_process_management_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_process_management_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_process_management_updated_at() OWNER TO postgres;

--
-- Name: update_processes_automation_settings_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_processes_automation_settings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_processes_automation_settings_updated_at() OWNER TO postgres;

--
-- Name: update_queue_auto_response_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_queue_auto_response_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_queue_auto_response_updated_at() OWNER TO postgres;

--
-- Name: update_queues_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_queues_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_queues_updated_at() OWNER TO postgres;

--
-- Name: update_roles_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_roles_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_roles_groups_updated_at() OWNER TO postgres;

--
-- Name: update_roles_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_roles_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_roles_updated_at() OWNER TO postgres;

--
-- Name: update_services_attachments_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_services_attachments_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_services_attachments_updated_at() OWNER TO postgres;

--
-- Name: update_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_services_updated_at() OWNER TO postgres;

--
-- Name: update_session_management_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_session_management_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_session_management_updated_at() OWNER TO postgres;

--
-- Name: update_signatures_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_signatures_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_signatures_updated_at() OWNER TO postgres;

--
-- Name: update_sla_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_sla_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_sla_services_updated_at() OWNER TO postgres;

--
-- Name: update_sla_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_sla_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_sla_updated_at() OWNER TO postgres;

--
-- Name: update_smime_certificates_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_smime_certificates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_smime_certificates_updated_at() OWNER TO postgres;

--
-- Name: update_sql_box_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_sql_box_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_sql_box_updated_at() OWNER TO postgres;

--
-- Name: update_states_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_states_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_states_updated_at() OWNER TO postgres;

--
-- Name: update_support_data_collector_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_support_data_collector_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_support_data_collector_updated_at() OWNER TO postgres;

--
-- Name: update_system_configuration_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_system_configuration_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_system_configuration_updated_at() OWNER TO postgres;

--
-- Name: update_system_file_support_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_system_file_support_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_system_file_support_updated_at() OWNER TO postgres;

--
-- Name: update_system_log_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_system_log_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_system_log_updated_at() OWNER TO postgres;

--
-- Name: update_system_maintenance_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_system_maintenance_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_system_maintenance_updated_at() OWNER TO postgres;

--
-- Name: update_template_attachments_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_template_attachments_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_template_attachments_updated_at() OWNER TO postgres;

--
-- Name: update_template_queues_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_template_queues_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_template_queues_updated_at() OWNER TO postgres;

--
-- Name: update_templates_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_templates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_templates_updated_at() OWNER TO postgres;

--
-- Name: update_test_entities_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_test_entities_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_test_entities_updated_at() OWNER TO postgres;

--
-- Name: update_ticket_attribute_relations_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_ticket_attribute_relations_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_ticket_attribute_relations_updated_at() OWNER TO postgres;

--
-- Name: update_ticket_notifications_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_ticket_notifications_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_ticket_notifications_updated_at() OWNER TO postgres;

--
-- Name: update_ticket_schedules_timestamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_ticket_schedules_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_ticket_schedules_timestamp() OWNER TO postgres;

--
-- Name: update_translation_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_translation_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_translation_updated_at() OWNER TO postgres;

--
-- Name: update_type_categories_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_type_categories_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_type_categories_updated_at() OWNER TO postgres;

--
-- Name: update_types_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_types_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_types_updated_at() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- Name: update_users_groups_roles_settings_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_users_groups_roles_settings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_users_groups_roles_settings_updated_at() OWNER TO postgres;

--
-- Name: update_web_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_web_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_web_services_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acl (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    permissions text[],
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.acl OWNER TO postgres;

--
-- Name: acl_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.acl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.acl_id_seq OWNER TO postgres;

--
-- Name: acl_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.acl_id_seq OWNED BY public.acl.id;


--
-- Name: acls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acls (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.acls OWNER TO postgres;

--
-- Name: acls_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.acls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.acls_id_seq OWNER TO postgres;

--
-- Name: acls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.acls_id_seq OWNED BY public.acls.id;


--
-- Name: admin_notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_notification (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admin_notification OWNER TO postgres;

--
-- Name: admin_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_notification_id_seq OWNER TO postgres;

--
-- Name: admin_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_notification_id_seq OWNED BY public.admin_notification.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    login character varying(100) NOT NULL,
    password text NOT NULL,
    email character varying(255),
    mobile_phone character varying(50),
    telegram_account character varying(100),
    avatar text,
    is_active boolean DEFAULT true,
    role_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents OWNER TO postgres;

--
-- Name: agents_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    role_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents_groups OWNER TO postgres;

--
-- Name: agents_groups_agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_groups_agents (
    agents_group_id integer NOT NULL,
    agent_id integer NOT NULL
);


ALTER TABLE public.agents_groups_agents OWNER TO postgres;

--
-- Name: agents_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_groups_id_seq OWNER TO postgres;

--
-- Name: agents_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_groups_id_seq OWNED BY public.agents_groups.id;


--
-- Name: agents_groups_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_groups_roles (
    agents_group_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.agents_groups_roles OWNER TO postgres;

--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_id_seq OWNER TO postgres;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: agents_queues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_queues (
    id integer NOT NULL,
    agent_id integer,
    queue_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents_queues OWNER TO postgres;

--
-- Name: agents_queues_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_queues_id_seq OWNER TO postgres;

--
-- Name: agents_queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_queues_id_seq OWNED BY public.agents_queues.id;


--
-- Name: agents_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_roles (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents_roles OWNER TO postgres;

--
-- Name: agents_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_roles_id_seq OWNER TO postgres;

--
-- Name: agents_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_roles_id_seq OWNED BY public.agents_roles.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    file_name character varying(255),
    type integer,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attachments OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachments_id_seq OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: auto_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auto_responses (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    trigger character varying(255),
    response text,
    delay integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.auto_responses OWNER TO postgres;

--
-- Name: auto_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auto_responses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auto_responses_id_seq OWNER TO postgres;

--
-- Name: auto_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auto_responses_id_seq OWNED BY public.auto_responses.id;


--
-- Name: calendars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calendars (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    timezone character varying(100) DEFAULT 'Europe/Moscow'::character varying,
    work_hours_from time without time zone DEFAULT '09:00:00'::time without time zone,
    work_hours_to time without time zone DEFAULT '18:00:00'::time without time zone,
    work_days_per_week integer DEFAULT 5,
    color character varying(7) DEFAULT '#3b82f6'::character varying,
    date_from date,
    date_to date,
    work_hours text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.calendars OWNER TO postgres;

--
-- Name: calendars_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calendars_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calendars_id_seq OWNER TO postgres;

--
-- Name: calendars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calendars_id_seq OWNED BY public.calendars.id;


--
-- Name: customer_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_users (
    id integer NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    login character varying(100) NOT NULL,
    password text NOT NULL,
    email character varying(255),
    mobile_phone character varying(50),
    telegram_account character varying(100),
    customer_id integer,
    customers_group_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_users OWNER TO postgres;

--
-- Name: customer_users_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_users_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_users_groups OWNER TO postgres;

--
-- Name: customer_users_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_users_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_users_groups_id_seq OWNER TO postgres;

--
-- Name: customer_users_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_users_groups_id_seq OWNED BY public.customer_users_groups.id;


--
-- Name: customer_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_users_id_seq OWNER TO postgres;

--
-- Name: customer_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_users_id_seq OWNED BY public.customer_users.id;


--
-- Name: customer_users_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_users_services (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_users_services OWNER TO postgres;

--
-- Name: customer_users_services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_users_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_users_services_id_seq OWNER TO postgres;

--
-- Name: customer_users_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_users_services_id_seq OWNED BY public.customer_users_services.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    street character varying(255),
    zip character varying(20),
    city character varying(255),
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    customer_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customers_groups OWNER TO postgres;

--
-- Name: customers_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_groups_id_seq OWNER TO postgres;

--
-- Name: customers_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_groups_id_seq OWNED BY public.customers_groups.id;


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: customers_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers_services (
    customer_id integer NOT NULL,
    service_id integer NOT NULL
);


ALTER TABLE public.customers_services OWNER TO postgres;

--
-- Name: dynamic_fields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamic_fields (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    label character varying(255),
    field_type character varying(255),
    default_value character varying(255),
    is_required boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dynamic_fields OWNER TO postgres;

--
-- Name: dynamic_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dynamic_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dynamic_fields_id_seq OWNER TO postgres;

--
-- Name: dynamic_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dynamic_fields_id_seq OWNED BY public.dynamic_fields.id;


--
-- Name: dynamic_fields_screens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamic_fields_screens (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    screen_name character varying(255),
    field_name character varying(255),
    field_type character varying(255),
    is_required boolean DEFAULT false,
    "position" integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dynamic_fields_screens OWNER TO postgres;

--
-- Name: dynamic_fields_screens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dynamic_fields_screens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dynamic_fields_screens_id_seq OWNER TO postgres;

--
-- Name: dynamic_fields_screens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dynamic_fields_screens_id_seq OWNED BY public.dynamic_fields_screens.id;


--
-- Name: dynamicfields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamicfields (
    id integer NOT NULL,
    name character varying(255),
    label character varying(255),
    fieldtype character varying(255),
    defaultvalue character varying(255),
    isrequired boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status integer DEFAULT 1,
    is_active boolean DEFAULT true
);


ALTER TABLE public.dynamicfields OWNER TO postgres;

--
-- Name: dynamicfields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dynamicfields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dynamicfields_id_seq OWNER TO postgres;

--
-- Name: dynamicfields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dynamicfields_id_seq OWNED BY public.dynamicfields.id;


--
-- Name: email_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_addresses (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    queue_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.email_addresses OWNER TO postgres;

--
-- Name: email_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_addresses_id_seq OWNER TO postgres;

--
-- Name: email_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_addresses_id_seq OWNED BY public.email_addresses.id;


--
-- Name: generic_agent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generic_agent (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    trigger_type character varying(255),
    schedule character varying(255),
    last_run character varying(255),
    next_run character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.generic_agent OWNER TO postgres;

--
-- Name: generic_agent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.generic_agent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.generic_agent_id_seq OWNER TO postgres;

--
-- Name: generic_agent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.generic_agent_id_seq OWNED BY public.generic_agent.id;


--
-- Name: greetings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.greetings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content text,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.greetings OWNER TO postgres;

--
-- Name: greetings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.greetings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.greetings_id_seq OWNER TO postgres;

--
-- Name: greetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.greetings_id_seq OWNED BY public.greetings.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.groups_id_seq OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: knowledge_base; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knowledge_base (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    content text,
    category_id integer,
    tags text[],
    service_id integer,
    is_published boolean DEFAULT false,
    views_count integer DEFAULT 0,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.knowledge_base OWNER TO postgres;

--
-- Name: knowledge_base_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knowledge_base_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_base_id_seq OWNER TO postgres;

--
-- Name: knowledge_base_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knowledge_base_id_seq OWNED BY public.knowledge_base.id;


--
-- Name: mail_fetch_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mail_fetch_logs (
    id integer NOT NULL,
    account_id integer,
    status character varying(50),
    message text,
    fetched_count integer DEFAULT 0,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mail_fetch_logs OWNER TO postgres;

--
-- Name: mail_fetch_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mail_fetch_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mail_fetch_logs_id_seq OWNER TO postgres;

--
-- Name: mail_fetch_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mail_fetch_logs_id_seq OWNED BY public.mail_fetch_logs.id;


--
-- Name: oauth2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth2 (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    client_id character varying(255),
    client_secret character varying(255),
    authorization_url character varying(255),
    token_url character varying(255),
    scopes text[],
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.oauth2 OWNER TO postgres;

--
-- Name: oauth2_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.oauth2_id_seq OWNER TO postgres;

--
-- Name: oauth2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth2_id_seq OWNED BY public.oauth2.id;


--
-- Name: package_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.package_manager (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    version character varying(255),
    author character varying(255),
    is_installed boolean DEFAULT false,
    is_upgradable boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.package_manager OWNER TO postgres;

--
-- Name: package_manager_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.package_manager_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.package_manager_id_seq OWNER TO postgres;

--
-- Name: package_manager_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.package_manager_id_seq OWNED BY public.package_manager.id;


--
-- Name: performance_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.performance_log (
    id integer NOT NULL,
    name character varying(255),
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.performance_log OWNER TO postgres;

--
-- Name: performance_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.performance_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.performance_log_id_seq OWNER TO postgres;

--
-- Name: performance_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.performance_log_id_seq OWNED BY public.performance_log.id;


--
-- Name: pgp_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pgp_keys (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pgp_keys OWNER TO postgres;

--
-- Name: pgp_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pgp_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pgp_keys_id_seq OWNER TO postgres;

--
-- Name: pgp_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pgp_keys_id_seq OWNED BY public.pgp_keys.id;


--
-- Name: post_master_filters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post_master_filters (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.post_master_filters OWNER TO postgres;

--
-- Name: post_master_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_master_filters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.post_master_filters_id_seq OWNER TO postgres;

--
-- Name: post_master_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.post_master_filters_id_seq OWNED BY public.post_master_filters.id;


--
-- Name: post_master_mail_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post_master_mail_accounts (
    id integer NOT NULL,
    name character varying(255),
    type character varying(20) DEFAULT 'IMAP'::character varying NOT NULL,
    authentication_type character varying(50) DEFAULT 'password'::character varying NOT NULL,
    login character varying(255) DEFAULT ''::character varying NOT NULL,
    password character varying(500),
    host character varying(255) DEFAULT ''::character varying NOT NULL,
    port integer DEFAULT 993,
    protocol character varying(50) DEFAULT 'imap'::character varying,
    imap_folder character varying(255) DEFAULT 'INBOX'::character varying,
    trusted boolean DEFAULT false NOT NULL,
    dispatching_by character varying(20) DEFAULT 'Queue'::character varying NOT NULL,
    queue_id integer,
    comment text,
    oauth2_token_config_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.post_master_mail_accounts OWNER TO postgres;

--
-- Name: post_master_mail_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_master_mail_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.post_master_mail_accounts_id_seq OWNER TO postgres;

--
-- Name: post_master_mail_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.post_master_mail_accounts_id_seq OWNED BY public.post_master_mail_accounts.id;


--
-- Name: priorities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.priorities (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(7) DEFAULT '#808080'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.priorities OWNER TO postgres;

--
-- Name: priorities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.priorities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.priorities_id_seq OWNER TO postgres;

--
-- Name: priorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.priorities_id_seq OWNED BY public.priorities.id;


--
-- Name: queue_auto_response; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.queue_auto_response (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.queue_auto_response OWNER TO postgres;

--
-- Name: queue_auto_response_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.queue_auto_response_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.queue_auto_response_id_seq OWNER TO postgres;

--
-- Name: queue_auto_response_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.queue_auto_response_id_seq OWNED BY public.queue_auto_response.id;


--
-- Name: queues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.queues (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    company_id integer,
    department_id integer,
    service_id integer,
    sla_id integer,
    workflow_id integer,
    priority_id integer,
    executor_group_ids integer[],
    executor_agent_ids integer[],
    observer_group_ids integer[],
    observer_agent_ids integer[],
    approver_group_ids integer[],
    approver_agent_ids integer[],
    keywords text[],
    quick_answer_article_ids integer[],
    type_id integer,
    category_id integer,
    post_master_mail_account_id integer,
    template_open_ticket_id integer,
    template_close_ticket_id integer,
    template_confirm_ticket_id integer,
    template_status_change_id integer,
    template_comment_ticket_id integer,
    template_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.queues OWNER TO postgres;

--
-- Name: queues_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.queues_id_seq OWNER TO postgres;

--
-- Name: queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.queues_id_seq OWNED BY public.queues.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    role_id integer NOT NULL,
    permission character varying(255) NOT NULL,
    is_granted boolean DEFAULT true,
    level integer DEFAULT 444,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_permissions_id_seq OWNER TO postgres;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    icon character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles_groups OWNER TO postgres;

--
-- Name: roles_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_groups_id_seq OWNER TO postgres;

--
-- Name: roles_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_groups_id_seq OWNED BY public.roles_groups.id;


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: service_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_attachments (
    id integer NOT NULL,
    service_id integer NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer,
    mime_type character varying(255),
    uploaded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.service_attachments OWNER TO postgres;

--
-- Name: service_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_attachments_id_seq OWNER TO postgres;

--
-- Name: service_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_attachments_id_seq OWNED BY public.service_attachments.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    type character varying(50),
    sla_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services_attachments (
    id integer NOT NULL,
    service_id integer NOT NULL,
    attachment_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.services_attachments OWNER TO postgres;

--
-- Name: services_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_attachments_id_seq OWNER TO postgres;

--
-- Name: services_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_attachments_id_seq OWNED BY public.services_attachments.id;


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: session_management; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session_management (
    id integer NOT NULL,
    username character varying(255),
    ip_address character varying(100),
    user_agent text,
    login_time timestamp without time zone,
    last_activity timestamp without time zone,
    is_active boolean DEFAULT true,
    type character varying(20),
    user_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.session_management OWNER TO postgres;

--
-- Name: session_management_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.session_management_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.session_management_id_seq OWNER TO postgres;

--
-- Name: session_management_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.session_management_id_seq OWNED BY public.session_management.id;


--
-- Name: signatures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.signatures (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content text,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.signatures OWNER TO postgres;

--
-- Name: signatures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.signatures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.signatures_id_seq OWNER TO postgres;

--
-- Name: signatures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.signatures_id_seq OWNED BY public.signatures.id;


--
-- Name: sla; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sla (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    response_time numeric(10,2),
    resolution_time numeric(10,2),
    notification_percentage integer DEFAULT 80,
    type character varying(50),
    solution_time numeric(10,2),
    min_incident_time numeric(10,2),
    response_notification boolean DEFAULT true,
    update_notification boolean DEFAULT true,
    solution_notification boolean DEFAULT true,
    calendar_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sla OWNER TO postgres;

--
-- Name: sla_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sla_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sla_id_seq OWNER TO postgres;

--
-- Name: sla_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sla_id_seq OWNED BY public.sla.id;


--
-- Name: sla_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sla_services (
    id integer NOT NULL,
    sla_id integer NOT NULL,
    service_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sla_services OWNER TO postgres;

--
-- Name: sla_services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sla_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sla_services_id_seq OWNER TO postgres;

--
-- Name: sla_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sla_services_id_seq OWNED BY public.sla_services.id;


--
-- Name: smime_certificates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.smime_certificates (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.smime_certificates OWNER TO postgres;

--
-- Name: smime_certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.smime_certificates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.smime_certificates_id_seq OWNER TO postgres;

--
-- Name: smime_certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.smime_certificates_id_seq OWNED BY public.smime_certificates.id;


--
-- Name: sql_box; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sql_box (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sql_box OWNER TO postgres;

--
-- Name: sql_box_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sql_box_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sql_box_id_seq OWNER TO postgres;

--
-- Name: sql_box_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sql_box_id_seq OWNED BY public.sql_box.id;


--
-- Name: state_transitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.state_transitions (
    id integer NOT NULL,
    type_id integer,
    from_state_id integer,
    to_state_id integer NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    sort_order integer DEFAULT 0
);


ALTER TABLE public.state_transitions OWNER TO postgres;

--
-- Name: TABLE state_transitions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.state_transitions IS 'Переходы между статусами (workflow) привязанные к типу инцидента';


--
-- Name: COLUMN state_transitions.type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.type_id IS 'Тип инцидента (NULL = общие переходы)';


--
-- Name: COLUMN state_transitions.from_state_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.from_state_id IS 'Исходный статус (NULL = начальный статус)';


--
-- Name: COLUMN state_transitions.to_state_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.to_state_id IS 'Целевой статус';


--
-- Name: COLUMN state_transitions.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.name IS 'Название перехода';


--
-- Name: state_transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.state_transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.state_transitions_id_seq OWNER TO postgres;

--
-- Name: state_transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.state_transitions_id_seq OWNED BY public.state_transitions.id;


--
-- Name: states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.states (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    type character varying(50),
    color character varying(7) DEFAULT '#808080'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.states OWNER TO postgres;

--
-- Name: states_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.states_id_seq OWNER TO postgres;

--
-- Name: states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.states_id_seq OWNED BY public.states.id;


--
-- Name: system_configuration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_configuration (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    value text,
    config_type character varying(50),
    is_editable boolean DEFAULT true,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_configuration OWNER TO postgres;

--
-- Name: system_configuration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_configuration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_configuration_id_seq OWNER TO postgres;

--
-- Name: system_configuration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_configuration_id_seq OWNED BY public.system_configuration.id;


--
-- Name: system_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_log (
    id integer NOT NULL,
    name character varying(255),
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_log OWNER TO postgres;

--
-- Name: system_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_log_id_seq OWNER TO postgres;

--
-- Name: system_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_log_id_seq OWNED BY public.system_log.id;


--
-- Name: system_maintenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_maintenance (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    start_time character varying(255),
    end_time character varying(255),
    is_scheduled boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_maintenance OWNER TO postgres;

--
-- Name: system_maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_maintenance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_maintenance_id_seq OWNER TO postgres;

--
-- Name: system_maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_maintenance_id_seq OWNED BY public.system_maintenance.id;


--
-- Name: template_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.template_attachments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.template_attachments OWNER TO postgres;

--
-- Name: template_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.template_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.template_attachments_id_seq OWNER TO postgres;

--
-- Name: template_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.template_attachments_id_seq OWNED BY public.template_attachments.id;


--
-- Name: template_queues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.template_queues (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.template_queues OWNER TO postgres;

--
-- Name: template_queues_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.template_queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.template_queues_id_seq OWNER TO postgres;

--
-- Name: template_queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.template_queues_id_seq OWNED BY public.template_queues.id;


--
-- Name: templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.templates (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.templates OWNER TO postgres;

--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.templates_id_seq OWNER TO postgres;

--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- Name: test_entities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_entities (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.test_entities OWNER TO postgres;

--
-- Name: test_entities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_entities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_entities_id_seq OWNER TO postgres;

--
-- Name: test_entities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_entities_id_seq OWNED BY public.test_entities.id;


--
-- Name: ticket_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_attachments (
    id integer NOT NULL,
    ticket_id integer,
    attachment_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_attachments OWNER TO postgres;

--
-- Name: ticket_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_attachments_id_seq OWNER TO postgres;

--
-- Name: ticket_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_attachments_id_seq OWNED BY public.ticket_attachments.id;


--
-- Name: ticket_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_comments (
    id integer NOT NULL,
    ticket_id integer,
    content text NOT NULL,
    author_id integer,
    is_internal boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_comments OWNER TO postgres;

--
-- Name: ticket_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_comments_id_seq OWNER TO postgres;

--
-- Name: ticket_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_comments_id_seq OWNED BY public.ticket_comments.id;


--
-- Name: ticket_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_history (
    id integer NOT NULL,
    ticket_id integer,
    changed_by integer,
    field_name character varying(100),
    old_value text,
    new_value text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_history OWNER TO postgres;

--
-- Name: ticket_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_history_id_seq OWNER TO postgres;

--
-- Name: ticket_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_history_id_seq OWNED BY public.ticket_history.id;


--
-- Name: ticket_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_notifications (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_notifications OWNER TO postgres;

--
-- Name: ticket_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_notifications_id_seq OWNER TO postgres;

--
-- Name: ticket_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_notifications_id_seq OWNED BY public.ticket_notifications.id;


--
-- Name: ticket_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_number_seq
    START WITH 1000001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_number_seq OWNER TO postgres;

--
-- Name: ticket_schedule_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_schedule_logs (
    id integer NOT NULL,
    schedule_id integer,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_ticket_id integer,
    created_ticket_number character varying(20),
    status character varying(20) DEFAULT 'success'::character varying,
    error_message text,
    details jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_schedule_logs OWNER TO postgres;

--
-- Name: ticket_schedule_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_schedule_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_schedule_logs_id_seq OWNER TO postgres;

--
-- Name: ticket_schedule_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_schedule_logs_id_seq OWNED BY public.ticket_schedule_logs.id;


--
-- Name: ticket_schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_schedules (
    id integer NOT NULL,
    ticket_id integer,
    schedule_type character varying(20) DEFAULT 'daily'::character varying,
    schedule_time character varying(5) DEFAULT '09:00'::character varying,
    schedule_days integer[],
    schedule_day_of_month integer,
    start_date date,
    end_date date,
    is_active boolean DEFAULT true,
    last_run_at timestamp without time zone,
    next_run_at timestamp without time zone,
    title_prefix character varying(100) DEFAULT 'Расписание (Р) '::character varying,
    title character varying(500),
    description text,
    type_id integer,
    category_id integer,
    priority_id integer,
    queue_id integer,
    state_id integer,
    owner_id integer,
    executor_agent_ids integer[],
    executor_group_ids integer[],
    company_id integer,
    service_id integer,
    sla_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_schedules OWNER TO postgres;

--
-- Name: ticket_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_schedules_id_seq OWNER TO postgres;

--
-- Name: ticket_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_schedules_id_seq OWNED BY public.ticket_schedules.id;


--
-- Name: ticket_status_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_status_history (
    id integer NOT NULL,
    ticket_id integer,
    from_state_id integer,
    to_state_id integer,
    changed_by integer,
    time_in_previous_status interval,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_status_history OWNER TO postgres;

--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_status_history_id_seq OWNER TO postgres;

--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_status_history_id_seq OWNED BY public.ticket_status_history.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tickets (
    id integer NOT NULL,
    ticket_number character varying(20),
    title character varying(500) NOT NULL,
    description text,
    type_id integer,
    category_id integer,
    priority_id integer,
    queue_id integer,
    state_id integer,
    owner_id integer,
    executor_agent_ids integer[],
    executor_group_ids integer[],
    company_id integer,
    service_id integer,
    sla_id integer,
    response_deadline timestamp without time zone,
    resolution_deadline timestamp without time zone,
    first_response_at timestamp without time zone,
    sla_violated boolean DEFAULT false,
    pending_start_at timestamp without time zone,
    observer_agent_ids integer[],
    observer_group_ids integer[],
    escalation_count integer DEFAULT 0,
    is_escalated boolean DEFAULT false,
    created_by_schedule_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tickets OWNER TO postgres;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tickets_id_seq OWNER TO postgres;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: type_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type_categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    labor_hours numeric(10,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.type_categories OWNER TO postgres;

--
-- Name: type_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.type_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.type_categories_id_seq OWNER TO postgres;

--
-- Name: type_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.type_categories_id_seq OWNED BY public.type_categories.id;


--
-- Name: type_category_relations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type_category_relations (
    id integer NOT NULL,
    type_id integer NOT NULL,
    category_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.type_category_relations OWNER TO postgres;

--
-- Name: type_category_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.type_category_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.type_category_relations_id_seq OWNER TO postgres;

--
-- Name: type_category_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.type_category_relations_id_seq OWNED BY public.type_category_relations.id;


--
-- Name: types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    workflow_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.types OWNER TO postgres;

--
-- Name: types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.types_id_seq OWNER TO postgres;

--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.types_id_seq OWNED BY public.types.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login character varying(100) NOT NULL,
    password text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    email character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_groups_roles_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_groups_roles_settings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users_groups_roles_settings OWNER TO postgres;

--
-- Name: users_groups_roles_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_groups_roles_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_groups_roles_settings_id_seq OWNER TO postgres;

--
-- Name: users_groups_roles_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_groups_roles_settings_id_seq OWNED BY public.users_groups_roles_settings.id;


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.workflows OWNER TO postgres;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO postgres;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: acl id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acl ALTER COLUMN id SET DEFAULT nextval('public.acl_id_seq'::regclass);


--
-- Name: acls id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acls ALTER COLUMN id SET DEFAULT nextval('public.acls_id_seq'::regclass);


--
-- Name: admin_notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_notification ALTER COLUMN id SET DEFAULT nextval('public.admin_notification_id_seq'::regclass);


--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: agents_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups ALTER COLUMN id SET DEFAULT nextval('public.agents_groups_id_seq'::regclass);


--
-- Name: agents_queues id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_queues ALTER COLUMN id SET DEFAULT nextval('public.agents_queues_id_seq'::regclass);


--
-- Name: agents_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_roles ALTER COLUMN id SET DEFAULT nextval('public.agents_roles_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: auto_responses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auto_responses ALTER COLUMN id SET DEFAULT nextval('public.auto_responses_id_seq'::regclass);


--
-- Name: calendars id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendars ALTER COLUMN id SET DEFAULT nextval('public.calendars_id_seq'::regclass);


--
-- Name: customer_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users ALTER COLUMN id SET DEFAULT nextval('public.customer_users_id_seq'::regclass);


--
-- Name: customer_users_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_groups ALTER COLUMN id SET DEFAULT nextval('public.customer_users_groups_id_seq'::regclass);


--
-- Name: customer_users_services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_services ALTER COLUMN id SET DEFAULT nextval('public.customer_users_services_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: customers_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_groups ALTER COLUMN id SET DEFAULT nextval('public.customers_groups_id_seq'::regclass);


--
-- Name: dynamic_fields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_fields ALTER COLUMN id SET DEFAULT nextval('public.dynamic_fields_id_seq'::regclass);


--
-- Name: dynamic_fields_screens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_fields_screens ALTER COLUMN id SET DEFAULT nextval('public.dynamic_fields_screens_id_seq'::regclass);


--
-- Name: dynamicfields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamicfields ALTER COLUMN id SET DEFAULT nextval('public.dynamicfields_id_seq'::regclass);


--
-- Name: email_addresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_addresses ALTER COLUMN id SET DEFAULT nextval('public.email_addresses_id_seq'::regclass);


--
-- Name: generic_agent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generic_agent ALTER COLUMN id SET DEFAULT nextval('public.generic_agent_id_seq'::regclass);


--
-- Name: greetings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.greetings ALTER COLUMN id SET DEFAULT nextval('public.greetings_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: knowledge_base id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base ALTER COLUMN id SET DEFAULT nextval('public.knowledge_base_id_seq'::regclass);


--
-- Name: mail_fetch_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mail_fetch_logs ALTER COLUMN id SET DEFAULT nextval('public.mail_fetch_logs_id_seq'::regclass);


--
-- Name: oauth2 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth2 ALTER COLUMN id SET DEFAULT nextval('public.oauth2_id_seq'::regclass);


--
-- Name: package_manager id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package_manager ALTER COLUMN id SET DEFAULT nextval('public.package_manager_id_seq'::regclass);


--
-- Name: performance_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_log ALTER COLUMN id SET DEFAULT nextval('public.performance_log_id_seq'::regclass);


--
-- Name: pgp_keys id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pgp_keys ALTER COLUMN id SET DEFAULT nextval('public.pgp_keys_id_seq'::regclass);


--
-- Name: post_master_filters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_filters ALTER COLUMN id SET DEFAULT nextval('public.post_master_filters_id_seq'::regclass);


--
-- Name: post_master_mail_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_mail_accounts ALTER COLUMN id SET DEFAULT nextval('public.post_master_mail_accounts_id_seq'::regclass);


--
-- Name: priorities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities ALTER COLUMN id SET DEFAULT nextval('public.priorities_id_seq'::regclass);


--
-- Name: queue_auto_response id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queue_auto_response ALTER COLUMN id SET DEFAULT nextval('public.queue_auto_response_id_seq'::regclass);


--
-- Name: queues id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues ALTER COLUMN id SET DEFAULT nextval('public.queues_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: roles_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles_groups ALTER COLUMN id SET DEFAULT nextval('public.roles_groups_id_seq'::regclass);


--
-- Name: service_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_attachments ALTER COLUMN id SET DEFAULT nextval('public.service_attachments_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: services_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services_attachments ALTER COLUMN id SET DEFAULT nextval('public.services_attachments_id_seq'::regclass);


--
-- Name: session_management id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_management ALTER COLUMN id SET DEFAULT nextval('public.session_management_id_seq'::regclass);


--
-- Name: signatures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signatures ALTER COLUMN id SET DEFAULT nextval('public.signatures_id_seq'::regclass);


--
-- Name: sla id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla ALTER COLUMN id SET DEFAULT nextval('public.sla_id_seq'::regclass);


--
-- Name: sla_services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla_services ALTER COLUMN id SET DEFAULT nextval('public.sla_services_id_seq'::regclass);


--
-- Name: smime_certificates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smime_certificates ALTER COLUMN id SET DEFAULT nextval('public.smime_certificates_id_seq'::regclass);


--
-- Name: sql_box id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sql_box ALTER COLUMN id SET DEFAULT nextval('public.sql_box_id_seq'::regclass);


--
-- Name: state_transitions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state_transitions ALTER COLUMN id SET DEFAULT nextval('public.state_transitions_id_seq'::regclass);


--
-- Name: states id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.states ALTER COLUMN id SET DEFAULT nextval('public.states_id_seq'::regclass);


--
-- Name: system_configuration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_configuration ALTER COLUMN id SET DEFAULT nextval('public.system_configuration_id_seq'::regclass);


--
-- Name: system_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_log ALTER COLUMN id SET DEFAULT nextval('public.system_log_id_seq'::regclass);


--
-- Name: system_maintenance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_maintenance ALTER COLUMN id SET DEFAULT nextval('public.system_maintenance_id_seq'::regclass);


--
-- Name: template_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_attachments ALTER COLUMN id SET DEFAULT nextval('public.template_attachments_id_seq'::regclass);


--
-- Name: template_queues id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_queues ALTER COLUMN id SET DEFAULT nextval('public.template_queues_id_seq'::regclass);


--
-- Name: templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- Name: test_entities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_entities ALTER COLUMN id SET DEFAULT nextval('public.test_entities_id_seq'::regclass);


--
-- Name: ticket_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attachments ALTER COLUMN id SET DEFAULT nextval('public.ticket_attachments_id_seq'::regclass);


--
-- Name: ticket_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_comments ALTER COLUMN id SET DEFAULT nextval('public.ticket_comments_id_seq'::regclass);


--
-- Name: ticket_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_history ALTER COLUMN id SET DEFAULT nextval('public.ticket_history_id_seq'::regclass);


--
-- Name: ticket_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_notifications ALTER COLUMN id SET DEFAULT nextval('public.ticket_notifications_id_seq'::regclass);


--
-- Name: ticket_schedule_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedule_logs ALTER COLUMN id SET DEFAULT nextval('public.ticket_schedule_logs_id_seq'::regclass);


--
-- Name: ticket_schedules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules ALTER COLUMN id SET DEFAULT nextval('public.ticket_schedules_id_seq'::regclass);


--
-- Name: ticket_status_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history ALTER COLUMN id SET DEFAULT nextval('public.ticket_status_history_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: type_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_categories ALTER COLUMN id SET DEFAULT nextval('public.type_categories_id_seq'::regclass);


--
-- Name: type_category_relations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_category_relations ALTER COLUMN id SET DEFAULT nextval('public.type_category_relations_id_seq'::regclass);


--
-- Name: types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types ALTER COLUMN id SET DEFAULT nextval('public.types_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: users_groups_roles_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_groups_roles_settings ALTER COLUMN id SET DEFAULT nextval('public.users_groups_roles_settings_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: acl; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: acls; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: admin_notification; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agents (id, first_name, last_name, login, password, email, mobile_phone, telegram_account, avatar, is_active, role_id, created_at, updated_at) VALUES (1, 'Admin', 'User', 'admin', '$2b$10$TBFHhA2N0fkQEP7R5F7v7eIxWN4UUh0ug5KWawQ5Tn7nYqnJqIjZO', 'admin@example.com', NULL, NULL, NULL, true, 1, '2026-05-21 11:53:58.577777', '2026-05-21 11:53:58.577777');


--
-- Data for Name: agents_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agents_groups (id, name, role_id, is_active, created_at, updated_at) VALUES (2, 'Администраторы', NULL, true, '2026-05-21 12:36:16.913421', '2026-05-21 12:36:16.913421');


--
-- Data for Name: agents_groups_agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agents_groups_agents (agents_group_id, agent_id) VALUES (2, 1);


--
-- Data for Name: agents_groups_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agents_groups_roles (agents_group_id, role_id) VALUES (2, 1);


--
-- Data for Name: agents_queues; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: agents_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: auto_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: calendars; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customer_users; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customer_users_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customer_users_services; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customers_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customers_services; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: dynamic_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: dynamic_fields_screens; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: dynamicfields; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: email_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: generic_agent; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: greetings; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: knowledge_base; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: mail_fetch_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: oauth2; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: package_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: performance_log; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: pgp_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: post_master_filters; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: post_master_mail_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: priorities; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (1, 'Низкий', '#22c55e', true, '2026-05-21 11:53:58.581393', '2026-05-21 11:53:58.581393');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (2, 'Средний', '#eab308', true, '2026-05-21 11:53:58.581393', '2026-05-21 11:53:58.581393');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (3, 'Высокий', '#ef4444', true, '2026-05-21 11:53:58.581393', '2026-05-21 11:53:58.581393');


--
-- Data for Name: queue_auto_response; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: queues; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (2, 1, 'menu_agents_write', true, 644, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (3, 1, 'menu_agents_delete', true, 744, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (5, 1, 'menu_roles_list_write', true, 644, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (6, 1, 'menu_roles_list_delete', true, 744, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (8, 1, 'menu_permissions_write', true, 644, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (9, 1, 'menu_permissions_delete', true, 744, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (10, 1, 'menu_dashboard_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 12:37:41.77098');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (1, 1, 'menu_agents_read', true, 444, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (4, 1, 'menu_roles_list_read', true, 444, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (7, 1, 'menu_permissions_read', true, 444, '2026-05-21 12:23:27.607564', '2026-05-21 12:23:27.607564');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (35, 1, 'menu_tickets_list_delete', true, 444, '2026-05-21 14:34:32.523311', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (11, 1, 'menu_tickets_list_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (29, 1, 'menu_tickets_list_write', true, 444, '2026-05-21 14:34:20.788966', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (38, 1, 'menu_tickets_create_delete', true, 444, '2026-05-21 14:34:32.523311', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (12, 1, 'menu_tickets_create_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (31, 1, 'menu_tickets_create_write', true, 444, '2026-05-21 14:34:20.788966', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (41, 1, 'menu_tickets_schedules_delete', true, 444, '2026-05-21 14:34:32.523311', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (34, 1, 'menu_tickets_schedules_read', true, 444, '2026-05-21 14:34:20.788966', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (33, 1, 'menu_tickets_schedules_write', true, 444, '2026-05-21 14:34:20.788966', '2026-05-21 14:34:32.523311');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (46, 1, 'menu_knowledge_base_delete', true, 444, '2026-05-21 14:34:40.059319', '2026-05-21 14:34:40.059319');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (15, 1, 'menu_knowledge_base_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:34:40.059319');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (44, 1, 'menu_knowledge_base_write', true, 444, '2026-05-21 14:34:37.8617', '2026-05-21 14:34:40.059319');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (51, 1, 'menu_services_delete', true, 444, '2026-05-21 14:34:44.891868', '2026-05-21 14:34:44.891868');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (16, 1, 'menu_services_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:34:44.891868');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (49, 1, 'menu_services_write', true, 444, '2026-05-21 14:34:43.881454', '2026-05-21 14:34:44.891868');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (26, 1, 'menu_post_master_mail_accounts_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:45:58.716259');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (62, 1, 'menu_companies_list_delete', true, 444, '2026-05-21 14:45:48.567696', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (17, 1, 'menu_companies_list_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (54, 1, 'menu_companies_list_write', true, 444, '2026-05-21 14:45:47.538014', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (65, 1, 'menu_companies_groups_delete', true, 444, '2026-05-21 14:45:48.567696', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (57, 1, 'menu_companies_groups_read', true, 444, '2026-05-21 14:45:47.538014', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (56, 1, 'menu_companies_groups_write', true, 444, '2026-05-21 14:45:47.538014', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (68, 1, 'menu_companies_users_delete', true, 444, '2026-05-21 14:45:48.567696', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (59, 1, 'menu_companies_users_read', true, 444, '2026-05-21 14:45:47.538014', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (58, 1, 'menu_companies_users_write', true, 444, '2026-05-21 14:45:47.538014', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (71, 1, 'menu_companies_structure_delete', true, 444, '2026-05-21 14:45:48.567696', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (61, 1, 'menu_companies_structure_read', true, 444, '2026-05-21 14:45:47.538014', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (60, 1, 'menu_companies_structure_write', true, 444, '2026-05-21 14:45:47.538014', '2026-05-21 14:45:48.567696');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (19, 1, 'menu_types_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (90, 1, 'menu_types_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (122, 1, 'menu_type_categories_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (76, 1, 'menu_type_categories_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (92, 1, 'menu_type_categories_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (13, 1, 'menu_chat_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:46:24.090719');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (14, 1, 'menu_kanban_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:46:46.053336');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (27, 1, 'menu_kanban_write', true, 444, '2026-05-21 14:02:54.639597', '2026-05-21 14:46:46.053336');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (116, 1, 'menu_queues_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (18, 1, 'menu_queues_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (88, 1, 'menu_queues_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (119, 1, 'menu_types_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (125, 1, 'menu_states_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (20, 1, 'menu_states_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (94, 1, 'menu_states_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (128, 1, 'menu_priorities_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (21, 1, 'menu_priorities_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (96, 1, 'menu_priorities_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (131, 1, 'menu_sla_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (22, 1, 'menu_sla_read', true, 444, '2026-05-21 12:37:41.77098', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (98, 1, 'menu_sla_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (134, 1, 'menu_templates_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (80, 1, 'menu_templates_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (100, 1, 'menu_templates_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (137, 1, 'menu_template_queues_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (81, 1, 'menu_template_queues_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (102, 1, 'menu_template_queues_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (140, 1, 'menu_workflows_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (82, 1, 'menu_workflows_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (104, 1, 'menu_workflows_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (143, 1, 'menu_greetings_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (83, 1, 'menu_greetings_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (106, 1, 'menu_greetings_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (146, 1, 'menu_signatures_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (84, 1, 'menu_signatures_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (108, 1, 'menu_signatures_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (149, 1, 'menu_auto_responses_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (85, 1, 'menu_auto_responses_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (110, 1, 'menu_auto_responses_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (152, 1, 'menu_attachments_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (86, 1, 'menu_attachments_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (112, 1, 'menu_attachments_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (155, 1, 'menu_tickets_system_configuration_delete', true, 444, '2026-05-21 14:45:54.194215', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (87, 1, 'menu_tickets_system_configuration_read', true, 444, '2026-05-21 14:45:52.076725', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (114, 1, 'menu_tickets_system_configuration_write', true, 444, '2026-05-21 14:45:53.136556', '2026-05-21 14:45:54.194215');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (164, 1, 'menu_email_addresses_delete', true, 444, '2026-05-21 14:45:58.716259', '2026-05-21 14:45:58.716259');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (158, 1, 'menu_email_addresses_read', true, 444, '2026-05-21 14:45:56.591864', '2026-05-21 14:45:58.716259');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (160, 1, 'menu_email_addresses_write', true, 444, '2026-05-21 14:45:57.633718', '2026-05-21 14:45:58.716259');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (167, 1, 'menu_post_master_mail_accounts_delete', true, 444, '2026-05-21 14:45:58.716259', '2026-05-21 14:45:58.716259');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (162, 1, 'menu_post_master_mail_accounts_write', true, 444, '2026-05-21 14:45:57.633718', '2026-05-21 14:45:58.716259');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (179, 1, 'menu_calendars_delete', true, 444, '2026-05-21 14:46:02.057141', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (170, 1, 'menu_calendars_read', true, 444, '2026-05-21 14:45:59.997761', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (173, 1, 'menu_calendars_write', true, 444, '2026-05-21 14:46:01.109681', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (182, 1, 'menu_session_management_delete', true, 444, '2026-05-21 14:46:02.057141', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (171, 1, 'menu_session_management_read', true, 444, '2026-05-21 14:45:59.997761', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (175, 1, 'menu_session_management_write', true, 444, '2026-05-21 14:46:01.109681', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (185, 1, 'menu_system_log_delete', true, 444, '2026-05-21 14:46:02.057141', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (172, 1, 'menu_system_log_read', true, 444, '2026-05-21 14:45:59.997761', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (177, 1, 'menu_system_log_write', true, 444, '2026-05-21 14:46:01.109681', '2026-05-21 14:46:02.057141');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (191, 1, 'menu_backup_delete', true, 444, '2026-05-21 14:46:05.65423', '2026-05-21 14:46:05.65423');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (188, 1, 'menu_backup_read', true, 444, '2026-05-21 14:46:03.668703', '2026-05-21 14:46:05.65423');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (189, 1, 'menu_backup_write', true, 444, '2026-05-21 14:46:04.696469', '2026-05-21 14:46:05.65423');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (197, 1, 'menu_integrity_check_delete', true, 444, '2026-05-21 14:46:09.039621', '2026-05-21 14:46:09.039621');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (194, 1, 'menu_integrity_check_read', true, 444, '2026-05-21 14:46:06.739042', '2026-05-21 14:46:09.039621');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (195, 1, 'menu_integrity_check_write', true, 444, '2026-05-21 14:46:07.900668', '2026-05-21 14:46:09.039621');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (202, 1, 'menu_chat_delete', true, 444, '2026-05-21 14:46:24.090719', '2026-05-21 14:46:24.090719');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (200, 1, 'menu_chat_write', true, 444, '2026-05-21 14:46:22.931808', '2026-05-21 14:46:24.090719');
INSERT INTO public.role_permissions (id, role_id, permission, is_granted, level, created_at, updated_at) VALUES (205, 1, 'menu_kanban_delete', true, 444, '2026-05-21 14:46:46.053336', '2026-05-21 14:46:46.053336');


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.roles (id, name, message, icon, is_active, created_at, updated_at) VALUES (1, 'Admin_new1', NULL, NULL, true, '2026-05-21 11:53:58.573802', '2026-05-21 14:46:48.455285');


--
-- Data for Name: roles_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: service_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: services_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: session_management; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (1, 'admin', '::ffff:127.0.0.1', 'curl/7.81.0', '2026-05-21 09:08:37.812', '2026-05-21 12:15:18.674625', false, 'agent', 1, '2026-05-21 12:08:37.813034', '2026-05-21 12:08:37.813034');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (2, 'admin', '::ffff:127.0.0.1', 'curl/7.81.0', '2026-05-21 09:15:18.678', '2026-05-21 12:15:58.696934', false, 'agent', 1, '2026-05-21 12:15:18.678685', '2026-05-21 12:15:18.678685');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (3, 'admin', '::ffff:127.0.0.1', 'curl/7.81.0', '2026-05-21 09:15:58.735', '2026-05-21 12:18:24.72469', false, 'agent', 1, '2026-05-21 12:15:58.735411', '2026-05-21 12:15:58.735411');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (4, 'admin', '::ffff:127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36', '2026-05-21 09:18:24.728', '2026-05-21 12:27:26.773986', false, 'agent', 1, '2026-05-21 12:18:24.728653', '2026-05-21 12:18:24.728653');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (5, 'admin', '::ffff:127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36', '2026-05-21 09:27:26.777', '2026-05-21 12:27:41.497369', false, 'agent', 1, '2026-05-21 12:27:26.7783', '2026-05-21 12:27:26.7783');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (6, 'admin', '::ffff:127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36', '2026-05-21 09:27:41.499', '2026-05-21 12:27:58.114178', false, 'agent', 1, '2026-05-21 12:27:41.500071', '2026-05-21 12:27:41.500071');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (7, 'admin', '::ffff:127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36', '2026-05-21 09:27:58.117', '2026-05-21 13:46:02.253748', false, 'agent', 1, '2026-05-21 12:27:58.117438', '2026-05-21 12:27:58.117438');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (8, 'admin', '::ffff:127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36', '2026-05-21 10:46:02.257', '2026-05-21 11:46:58.963', false, 'agent', 1, '2026-05-21 13:46:02.258296', '2026-05-21 14:46:58.963918');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (9, 'admin', '::ffff:127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36', '2026-05-21 11:47:05.638', '2026-05-21 11:49:52.833', false, 'agent', 1, '2026-05-21 14:47:05.638814', '2026-05-21 14:49:52.835431');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (10, 'admin', '::ffff:127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36', '2026-05-21 11:50:06.947', '2026-05-21 11:51:47.101', false, 'agent', 1, '2026-05-21 14:50:06.947907', '2026-05-21 14:51:47.101886');
INSERT INTO public.session_management (id, username, ip_address, user_agent, login_time, last_activity, is_active, type, user_id, created_at, updated_at) VALUES (11, 'admin', '::ffff:127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36', '2026-05-21 11:51:50.04', '2026-05-21 11:54:38.389', true, 'agent', 1, '2026-05-21 14:51:50.041704', '2026-05-21 14:54:38.389468');


--
-- Data for Name: signatures; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sla; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sla_services; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: smime_certificates; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sql_box; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: state_transitions; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: states; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.states (id, name, comment, type, color, is_active, created_at, updated_at) VALUES (1, 'Новый', NULL, NULL, '#3b82f6', true, '2026-05-21 11:53:58.585188', '2026-05-21 11:53:58.585188');
INSERT INTO public.states (id, name, comment, type, color, is_active, created_at, updated_at) VALUES (2, 'В работе', NULL, NULL, '#f59e0b', true, '2026-05-21 11:53:58.585188', '2026-05-21 11:53:58.585188');
INSERT INTO public.states (id, name, comment, type, color, is_active, created_at, updated_at) VALUES (3, 'Решён', NULL, NULL, '#22c55e', true, '2026-05-21 11:53:58.585188', '2026-05-21 11:53:58.585188');
INSERT INTO public.states (id, name, comment, type, color, is_active, created_at, updated_at) VALUES (4, 'Закрыт', NULL, NULL, '#6b7280', true, '2026-05-21 11:53:58.585188', '2026-05-21 11:53:58.585188');


--
-- Data for Name: system_configuration; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: system_log; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: system_maintenance; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: template_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: template_queues; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: test_entities; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_history; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_schedule_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_status_history; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: type_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.type_categories (id, name, labor_hours, is_active, created_at, updated_at) VALUES (1, 'Общий', 0.00, true, '2026-05-21 11:53:58.588791', '2026-05-21 11:53:58.588791');
INSERT INTO public.type_categories (id, name, labor_hours, is_active, created_at, updated_at) VALUES (2, 'Инцидент', 0.00, true, '2026-05-21 11:53:58.588791', '2026-05-21 11:53:58.588791');
INSERT INTO public.type_categories (id, name, labor_hours, is_active, created_at, updated_at) VALUES (3, 'Запрос', 0.00, true, '2026-05-21 11:53:58.588791', '2026-05-21 11:53:58.588791');


--
-- Data for Name: type_category_relations; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: users_groups_roles_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: acl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acl_id_seq', 1, false);


--
-- Name: acls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acls_id_seq', 1, false);


--
-- Name: admin_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_notification_id_seq', 1, false);


--
-- Name: agents_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_groups_id_seq', 2, true);


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_id_seq', 1, true);


--
-- Name: agents_queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_queues_id_seq', 1, false);


--
-- Name: agents_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_roles_id_seq', 1, false);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, false);


--
-- Name: auto_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auto_responses_id_seq', 1, false);


--
-- Name: calendars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calendars_id_seq', 1, false);


--
-- Name: customer_users_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_users_groups_id_seq', 1, false);


--
-- Name: customer_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_users_id_seq', 1, false);


--
-- Name: customer_users_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_users_services_id_seq', 1, false);


--
-- Name: customers_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_groups_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: dynamic_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dynamic_fields_id_seq', 1, false);


--
-- Name: dynamic_fields_screens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dynamic_fields_screens_id_seq', 1, false);


--
-- Name: dynamicfields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dynamicfields_id_seq', 1, false);


--
-- Name: email_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_addresses_id_seq', 1, false);


--
-- Name: generic_agent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.generic_agent_id_seq', 1, false);


--
-- Name: greetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.greetings_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: knowledge_base_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knowledge_base_id_seq', 1, false);


--
-- Name: mail_fetch_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mail_fetch_logs_id_seq', 1, false);


--
-- Name: oauth2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth2_id_seq', 1, false);


--
-- Name: package_manager_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.package_manager_id_seq', 1, false);


--
-- Name: performance_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.performance_log_id_seq', 1, false);


--
-- Name: pgp_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pgp_keys_id_seq', 1, false);


--
-- Name: post_master_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_master_filters_id_seq', 1, false);


--
-- Name: post_master_mail_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_master_mail_accounts_id_seq', 1, false);


--
-- Name: priorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.priorities_id_seq', 3, true);


--
-- Name: queue_auto_response_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.queue_auto_response_id_seq', 1, false);


--
-- Name: queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.queues_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 207, true);


--
-- Name: roles_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_groups_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- Name: service_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_attachments_id_seq', 1, false);


--
-- Name: services_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_attachments_id_seq', 1, false);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_id_seq', 1, false);


--
-- Name: session_management_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.session_management_id_seq', 11, true);


--
-- Name: signatures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.signatures_id_seq', 1, false);


--
-- Name: sla_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sla_id_seq', 1, false);


--
-- Name: sla_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sla_services_id_seq', 1, false);


--
-- Name: smime_certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.smime_certificates_id_seq', 1, false);


--
-- Name: sql_box_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sql_box_id_seq', 1, false);


--
-- Name: state_transitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.state_transitions_id_seq', 1, false);


--
-- Name: states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.states_id_seq', 4, true);


--
-- Name: system_configuration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_configuration_id_seq', 1, false);


--
-- Name: system_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_log_id_seq', 1, false);


--
-- Name: system_maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_maintenance_id_seq', 1, false);


--
-- Name: template_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.template_attachments_id_seq', 1, false);


--
-- Name: template_queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.template_queues_id_seq', 1, false);


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.templates_id_seq', 1, false);


--
-- Name: test_entities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_entities_id_seq', 1, false);


--
-- Name: ticket_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_attachments_id_seq', 1, false);


--
-- Name: ticket_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_comments_id_seq', 1, false);


--
-- Name: ticket_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_history_id_seq', 1, false);


--
-- Name: ticket_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_notifications_id_seq', 1, false);


--
-- Name: ticket_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_number_seq', 1000001, false);


--
-- Name: ticket_schedule_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_schedule_logs_id_seq', 1, false);


--
-- Name: ticket_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_schedules_id_seq', 1, false);


--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_status_history_id_seq', 1, false);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tickets_id_seq', 1, false);


--
-- Name: type_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.type_categories_id_seq', 3, true);


--
-- Name: type_category_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.type_category_relations_id_seq', 1, false);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.types_id_seq', 1, false);


--
-- Name: users_groups_roles_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_groups_roles_settings_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1, false);


--
-- Name: acl acl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acl
    ADD CONSTRAINT acl_pkey PRIMARY KEY (id);


--
-- Name: acls acls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acls
    ADD CONSTRAINT acls_pkey PRIMARY KEY (id);


--
-- Name: admin_notification admin_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_notification
    ADD CONSTRAINT admin_notification_pkey PRIMARY KEY (id);


--
-- Name: agents agents_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_email_key UNIQUE (email);


--
-- Name: agents_groups_agents agents_groups_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_agents
    ADD CONSTRAINT agents_groups_agents_pkey PRIMARY KEY (agents_group_id, agent_id);


--
-- Name: agents_groups agents_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups
    ADD CONSTRAINT agents_groups_pkey PRIMARY KEY (id);


--
-- Name: agents_groups_roles agents_groups_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_roles
    ADD CONSTRAINT agents_groups_roles_pkey PRIMARY KEY (agents_group_id, role_id);


--
-- Name: agents agents_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_login_key UNIQUE (login);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: agents_roles agents_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_roles
    ADD CONSTRAINT agents_roles_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: auto_responses auto_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auto_responses
    ADD CONSTRAINT auto_responses_pkey PRIMARY KEY (id);


--
-- Name: calendars calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendars
    ADD CONSTRAINT calendars_pkey PRIMARY KEY (id);


--
-- Name: customer_users customer_users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_email_key UNIQUE (email);


--
-- Name: customer_users_groups customer_users_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_groups
    ADD CONSTRAINT customer_users_groups_pkey PRIMARY KEY (id);


--
-- Name: customer_users customer_users_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_login_key UNIQUE (login);


--
-- Name: customer_users customer_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_pkey PRIMARY KEY (id);


--
-- Name: customer_users_services customer_users_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_services
    ADD CONSTRAINT customer_users_services_pkey PRIMARY KEY (id);


--
-- Name: customers_groups customers_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_groups
    ADD CONSTRAINT customers_groups_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers_services customers_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_services
    ADD CONSTRAINT customers_services_pkey PRIMARY KEY (customer_id, service_id);


--
-- Name: dynamic_fields dynamic_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_fields
    ADD CONSTRAINT dynamic_fields_pkey PRIMARY KEY (id);


--
-- Name: dynamic_fields_screens dynamic_fields_screens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_fields_screens
    ADD CONSTRAINT dynamic_fields_screens_pkey PRIMARY KEY (id);


--
-- Name: email_addresses email_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_addresses
    ADD CONSTRAINT email_addresses_pkey PRIMARY KEY (id);


--
-- Name: generic_agent generic_agent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generic_agent
    ADD CONSTRAINT generic_agent_pkey PRIMARY KEY (id);


--
-- Name: greetings greetings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.greetings
    ADD CONSTRAINT greetings_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: knowledge_base knowledge_base_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_pkey PRIMARY KEY (id);


--
-- Name: mail_fetch_logs mail_fetch_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mail_fetch_logs
    ADD CONSTRAINT mail_fetch_logs_pkey PRIMARY KEY (id);


--
-- Name: oauth2 oauth2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth2
    ADD CONSTRAINT oauth2_pkey PRIMARY KEY (id);


--
-- Name: package_manager package_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package_manager
    ADD CONSTRAINT package_manager_pkey PRIMARY KEY (id);


--
-- Name: performance_log performance_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_log
    ADD CONSTRAINT performance_log_pkey PRIMARY KEY (id);


--
-- Name: pgp_keys pgp_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pgp_keys
    ADD CONSTRAINT pgp_keys_pkey PRIMARY KEY (id);


--
-- Name: post_master_filters post_master_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_filters
    ADD CONSTRAINT post_master_filters_pkey PRIMARY KEY (id);


--
-- Name: post_master_mail_accounts post_master_mail_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_mail_accounts
    ADD CONSTRAINT post_master_mail_accounts_pkey PRIMARY KEY (id);


--
-- Name: priorities priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT priorities_pkey PRIMARY KEY (id);


--
-- Name: queue_auto_response queue_auto_response_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queue_auto_response
    ADD CONSTRAINT queue_auto_response_pkey PRIMARY KEY (id);


--
-- Name: queues queues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_id_permission_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_permission_key UNIQUE (role_id, permission);


--
-- Name: roles_groups roles_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles_groups
    ADD CONSTRAINT roles_groups_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: session_management session_management_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_management
    ADD CONSTRAINT session_management_pkey PRIMARY KEY (id);


--
-- Name: signatures signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signatures
    ADD CONSTRAINT signatures_pkey PRIMARY KEY (id);


--
-- Name: sla sla_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla
    ADD CONSTRAINT sla_pkey PRIMARY KEY (id);


--
-- Name: smime_certificates smime_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smime_certificates
    ADD CONSTRAINT smime_certificates_pkey PRIMARY KEY (id);


--
-- Name: sql_box sql_box_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sql_box
    ADD CONSTRAINT sql_box_pkey PRIMARY KEY (id);


--
-- Name: states states_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.states
    ADD CONSTRAINT states_pkey PRIMARY KEY (id);


--
-- Name: system_configuration system_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_configuration
    ADD CONSTRAINT system_configuration_pkey PRIMARY KEY (id);


--
-- Name: system_log system_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_log
    ADD CONSTRAINT system_log_pkey PRIMARY KEY (id);


--
-- Name: system_maintenance system_maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_maintenance
    ADD CONSTRAINT system_maintenance_pkey PRIMARY KEY (id);


--
-- Name: template_attachments template_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_attachments
    ADD CONSTRAINT template_attachments_pkey PRIMARY KEY (id);


--
-- Name: template_queues template_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_queues
    ADD CONSTRAINT template_queues_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: test_entities test_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_entities
    ADD CONSTRAINT test_entities_pkey PRIMARY KEY (id);


--
-- Name: ticket_attachments ticket_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attachments
    ADD CONSTRAINT ticket_attachments_pkey PRIMARY KEY (id);


--
-- Name: ticket_comments ticket_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_pkey PRIMARY KEY (id);


--
-- Name: ticket_history ticket_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_pkey PRIMARY KEY (id);


--
-- Name: ticket_notifications ticket_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_notifications
    ADD CONSTRAINT ticket_notifications_pkey PRIMARY KEY (id);


--
-- Name: ticket_schedule_logs ticket_schedule_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedule_logs
    ADD CONSTRAINT ticket_schedule_logs_pkey PRIMARY KEY (id);


--
-- Name: ticket_schedules ticket_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_pkey PRIMARY KEY (id);


--
-- Name: ticket_status_history ticket_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_ticket_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_ticket_number_key UNIQUE (ticket_number);


--
-- Name: type_categories type_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_categories
    ADD CONSTRAINT type_categories_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users_groups_roles_settings users_groups_roles_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_groups_roles_settings
    ADD CONSTRAINT users_groups_roles_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_login_key UNIQUE (login);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_acl_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acl_is_active ON public.acl USING btree (is_active);


--
-- Name: idx_acl_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acl_name ON public.acl USING btree (name);


--
-- Name: idx_acls_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acls_is_active ON public.acls USING btree (is_active);


--
-- Name: idx_acls_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acls_name ON public.acls USING btree (name);


--
-- Name: idx_admin_notification_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admin_notification_is_active ON public.admin_notification USING btree (is_active);


--
-- Name: idx_admin_notification_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admin_notification_name ON public.admin_notification USING btree (name);


--
-- Name: idx_agents_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_email ON public.agents USING btree (email);


--
-- Name: idx_agents_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_groups_is_active ON public.agents_groups USING btree (is_active);


--
-- Name: idx_agents_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_groups_name ON public.agents_groups USING btree (name);


--
-- Name: idx_agents_groups_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_groups_role_id ON public.agents_groups USING btree (role_id);


--
-- Name: idx_agents_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_is_active ON public.agents USING btree (is_active);


--
-- Name: idx_agents_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_login ON public.agents USING btree (login);


--
-- Name: idx_agents_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_role_id ON public.agents USING btree (role_id);


--
-- Name: idx_agents_roles_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_roles_is_active ON public.agents_roles USING btree (is_active);


--
-- Name: idx_agents_roles_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_roles_name ON public.agents_roles USING btree (name);


--
-- Name: idx_calendars_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_is_active ON public.calendars USING btree (is_active);


--
-- Name: idx_calendars_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_name ON public.calendars USING btree (name);


--
-- Name: idx_customer_users_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_customer_id ON public.customer_users USING btree (customer_id);


--
-- Name: idx_customer_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_email ON public.customer_users USING btree (email);


--
-- Name: idx_customer_users_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_groups_is_active ON public.customer_users_groups USING btree (is_active);


--
-- Name: idx_customer_users_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_groups_name ON public.customer_users_groups USING btree (name);


--
-- Name: idx_customer_users_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_login ON public.customer_users USING btree (login);


--
-- Name: idx_customer_users_services_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_services_is_active ON public.customer_users_services USING btree (is_active);


--
-- Name: idx_customer_users_services_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_services_name ON public.customer_users_services USING btree (name);


--
-- Name: idx_customers_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_groups_name ON public.customers_groups USING btree (name);


--
-- Name: idx_customers_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_is_active ON public.customers USING btree (is_active);


--
-- Name: idx_customers_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_name ON public.customers USING btree (name);


--
-- Name: idx_dynamic_fields_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_fields_is_active ON public.dynamic_fields USING btree (is_active);


--
-- Name: idx_dynamic_fields_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_fields_name ON public.dynamic_fields USING btree (name);


--
-- Name: idx_dynamic_fields_screens_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_fields_screens_is_active ON public.dynamic_fields_screens USING btree (is_active);


--
-- Name: idx_dynamic_fields_screens_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_fields_screens_name ON public.dynamic_fields_screens USING btree (name);


--
-- Name: idx_generic_agent_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_generic_agent_is_active ON public.generic_agent USING btree (is_active);


--
-- Name: idx_generic_agent_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_generic_agent_name ON public.generic_agent USING btree (name);


--
-- Name: idx_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_groups_is_active ON public.groups USING btree (is_active);


--
-- Name: idx_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_groups_name ON public.groups USING btree (name);


--
-- Name: idx_oauth2_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_oauth2_is_active ON public.oauth2 USING btree (is_active);


--
-- Name: idx_oauth2_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_oauth2_name ON public.oauth2 USING btree (name);


--
-- Name: idx_package_manager_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_package_manager_is_active ON public.package_manager USING btree (is_active);


--
-- Name: idx_package_manager_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_package_manager_name ON public.package_manager USING btree (name);


--
-- Name: idx_pgp_keys_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pgp_keys_is_active ON public.pgp_keys USING btree (is_active);


--
-- Name: idx_pgp_keys_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pgp_keys_name ON public.pgp_keys USING btree (name);


--
-- Name: idx_post_master_mail_accounts_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_post_master_mail_accounts_is_active ON public.post_master_mail_accounts USING btree (is_active);


--
-- Name: idx_post_master_mail_accounts_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_post_master_mail_accounts_login ON public.post_master_mail_accounts USING btree (login);


--
-- Name: idx_post_master_mail_accounts_queue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_post_master_mail_accounts_queue_id ON public.post_master_mail_accounts USING btree (queue_id);


--
-- Name: idx_priorities_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_priorities_is_active ON public.priorities USING btree (is_active);


--
-- Name: idx_priorities_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_priorities_name ON public.priorities USING btree (name);


--
-- Name: idx_queues_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_company_id ON public.queues USING btree (company_id);


--
-- Name: idx_queues_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_is_active ON public.queues USING btree (is_active);


--
-- Name: idx_queues_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_name ON public.queues USING btree (name);


--
-- Name: idx_queues_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_service_id ON public.queues USING btree (service_id);


--
-- Name: idx_queues_sla_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_sla_id ON public.queues USING btree (sla_id);


--
-- Name: idx_role_permissions_permission; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_role_permissions_permission ON public.role_permissions USING btree (permission);


--
-- Name: idx_role_permissions_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_role_permissions_role_id ON public.role_permissions USING btree (role_id);


--
-- Name: idx_roles_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_roles_groups_is_active ON public.roles_groups USING btree (is_active);


--
-- Name: idx_roles_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_roles_groups_name ON public.roles_groups USING btree (name);


--
-- Name: idx_roles_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_roles_is_active ON public.roles USING btree (is_active);


--
-- Name: idx_roles_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_roles_name ON public.roles USING btree (name);


--
-- Name: idx_services_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_is_active ON public.services USING btree (is_active);


--
-- Name: idx_services_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_name ON public.services USING btree (name);


--
-- Name: idx_sla_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sla_is_active ON public.sla USING btree (is_active);


--
-- Name: idx_sla_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sla_name ON public.sla USING btree (name);


--
-- Name: idx_sla_services_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sla_services_service_id ON public.sla_services USING btree (service_id);


--
-- Name: idx_sla_services_sla_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sla_services_sla_id ON public.sla_services USING btree (sla_id);


--
-- Name: idx_smime_certificates_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_smime_certificates_is_active ON public.smime_certificates USING btree (is_active);


--
-- Name: idx_smime_certificates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_smime_certificates_name ON public.smime_certificates USING btree (name);


--
-- Name: idx_sql_box_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sql_box_is_active ON public.sql_box USING btree (is_active);


--
-- Name: idx_sql_box_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sql_box_name ON public.sql_box USING btree (name);


--
-- Name: idx_state_transitions_from; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_state_transitions_from ON public.state_transitions USING btree (from_state_id);


--
-- Name: idx_state_transitions_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_state_transitions_to ON public.state_transitions USING btree (to_state_id);


--
-- Name: idx_state_transitions_type_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_state_transitions_type_id ON public.state_transitions USING btree (type_id);


--
-- Name: idx_states_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_states_is_active ON public.states USING btree (is_active);


--
-- Name: idx_states_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_states_name ON public.states USING btree (name);


--
-- Name: idx_system_maintenance_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_maintenance_is_active ON public.system_maintenance USING btree (is_active);


--
-- Name: idx_system_maintenance_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_maintenance_name ON public.system_maintenance USING btree (name);


--
-- Name: idx_test_entities_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_test_entities_is_active ON public.test_entities USING btree (is_active);


--
-- Name: idx_test_entities_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_test_entities_name ON public.test_entities USING btree (name);


--
-- Name: idx_ticket_notifications_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_notifications_is_active ON public.ticket_notifications USING btree (is_active);


--
-- Name: idx_ticket_notifications_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_notifications_name ON public.ticket_notifications USING btree (name);


--
-- Name: idx_ticket_schedule_logs_schedule_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_schedule_logs_schedule_id ON public.ticket_schedule_logs USING btree (schedule_id);


--
-- Name: idx_ticket_schedules_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_schedules_is_active ON public.ticket_schedules USING btree (is_active);


--
-- Name: idx_ticket_schedules_next_run_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_schedules_next_run_at ON public.ticket_schedules USING btree (next_run_at);


--
-- Name: idx_ticket_schedules_ticket_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_schedules_ticket_id ON public.ticket_schedules USING btree (ticket_id);


--
-- Name: idx_tickets_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_created_at ON public.tickets USING btree (created_at);


--
-- Name: idx_tickets_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_is_active ON public.tickets USING btree (is_active);


--
-- Name: idx_tickets_queue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_queue_id ON public.tickets USING btree (queue_id);


--
-- Name: idx_tickets_state_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_state_id ON public.tickets USING btree (state_id);


--
-- Name: idx_tickets_ticket_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_ticket_number ON public.tickets USING btree (ticket_number);


--
-- Name: idx_type_categories_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_type_categories_name ON public.type_categories USING btree (name);


--
-- Name: idx_types_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_types_is_active ON public.types USING btree (is_active);


--
-- Name: idx_types_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_types_name ON public.types USING btree (name);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_groups_roles_settings_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_groups_roles_settings_is_active ON public.users_groups_roles_settings USING btree (is_active);


--
-- Name: idx_users_groups_roles_settings_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_groups_roles_settings_name ON public.users_groups_roles_settings USING btree (name);


--
-- Name: idx_users_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_login ON public.users USING btree (login);


--
-- Name: idx_workflows_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflows_is_active ON public.workflows USING btree (is_active);


--
-- Name: idx_workflows_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflows_name ON public.workflows USING btree (name);


--
-- Name: acl trigger_update_acl_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_acl_updated_at BEFORE UPDATE ON public.acl FOR EACH ROW EXECUTE FUNCTION public.update_acl_updated_at();


--
-- Name: acls trigger_update_acls_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_acls_updated_at BEFORE UPDATE ON public.acls FOR EACH ROW EXECUTE FUNCTION public.update_acls_updated_at();


--
-- Name: admin_notification trigger_update_admin_notification_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_admin_notification_updated_at BEFORE UPDATE ON public.admin_notification FOR EACH ROW EXECUTE FUNCTION public.update_admin_notification_updated_at();


--
-- Name: agents_groups trigger_update_agents_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_agents_groups_updated_at BEFORE UPDATE ON public.agents_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agents_roles trigger_update_agents_roles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_agents_roles_updated_at BEFORE UPDATE ON public.agents_roles FOR EACH ROW EXECUTE FUNCTION public.update_agents_roles_updated_at();


--
-- Name: agents trigger_update_agents_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: calendars trigger_update_calendars_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_calendars_updated_at BEFORE UPDATE ON public.calendars FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: customer_users_groups trigger_update_customer_users_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customer_users_groups_updated_at BEFORE UPDATE ON public.customer_users_groups FOR EACH ROW EXECUTE FUNCTION public.update_customer_users_groups_updated_at();


--
-- Name: customer_users_services trigger_update_customer_users_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customer_users_services_updated_at BEFORE UPDATE ON public.customer_users_services FOR EACH ROW EXECUTE FUNCTION public.update_customer_users_services_updated_at();


--
-- Name: customer_users trigger_update_customer_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customer_users_updated_at BEFORE UPDATE ON public.customer_users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: customers trigger_update_customers_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: dynamic_fields_screens trigger_update_dynamic_fields_screens_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_dynamic_fields_screens_updated_at BEFORE UPDATE ON public.dynamic_fields_screens FOR EACH ROW EXECUTE FUNCTION public.update_dynamic_fields_screens_updated_at();


--
-- Name: dynamic_fields trigger_update_dynamic_fields_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_dynamic_fields_updated_at BEFORE UPDATE ON public.dynamic_fields FOR EACH ROW EXECUTE FUNCTION public.update_dynamic_fields_updated_at();


--
-- Name: generic_agent trigger_update_generic_agent_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_generic_agent_updated_at BEFORE UPDATE ON public.generic_agent FOR EACH ROW EXECUTE FUNCTION public.update_generic_agent_updated_at();


--
-- Name: groups trigger_update_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_groups_updated_at BEFORE UPDATE ON public.groups FOR EACH ROW EXECUTE FUNCTION public.update_groups_updated_at();


--
-- Name: oauth2 trigger_update_oauth2_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_oauth2_updated_at BEFORE UPDATE ON public.oauth2 FOR EACH ROW EXECUTE FUNCTION public.update_oauth2_updated_at();


--
-- Name: package_manager trigger_update_package_manager_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_package_manager_updated_at BEFORE UPDATE ON public.package_manager FOR EACH ROW EXECUTE FUNCTION public.update_package_manager_updated_at();


--
-- Name: pgp_keys trigger_update_pgp_keys_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_pgp_keys_updated_at BEFORE UPDATE ON public.pgp_keys FOR EACH ROW EXECUTE FUNCTION public.update_pgp_keys_updated_at();


--
-- Name: post_master_mail_accounts trigger_update_post_master_mail_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_post_master_mail_accounts_updated_at BEFORE UPDATE ON public.post_master_mail_accounts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: priorities trigger_update_priorities_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_priorities_updated_at BEFORE UPDATE ON public.priorities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: queues trigger_update_queues_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_queues_updated_at BEFORE UPDATE ON public.queues FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: roles_groups trigger_update_roles_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_roles_groups_updated_at BEFORE UPDATE ON public.roles_groups FOR EACH ROW EXECUTE FUNCTION public.update_roles_groups_updated_at();


--
-- Name: roles trigger_update_roles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_roles_updated_at BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: services trigger_update_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: sla_services trigger_update_sla_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_sla_services_updated_at BEFORE UPDATE ON public.sla_services FOR EACH ROW EXECUTE FUNCTION public.update_sla_services_updated_at();


--
-- Name: sla trigger_update_sla_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_sla_updated_at BEFORE UPDATE ON public.sla FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: smime_certificates trigger_update_smime_certificates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_smime_certificates_updated_at BEFORE UPDATE ON public.smime_certificates FOR EACH ROW EXECUTE FUNCTION public.update_smime_certificates_updated_at();


--
-- Name: sql_box trigger_update_sql_box_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_sql_box_updated_at BEFORE UPDATE ON public.sql_box FOR EACH ROW EXECUTE FUNCTION public.update_sql_box_updated_at();


--
-- Name: states trigger_update_states_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_states_updated_at BEFORE UPDATE ON public.states FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: system_maintenance trigger_update_system_maintenance_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_system_maintenance_updated_at BEFORE UPDATE ON public.system_maintenance FOR EACH ROW EXECUTE FUNCTION public.update_system_maintenance_updated_at();


--
-- Name: test_entities trigger_update_test_entities_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_test_entities_updated_at BEFORE UPDATE ON public.test_entities FOR EACH ROW EXECUTE FUNCTION public.update_test_entities_updated_at();


--
-- Name: ticket_notifications trigger_update_ticket_notifications_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_ticket_notifications_updated_at BEFORE UPDATE ON public.ticket_notifications FOR EACH ROW EXECUTE FUNCTION public.update_ticket_notifications_updated_at();


--
-- Name: ticket_schedules trigger_update_ticket_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_ticket_schedules_updated_at BEFORE UPDATE ON public.ticket_schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tickets trigger_update_tickets_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_tickets_updated_at BEFORE UPDATE ON public.tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: types trigger_update_types_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_types_updated_at BEFORE UPDATE ON public.types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users_groups_roles_settings trigger_update_users_groups_roles_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_users_groups_roles_settings_updated_at BEFORE UPDATE ON public.users_groups_roles_settings FOR EACH ROW EXECUTE FUNCTION public.update_users_groups_roles_settings_updated_at();


--
-- Name: users trigger_update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: workflows trigger_update_workflows_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_workflows_updated_at BEFORE UPDATE ON public.workflows FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agents_groups_agents agents_groups_agents_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_agents
    ADD CONSTRAINT agents_groups_agents_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agents_groups_agents agents_groups_agents_agents_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_agents
    ADD CONSTRAINT agents_groups_agents_agents_group_id_fkey FOREIGN KEY (agents_group_id) REFERENCES public.agents_groups(id) ON DELETE CASCADE;


--
-- Name: agents_groups agents_groups_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups
    ADD CONSTRAINT agents_groups_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: agents_groups_roles agents_groups_roles_agents_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_roles
    ADD CONSTRAINT agents_groups_roles_agents_group_id_fkey FOREIGN KEY (agents_group_id) REFERENCES public.agents_groups(id) ON DELETE CASCADE;


--
-- Name: agents_groups_roles agents_groups_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_roles
    ADD CONSTRAINT agents_groups_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: agents agents_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: customer_users customer_users_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: customer_users customer_users_customers_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_customers_group_id_fkey FOREIGN KEY (customers_group_id) REFERENCES public.customers_groups(id) ON DELETE SET NULL;


--
-- Name: customers_groups customers_groups_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_groups
    ADD CONSTRAINT customers_groups_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: customers_services customers_services_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_services
    ADD CONSTRAINT customers_services_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customers_services customers_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_services
    ADD CONSTRAINT customers_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: email_addresses email_addresses_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_addresses
    ADD CONSTRAINT email_addresses_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.queues(id) ON DELETE SET NULL;


--
-- Name: knowledge_base knowledge_base_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: knowledge_base knowledge_base_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: post_master_mail_accounts post_master_mail_accounts_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_mail_accounts
    ADD CONSTRAINT post_master_mail_accounts_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.queues(id) ON DELETE SET NULL;


--
-- Name: queues queues_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.type_categories(id) ON DELETE SET NULL;


--
-- Name: queues queues_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: queues queues_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.priorities(id) ON DELETE SET NULL;


--
-- Name: queues queues_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: queues queues_sla_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_sla_id_fkey FOREIGN KEY (sla_id) REFERENCES public.sla(id) ON DELETE SET NULL;


--
-- Name: queues queues_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.types(id) ON DELETE SET NULL;


--
-- Name: queues queues_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE SET NULL;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: services services_sla_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_sla_id_fkey FOREIGN KEY (sla_id) REFERENCES public.sla(id) ON DELETE SET NULL;


--
-- Name: ticket_attachments ticket_attachments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attachments
    ADD CONSTRAINT ticket_attachments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_comments ticket_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: ticket_comments ticket_comments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_history ticket_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.agents(id);


--
-- Name: ticket_history ticket_history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_schedule_logs ticket_schedule_logs_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedule_logs
    ADD CONSTRAINT ticket_schedule_logs_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.ticket_schedules(id) ON DELETE CASCADE;


--
-- Name: ticket_schedules ticket_schedules_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.type_categories(id) ON DELETE SET NULL;


--
-- Name: ticket_schedules ticket_schedules_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: ticket_schedules ticket_schedules_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.customer_users(id) ON DELETE SET NULL;


--
-- Name: ticket_schedules ticket_schedules_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.priorities(id) ON DELETE SET NULL;


--
-- Name: ticket_schedules ticket_schedules_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.queues(id) ON DELETE SET NULL;


--
-- Name: ticket_schedules ticket_schedules_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: ticket_schedules ticket_schedules_sla_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_sla_id_fkey FOREIGN KEY (sla_id) REFERENCES public.sla(id) ON DELETE SET NULL;


--
-- Name: ticket_schedules ticket_schedules_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_state_id_fkey FOREIGN KEY (state_id) REFERENCES public.states(id) ON DELETE SET NULL;


--
-- Name: ticket_schedules ticket_schedules_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_schedules ticket_schedules_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_schedules
    ADD CONSTRAINT ticket_schedules_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.types(id) ON DELETE SET NULL;


--
-- Name: ticket_status_history ticket_status_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.agents(id);


--
-- Name: ticket_status_history ticket_status_history_from_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_from_state_id_fkey FOREIGN KEY (from_state_id) REFERENCES public.states(id);


--
-- Name: ticket_status_history ticket_status_history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_status_history ticket_status_history_to_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_to_state_id_fkey FOREIGN KEY (to_state_id) REFERENCES public.states(id);


--
-- Name: tickets tickets_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.type_categories(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.customer_users(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.priorities(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.queues(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_sla_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_sla_id_fkey FOREIGN KEY (sla_id) REFERENCES public.sla(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_state_id_fkey FOREIGN KEY (state_id) REFERENCES public.states(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.types(id) ON DELETE SET NULL;


--
-- Name: types types_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict iiWSqwVoThpj2zjxiaKAI9creY5L0J6NRQ7sMPWsSWKp5vDMLQkUfY2fYGhVUAW

