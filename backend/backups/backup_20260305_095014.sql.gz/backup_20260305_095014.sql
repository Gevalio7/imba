--
-- PostgreSQL database dump
--

\restrict gg3LptHnxWywPbFVaej3EEFtuhTqzopBEXhJnuXQI4cn8ef1aBtsoe5FZASxtXx

-- Dumped from database version 18.1 (Ubuntu 18.1-1.pgdg22.04+2)
-- Dumped by pg_dump version 18.1 (Ubuntu 18.1-1.pgdg22.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_acl_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_acl_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_acl_updated_at() OWNER TO postgres;

--
-- Name: update_acls_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_acls_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_acls_updated_at() OWNER TO postgres;

--
-- Name: update_admin_notification_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_admin_notification_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_admin_notification_updated_at() OWNER TO postgres;

--
-- Name: update_admin_notifications_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_admin_notifications_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_admin_notifications_updated_at() OWNER TO postgres;

--
-- Name: update_agents_groups_agents_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agents_groups_agents_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agents_groups_agents_updated_at() OWNER TO postgres;

--
-- Name: update_agents_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agents_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agents_groups_updated_at() OWNER TO postgres;

--
-- Name: update_agents_roles_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agents_roles_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agents_roles_updated_at() OWNER TO postgres;

--
-- Name: update_agents_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_agents_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_agents_updated_at() OWNER TO postgres;

--
-- Name: update_appointment_notifications_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_appointment_notifications_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_appointment_notifications_updated_at() OWNER TO postgres;

--
-- Name: update_attachments_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_attachments_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_attachments_updated_at() OWNER TO postgres;

--
-- Name: update_auto_responses_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_auto_responses_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_auto_responses_updated_at() OWNER TO postgres;

--
-- Name: update_calendar_events_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_calendar_events_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_calendar_events_updated_at() OWNER TO postgres;

--
-- Name: update_calendars_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_calendars_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_calendars_updated_at() OWNER TO postgres;

--
-- Name: update_communication_log_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_communication_log_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_communication_log_updated_at() OWNER TO postgres;

--
-- Name: update_communication_notifications_settings_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_communication_notifications_settings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_communication_notifications_settings_updated_at() OWNER TO postgres;

--
-- Name: update_customer_users_customers_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customer_users_customers_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_users_customers_updated_at() OWNER TO postgres;

--
-- Name: update_customer_users_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customer_users_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_users_groups_updated_at() OWNER TO postgres;

--
-- Name: update_customer_users_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customer_users_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_users_services_updated_at() OWNER TO postgres;

--
-- Name: update_customer_users_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customer_users_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customer_users_updated_at() OWNER TO postgres;

--
-- Name: update_customers_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customers_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customers_groups_updated_at() OWNER TO postgres;

--
-- Name: update_customers_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customers_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customers_services_updated_at() OWNER TO postgres;

--
-- Name: update_customers_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_customers_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_customers_updated_at() OWNER TO postgres;

--
-- Name: update_dynamic_fields_screens_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_dynamic_fields_screens_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_dynamic_fields_screens_updated_at() OWNER TO postgres;

--
-- Name: update_dynamic_fields_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_dynamic_fields_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_dynamic_fields_updated_at() OWNER TO postgres;

--
-- Name: update_email_addresses_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_email_addresses_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_email_addresses_updated_at() OWNER TO postgres;

--
-- Name: update_general_catalog_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_general_catalog_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_general_catalog_updated_at() OWNER TO postgres;

--
-- Name: update_generic_agent_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_generic_agent_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_generic_agent_updated_at() OWNER TO postgres;

--
-- Name: update_greetings_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_greetings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_greetings_updated_at() OWNER TO postgres;

--
-- Name: update_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_groups_updated_at() OWNER TO postgres;

--
-- Name: update_oauth2_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_oauth2_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_oauth2_updated_at() OWNER TO postgres;

--
-- Name: update_package_manager_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_package_manager_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_package_manager_updated_at() OWNER TO postgres;

--
-- Name: update_performance_log_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_performance_log_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_performance_log_updated_at() OWNER TO postgres;

--
-- Name: update_pgp_keys_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_pgp_keys_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_pgp_keys_updated_at() OWNER TO postgres;

--
-- Name: update_post_master_filters_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_post_master_filters_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_post_master_filters_updated_at() OWNER TO postgres;

--
-- Name: update_post_master_mail_accounts_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_post_master_mail_accounts_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_post_master_mail_accounts_updated_at() OWNER TO postgres;

--
-- Name: update_priorities_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_priorities_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_priorities_updated_at() OWNER TO postgres;

--
-- Name: update_process_management_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_process_management_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_process_management_updated_at() OWNER TO postgres;

--
-- Name: update_processes_automation_settings_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_processes_automation_settings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_processes_automation_settings_updated_at() OWNER TO postgres;

--
-- Name: update_queue_auto_response_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_queue_auto_response_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_queue_auto_response_updated_at() OWNER TO postgres;

--
-- Name: update_queues_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_queues_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_queues_updated_at() OWNER TO postgres;

--
-- Name: update_roles_groups_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_roles_groups_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_roles_groups_updated_at() OWNER TO postgres;

--
-- Name: update_roles_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_roles_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_roles_updated_at() OWNER TO postgres;

--
-- Name: update_services_attachments_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_services_attachments_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_services_attachments_updated_at() OWNER TO postgres;

--
-- Name: update_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_services_updated_at() OWNER TO postgres;

--
-- Name: update_session_management_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_session_management_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_session_management_updated_at() OWNER TO postgres;

--
-- Name: update_signatures_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_signatures_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_signatures_updated_at() OWNER TO postgres;

--
-- Name: update_sla_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_sla_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_sla_services_updated_at() OWNER TO postgres;

--
-- Name: update_sla_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_sla_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_sla_updated_at() OWNER TO postgres;

--
-- Name: update_smime_certificates_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_smime_certificates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_smime_certificates_updated_at() OWNER TO postgres;

--
-- Name: update_sql_box_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_sql_box_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_sql_box_updated_at() OWNER TO postgres;

--
-- Name: update_states_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_states_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_states_updated_at() OWNER TO postgres;

--
-- Name: update_support_data_collector_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_support_data_collector_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_support_data_collector_updated_at() OWNER TO postgres;

--
-- Name: update_system_configuration_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_system_configuration_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_system_configuration_updated_at() OWNER TO postgres;

--
-- Name: update_system_file_support_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_system_file_support_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_system_file_support_updated_at() OWNER TO postgres;

--
-- Name: update_system_log_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_system_log_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_system_log_updated_at() OWNER TO postgres;

--
-- Name: update_system_maintenance_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_system_maintenance_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_system_maintenance_updated_at() OWNER TO postgres;

--
-- Name: update_template_attachments_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_template_attachments_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_template_attachments_updated_at() OWNER TO postgres;

--
-- Name: update_template_queues_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_template_queues_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_template_queues_updated_at() OWNER TO postgres;

--
-- Name: update_templates_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_templates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_templates_updated_at() OWNER TO postgres;

--
-- Name: update_test_entities_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_test_entities_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_test_entities_updated_at() OWNER TO postgres;

--
-- Name: update_ticket_attribute_relations_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_ticket_attribute_relations_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_ticket_attribute_relations_updated_at() OWNER TO postgres;

--
-- Name: update_ticket_notifications_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_ticket_notifications_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_ticket_notifications_updated_at() OWNER TO postgres;

--
-- Name: update_translation_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_translation_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_translation_updated_at() OWNER TO postgres;

--
-- Name: update_types_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_types_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_types_updated_at() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

--
-- Name: update_users_groups_roles_settings_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_users_groups_roles_settings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_users_groups_roles_settings_updated_at() OWNER TO postgres;

--
-- Name: update_web_services_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_web_services_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_web_services_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acl (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    permissions text[],
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.acl OWNER TO postgres;

--
-- Name: acl_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.acl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.acl_id_seq OWNER TO postgres;

--
-- Name: acl_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.acl_id_seq OWNED BY public.acl.id;


--
-- Name: acls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acls (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.acls OWNER TO postgres;

--
-- Name: acls_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.acls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.acls_id_seq OWNER TO postgres;

--
-- Name: acls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.acls_id_seq OWNED BY public.acls.id;


--
-- Name: admin_notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_notification (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admin_notification OWNER TO postgres;

--
-- Name: admin_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_notification_id_seq OWNER TO postgres;

--
-- Name: admin_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_notification_id_seq OWNED BY public.admin_notification.id;


--
-- Name: admin_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_notifications (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admin_notifications OWNER TO postgres;

--
-- Name: admin_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_notifications_id_seq OWNER TO postgres;

--
-- Name: admin_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_notifications_id_seq OWNED BY public.admin_notifications.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    first_name character varying(255),
    last_name character varying(255),
    login character varying(255),
    password character varying(255),
    email character varying(255),
    mobile_phone character varying(255),
    telegram_account character varying(255),
    role_id integer
);


ALTER TABLE public.agents OWNER TO postgres;

--
-- Name: agents_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents_groups OWNER TO postgres;

--
-- Name: agents_groups_agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_groups_agents (
    id integer NOT NULL,
    agents_group_id integer NOT NULL,
    agent_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents_groups_agents OWNER TO postgres;

--
-- Name: agents_groups_agents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_groups_agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_groups_agents_id_seq OWNER TO postgres;

--
-- Name: agents_groups_agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_groups_agents_id_seq OWNED BY public.agents_groups_agents.id;


--
-- Name: agents_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_groups_id_seq OWNER TO postgres;

--
-- Name: agents_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_groups_id_seq OWNED BY public.agents_groups.id;


--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_id_seq OWNER TO postgres;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: agents_queues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_queues (
    id integer NOT NULL,
    agent_id integer,
    queue_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents_queues OWNER TO postgres;

--
-- Name: agents_queues_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_queues_id_seq OWNER TO postgres;

--
-- Name: agents_queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_queues_id_seq OWNED BY public.agents_queues.id;


--
-- Name: agents_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents_roles (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.agents_roles OWNER TO postgres;

--
-- Name: agents_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agents_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_roles_id_seq OWNER TO postgres;

--
-- Name: agents_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agents_roles_id_seq OWNED BY public.agents_roles.id;


--
-- Name: appointment_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointment_notifications (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.appointment_notifications OWNER TO postgres;

--
-- Name: appointment_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointment_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointment_notifications_id_seq OWNER TO postgres;

--
-- Name: appointment_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointment_notifications_id_seq OWNED BY public.appointment_notifications.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    file_name character varying(255),
    type integer,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attachments OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachments_id_seq OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: auto_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auto_responses (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    trigger character varying(255),
    response text,
    delay integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.auto_responses OWNER TO postgres;

--
-- Name: auto_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auto_responses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auto_responses_id_seq OWNER TO postgres;

--
-- Name: auto_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auto_responses_id_seq OWNED BY public.auto_responses.id;


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calendar_events (
    id integer NOT NULL,
    calendar_id integer NOT NULL,
    title character varying(255) NOT NULL,
    start timestamp without time zone NOT NULL,
    event_end timestamp without time zone NOT NULL,
    all_day boolean DEFAULT false,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.calendar_events OWNER TO postgres;

--
-- Name: calendar_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calendar_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calendar_events_id_seq OWNER TO postgres;

--
-- Name: calendar_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calendar_events_id_seq OWNED BY public.calendar_events.id;


--
-- Name: calendars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calendars (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    timezone character varying(255),
    work_hours character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    work_hours_from time without time zone,
    work_hours_to time without time zone,
    work_days_per_week integer DEFAULT 5,
    color character varying(50) DEFAULT 'primary'::character varying,
    date_from date,
    date_to date,
    include_weekends boolean DEFAULT false,
    CONSTRAINT calendars_work_days_per_week_check CHECK (((work_days_per_week >= 3) AND (work_days_per_week <= 7)))
);


ALTER TABLE public.calendars OWNER TO postgres;

--
-- Name: calendars_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calendars_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calendars_id_seq OWNER TO postgres;

--
-- Name: calendars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calendars_id_seq OWNED BY public.calendars.id;


--
-- Name: communication_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.communication_log (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.communication_log OWNER TO postgres;

--
-- Name: communication_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.communication_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.communication_log_id_seq OWNER TO postgres;

--
-- Name: communication_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.communication_log_id_seq OWNED BY public.communication_log.id;


--
-- Name: communication_notifications_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.communication_notifications_settings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.communication_notifications_settings OWNER TO postgres;

--
-- Name: communication_notifications_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.communication_notifications_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.communication_notifications_settings_id_seq OWNER TO postgres;

--
-- Name: communication_notifications_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.communication_notifications_settings_id_seq OWNED BY public.communication_notifications_settings.id;


--
-- Name: customer_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_users (
    id integer NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    first_name character varying(255),
    last_name character varying(255),
    login character varying(255),
    password character varying(255),
    email character varying(255),
    mobile_phone character varying(50),
    telegram_account character varying(100),
    customer_id integer,
    customers_group_id integer
);


ALTER TABLE public.customer_users OWNER TO postgres;

--
-- Name: customer_users_customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_users_customers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_users_customers OWNER TO postgres;

--
-- Name: customer_users_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_users_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_users_customers_id_seq OWNER TO postgres;

--
-- Name: customer_users_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_users_customers_id_seq OWNED BY public.customer_users_customers.id;


--
-- Name: customer_users_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_users_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_users_groups OWNER TO postgres;

--
-- Name: customer_users_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_users_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_users_groups_id_seq OWNER TO postgres;

--
-- Name: customer_users_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_users_groups_id_seq OWNED BY public.customer_users_groups.id;


--
-- Name: customer_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_users_id_seq OWNER TO postgres;

--
-- Name: customer_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_users_id_seq OWNED BY public.customer_users.id;


--
-- Name: customer_users_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_users_services (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer_users_services OWNER TO postgres;

--
-- Name: customer_users_services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_users_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_users_services_id_seq OWNER TO postgres;

--
-- Name: customer_users_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_users_services_id_seq OWNED BY public.customer_users_services.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    street character varying(255),
    zip character varying(20),
    city character varying(255),
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    customer_id integer
);


ALTER TABLE public.customers_groups OWNER TO postgres;

--
-- Name: customers_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_groups_id_seq OWNER TO postgres;

--
-- Name: customers_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_groups_id_seq OWNED BY public.customers_groups.id;


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: customers_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers_services (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    service_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customers_services OWNER TO postgres;

--
-- Name: TABLE customers_services; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.customers_services IS 'Таблица связи между компаниями и сервисами';


--
-- Name: COLUMN customers_services.customer_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.customers_services.customer_id IS 'ID компании';


--
-- Name: COLUMN customers_services.service_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.customers_services.service_id IS 'ID сервиса';


--
-- Name: customers_services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_services_id_seq OWNER TO postgres;

--
-- Name: customers_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_services_id_seq OWNED BY public.customers_services.id;


--
-- Name: dynamic_fields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamic_fields (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    label character varying(255),
    field_type character varying(255),
    default_value character varying(255),
    is_required boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dynamic_fields OWNER TO postgres;

--
-- Name: dynamic_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dynamic_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dynamic_fields_id_seq OWNER TO postgres;

--
-- Name: dynamic_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dynamic_fields_id_seq OWNED BY public.dynamic_fields.id;


--
-- Name: dynamic_fields_screens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamic_fields_screens (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    screen_name character varying(255),
    field_name character varying(255),
    field_type character varying(255),
    is_required boolean DEFAULT false,
    "position" integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dynamic_fields_screens OWNER TO postgres;

--
-- Name: dynamic_fields_screens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dynamic_fields_screens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dynamic_fields_screens_id_seq OWNER TO postgres;

--
-- Name: dynamic_fields_screens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dynamic_fields_screens_id_seq OWNED BY public.dynamic_fields_screens.id;


--
-- Name: dynamicfields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamicfields (
    id integer NOT NULL,
    name character varying(255),
    label character varying(255),
    fieldtype character varying(255),
    defaultvalue character varying(255),
    isrequired boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status integer DEFAULT 1,
    is_active boolean DEFAULT true
);


ALTER TABLE public.dynamicfields OWNER TO postgres;

--
-- Name: dynamicfields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dynamicfields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dynamicfields_id_seq OWNER TO postgres;

--
-- Name: dynamicfields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dynamicfields_id_seq OWNED BY public.dynamicfields.id;


--
-- Name: email_addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_addresses (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    queue_id integer
);


ALTER TABLE public.email_addresses OWNER TO postgres;

--
-- Name: COLUMN email_addresses.queue_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_addresses.queue_id IS 'ID связанной очереди';


--
-- Name: email_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_addresses_id_seq OWNER TO postgres;

--
-- Name: email_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_addresses_id_seq OWNED BY public.email_addresses.id;


--
-- Name: general_catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.general_catalog (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.general_catalog OWNER TO postgres;

--
-- Name: general_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.general_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.general_catalog_id_seq OWNER TO postgres;

--
-- Name: general_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.general_catalog_id_seq OWNED BY public.general_catalog.id;


--
-- Name: generic_agent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generic_agent (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    trigger_type character varying(255),
    schedule character varying(255),
    last_run character varying(255),
    next_run character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.generic_agent OWNER TO postgres;

--
-- Name: generic_agent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.generic_agent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.generic_agent_id_seq OWNER TO postgres;

--
-- Name: generic_agent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.generic_agent_id_seq OWNED BY public.generic_agent.id;


--
-- Name: greetings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.greetings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    content text
);


ALTER TABLE public.greetings OWNER TO postgres;

--
-- Name: greetings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.greetings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.greetings_id_seq OWNER TO postgres;

--
-- Name: greetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.greetings_id_seq OWNED BY public.greetings.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.groups_id_seq OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: oauth2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth2 (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    client_id character varying(255),
    client_secret character varying(255),
    authorization_url character varying(255),
    token_url character varying(255),
    scopes text[],
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.oauth2 OWNER TO postgres;

--
-- Name: oauth2_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.oauth2_id_seq OWNER TO postgres;

--
-- Name: oauth2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth2_id_seq OWNED BY public.oauth2.id;


--
-- Name: package_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.package_manager (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    version character varying(255),
    author character varying(255),
    is_installed boolean DEFAULT false,
    is_upgradable boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.package_manager OWNER TO postgres;

--
-- Name: package_manager_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.package_manager_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.package_manager_id_seq OWNER TO postgres;

--
-- Name: package_manager_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.package_manager_id_seq OWNED BY public.package_manager.id;


--
-- Name: performance_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.performance_log (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.performance_log OWNER TO postgres;

--
-- Name: performance_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.performance_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.performance_log_id_seq OWNER TO postgres;

--
-- Name: performance_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.performance_log_id_seq OWNED BY public.performance_log.id;


--
-- Name: pgp_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pgp_keys (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pgp_keys OWNER TO postgres;

--
-- Name: pgp_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pgp_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pgp_keys_id_seq OWNER TO postgres;

--
-- Name: pgp_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pgp_keys_id_seq OWNED BY public.pgp_keys.id;


--
-- Name: post_master_filters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post_master_filters (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.post_master_filters OWNER TO postgres;

--
-- Name: post_master_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_master_filters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.post_master_filters_id_seq OWNER TO postgres;

--
-- Name: post_master_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.post_master_filters_id_seq OWNED BY public.post_master_filters.id;


--
-- Name: post_master_mail_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post_master_mail_accounts (
    id integer NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying(20) DEFAULT 'IMAP'::character varying NOT NULL,
    authentication_type character varying(50) DEFAULT 'password'::character varying NOT NULL,
    login character varying(255) DEFAULT ''::character varying NOT NULL,
    password character varying(500),
    host character varying(255) DEFAULT ''::character varying NOT NULL,
    imap_folder character varying(255),
    trusted boolean DEFAULT false NOT NULL,
    dispatching_by character varying(20) DEFAULT 'Queue'::character varying NOT NULL,
    queue_id integer,
    comment text,
    oauth2_token_config_id integer
);


ALTER TABLE public.post_master_mail_accounts OWNER TO postgres;

--
-- Name: COLUMN post_master_mail_accounts.type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.type IS 'Тип протокола: IMAP, IMAPS, IMAPTLS, MSGraph, POP3, POP3S, POP3TLS';


--
-- Name: COLUMN post_master_mail_accounts.authentication_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.authentication_type IS 'Тип аутентификации: oauth2_token или password';


--
-- Name: COLUMN post_master_mail_accounts.login; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.login IS 'Логин для подключения к почтовому серверу';


--
-- Name: COLUMN post_master_mail_accounts.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.password IS 'Пароль для подключения (зашифрованный)';


--
-- Name: COLUMN post_master_mail_accounts.host; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.host IS 'Адрес почтового сервера';


--
-- Name: COLUMN post_master_mail_accounts.imap_folder; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.imap_folder IS 'Папка IMAP для получения сообщений (опционально)';


--
-- Name: COLUMN post_master_mail_accounts.trusted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.trusted IS 'Доверенный аккаунт';


--
-- Name: COLUMN post_master_mail_accounts.dispatching_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.dispatching_by IS 'Метод маршрутизации: Queue или From';


--
-- Name: COLUMN post_master_mail_accounts.queue_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.queue_id IS 'ID очереди для маршрутизации';


--
-- Name: COLUMN post_master_mail_accounts.comment; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.comment IS 'Комментарий к аккаунту';


--
-- Name: COLUMN post_master_mail_accounts.oauth2_token_config_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.post_master_mail_accounts.oauth2_token_config_id IS 'ID конфигурации OAuth2 токена';


--
-- Name: post_master_mail_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_master_mail_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.post_master_mail_accounts_id_seq OWNER TO postgres;

--
-- Name: post_master_mail_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.post_master_mail_accounts_id_seq OWNED BY public.post_master_mail_accounts.id;


--
-- Name: priorities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.priorities (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(7),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.priorities OWNER TO postgres;

--
-- Name: priorities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.priorities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.priorities_id_seq OWNER TO postgres;

--
-- Name: priorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.priorities_id_seq OWNED BY public.priorities.id;


--
-- Name: process_management; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.process_management (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    process_type character varying(255),
    last_executed character varying(255),
    next_execution character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.process_management OWNER TO postgres;

--
-- Name: process_management_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.process_management_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.process_management_id_seq OWNER TO postgres;

--
-- Name: process_management_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.process_management_id_seq OWNED BY public.process_management.id;


--
-- Name: processes_automation_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.processes_automation_settings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.processes_automation_settings OWNER TO postgres;

--
-- Name: processes_automation_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.processes_automation_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.processes_automation_settings_id_seq OWNER TO postgres;

--
-- Name: processes_automation_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.processes_automation_settings_id_seq OWNED BY public.processes_automation_settings.id;


--
-- Name: queue_auto_response; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.queue_auto_response (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.queue_auto_response OWNER TO postgres;

--
-- Name: queue_auto_response_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.queue_auto_response_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.queue_auto_response_id_seq OWNER TO postgres;

--
-- Name: queue_auto_response_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.queue_auto_response_id_seq OWNED BY public.queue_auto_response.id;


--
-- Name: queues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.queues (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    max_tickets integer,
    priority integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    template_id integer,
    company_id integer,
    service_id integer,
    sla_id integer,
    workflow_id integer,
    agent_group_id integer,
    priority_id integer,
    email_config jsonb DEFAULT '{}'::jsonb,
    keywords text[],
    auto_response_template text
);


ALTER TABLE public.queues OWNER TO postgres;

--
-- Name: COLUMN queues.template_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.template_id IS 'ID шаблона, связанного с очередью';


--
-- Name: COLUMN queues.company_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.company_id IS 'Ссылка на компанию (customers)';


--
-- Name: COLUMN queues.service_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.service_id IS 'Ссылка на сервис (services)';


--
-- Name: COLUMN queues.sla_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.sla_id IS 'Ссылка на SLA (sla)';


--
-- Name: COLUMN queues.workflow_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.workflow_id IS 'Ссылка на рабочий процесс (workflows)';


--
-- Name: COLUMN queues.agent_group_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.agent_group_id IS 'Ссылка на группу агентов (agents_groups)';


--
-- Name: COLUMN queues.priority_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.priority_id IS 'Приоритет по умолчанию (priorities)';


--
-- Name: COLUMN queues.email_config; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.email_config IS 'Конфигурация почты для очереди (JSONB)';


--
-- Name: COLUMN queues.keywords; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.keywords IS 'Ключевые слова для авто-маршрутизации';


--
-- Name: COLUMN queues.auto_response_template; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.queues.auto_response_template IS 'Шаблон авто-ответа';


--
-- Name: queues_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.queues_id_seq OWNER TO postgres;

--
-- Name: queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.queues_id_seq OWNED BY public.queues.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles_groups OWNER TO postgres;

--
-- Name: roles_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_groups_id_seq OWNER TO postgres;

--
-- Name: roles_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_groups_id_seq OWNED BY public.roles_groups.id;


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: service_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_attachments (
    id integer NOT NULL,
    service_id integer NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer,
    mime_type character varying(255),
    uploaded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.service_attachments OWNER TO postgres;

--
-- Name: TABLE service_attachments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.service_attachments IS 'Таблица вложений для сервисов';


--
-- Name: COLUMN service_attachments.service_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.service_attachments.service_id IS 'ID сервиса';


--
-- Name: COLUMN service_attachments.file_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.service_attachments.file_name IS 'Оригинальное имя файла';


--
-- Name: COLUMN service_attachments.file_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.service_attachments.file_path IS 'Путь к файлу на сервере';


--
-- Name: COLUMN service_attachments.file_size; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.service_attachments.file_size IS 'Размер файла в байтах';


--
-- Name: COLUMN service_attachments.mime_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.service_attachments.mime_type IS 'MIME-тип файла';


--
-- Name: COLUMN service_attachments.uploaded_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.service_attachments.uploaded_by IS 'ID пользователя, загрузившего файл';


--
-- Name: service_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_attachments_id_seq OWNER TO postgres;

--
-- Name: service_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_attachments_id_seq OWNED BY public.service_attachments.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying(255),
    sla_id integer
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: services_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services_attachments (
    id integer NOT NULL,
    service_id integer NOT NULL,
    attachment_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.services_attachments OWNER TO postgres;

--
-- Name: TABLE services_attachments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.services_attachments IS 'Таблица связи между сервисами и вложениями';


--
-- Name: COLUMN services_attachments.service_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.services_attachments.service_id IS 'ID сервиса';


--
-- Name: COLUMN services_attachments.attachment_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.services_attachments.attachment_id IS 'ID вложения';


--
-- Name: services_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_attachments_id_seq OWNER TO postgres;

--
-- Name: services_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_attachments_id_seq OWNED BY public.services_attachments.id;


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.services_id_seq OWNER TO postgres;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: session_management; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session_management (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    ip_address character varying(255),
    user_agent character varying(255),
    login_time character varying(255),
    last_activity character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.session_management OWNER TO postgres;

--
-- Name: session_management_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.session_management_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.session_management_id_seq OWNER TO postgres;

--
-- Name: session_management_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.session_management_id_seq OWNED BY public.session_management.id;


--
-- Name: signatures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.signatures (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    comment text
);


ALTER TABLE public.signatures OWNER TO postgres;

--
-- Name: signatures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.signatures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.signatures_id_seq OWNER TO postgres;

--
-- Name: signatures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.signatures_id_seq OWNED BY public.signatures.id;


--
-- Name: sla; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sla (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    response_time numeric(10,2),
    resolution_time numeric(10,2),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    calendar_id integer,
    notification_percentage integer DEFAULT 0,
    type character varying(255),
    solution_time integer DEFAULT 0,
    min_incident_time integer DEFAULT 10,
    response_notification integer DEFAULT 20,
    update_notification integer DEFAULT 80,
    solution_notification integer DEFAULT 80
);


ALTER TABLE public.sla OWNER TO postgres;

--
-- Name: sla_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sla_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sla_id_seq OWNER TO postgres;

--
-- Name: sla_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sla_id_seq OWNED BY public.sla.id;


--
-- Name: sla_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sla_services (
    id integer NOT NULL,
    sla_id integer NOT NULL,
    service_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sla_services OWNER TO postgres;

--
-- Name: sla_services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sla_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sla_services_id_seq OWNER TO postgres;

--
-- Name: sla_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sla_services_id_seq OWNED BY public.sla_services.id;


--
-- Name: smime_certificates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.smime_certificates (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.smime_certificates OWNER TO postgres;

--
-- Name: smime_certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.smime_certificates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.smime_certificates_id_seq OWNER TO postgres;

--
-- Name: smime_certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.smime_certificates_id_seq OWNED BY public.smime_certificates.id;


--
-- Name: sql_box; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sql_box (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sql_box OWNER TO postgres;

--
-- Name: sql_box_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sql_box_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sql_box_id_seq OWNER TO postgres;

--
-- Name: sql_box_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sql_box_id_seq OWNED BY public.sql_box.id;


--
-- Name: state_transitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.state_transitions (
    id integer NOT NULL,
    type_id integer,
    from_state_id integer,
    to_state_id integer NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    sort_order integer DEFAULT 0
);


ALTER TABLE public.state_transitions OWNER TO postgres;

--
-- Name: TABLE state_transitions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.state_transitions IS 'Переходы между статусами для типов инцидентов';


--
-- Name: COLUMN state_transitions.type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.type_id IS 'Тип инцидента (NULL = для всех типов)';


--
-- Name: COLUMN state_transitions.from_state_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.from_state_id IS 'Исходный статус (NULL = начальный статус для нового тикета)';


--
-- Name: COLUMN state_transitions.to_state_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.to_state_id IS 'Целевой статус';


--
-- Name: COLUMN state_transitions.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.name IS 'Название перехода (например: "Открыть", "Закрыть", "В работу")';


--
-- Name: COLUMN state_transitions.is_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.state_transitions.is_active IS 'Активен ли переход';


--
-- Name: state_transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.state_transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.state_transitions_id_seq OWNER TO postgres;

--
-- Name: state_transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.state_transitions_id_seq OWNED BY public.state_transitions.id;


--
-- Name: states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.states (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying(255),
    color character varying(7),
    type_id integer,
    is_initial boolean DEFAULT false
);


ALTER TABLE public.states OWNER TO postgres;

--
-- Name: COLUMN states.is_initial; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.states.is_initial IS 'Является ли статус начальным по умолчанию';


--
-- Name: states_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.states_id_seq OWNER TO postgres;

--
-- Name: states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.states_id_seq OWNED BY public.states.id;


--
-- Name: support_data_collector; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_data_collector (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.support_data_collector OWNER TO postgres;

--
-- Name: support_data_collector_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_data_collector_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_data_collector_id_seq OWNER TO postgres;

--
-- Name: support_data_collector_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_data_collector_id_seq OWNED BY public.support_data_collector.id;


--
-- Name: system_configuration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_configuration (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    value character varying(255),
    config_type character varying(255),
    is_editable boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_configuration OWNER TO postgres;

--
-- Name: system_configuration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_configuration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_configuration_id_seq OWNER TO postgres;

--
-- Name: system_configuration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_configuration_id_seq OWNED BY public.system_configuration.id;


--
-- Name: system_file_support; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_file_support (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_file_support OWNER TO postgres;

--
-- Name: system_file_support_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_file_support_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_file_support_id_seq OWNER TO postgres;

--
-- Name: system_file_support_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_file_support_id_seq OWNED BY public.system_file_support.id;


--
-- Name: system_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_log (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_log OWNER TO postgres;

--
-- Name: system_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_log_id_seq OWNER TO postgres;

--
-- Name: system_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_log_id_seq OWNED BY public.system_log.id;


--
-- Name: system_maintenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_maintenance (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    start_time character varying(255),
    end_time character varying(255),
    is_scheduled boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_maintenance OWNER TO postgres;

--
-- Name: system_maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_maintenance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_maintenance_id_seq OWNER TO postgres;

--
-- Name: system_maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_maintenance_id_seq OWNED BY public.system_maintenance.id;


--
-- Name: template_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.template_attachments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.template_attachments OWNER TO postgres;

--
-- Name: template_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.template_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.template_attachments_id_seq OWNER TO postgres;

--
-- Name: template_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.template_attachments_id_seq OWNED BY public.template_attachments.id;


--
-- Name: template_queues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.template_queues (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.template_queues OWNER TO postgres;

--
-- Name: template_queues_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.template_queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.template_queues_id_seq OWNER TO postgres;

--
-- Name: template_queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.template_queues_id_seq OWNED BY public.template_queues.id;


--
-- Name: templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.templates (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.templates OWNER TO postgres;

--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.templates_id_seq OWNER TO postgres;

--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- Name: test_entities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_entities (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.test_entities OWNER TO postgres;

--
-- Name: test_entities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_entities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_entities_id_seq OWNER TO postgres;

--
-- Name: test_entities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_entities_id_seq OWNED BY public.test_entities.id;


--
-- Name: ticket_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_attachments (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer,
    mime_type character varying(100),
    uploaded_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_attachments OWNER TO postgres;

--
-- Name: TABLE ticket_attachments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ticket_attachments IS 'Вложения к тикетам';


--
-- Name: COLUMN ticket_attachments.file_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_attachments.file_name IS 'Имя файла';


--
-- Name: COLUMN ticket_attachments.file_path; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_attachments.file_path IS 'Путь к файлу на сервере';


--
-- Name: COLUMN ticket_attachments.file_size; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_attachments.file_size IS 'Размер файла в байтах';


--
-- Name: COLUMN ticket_attachments.mime_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_attachments.mime_type IS 'MIME-тип файла';


--
-- Name: ticket_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_attachments_id_seq OWNER TO postgres;

--
-- Name: ticket_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_attachments_id_seq OWNED BY public.ticket_attachments.id;


--
-- Name: ticket_attribute_relations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_attribute_relations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    source_attribute character varying(255),
    target_attribute character varying(255),
    relation_type character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_attribute_relations OWNER TO postgres;

--
-- Name: ticket_attribute_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_attribute_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_attribute_relations_id_seq OWNER TO postgres;

--
-- Name: ticket_attribute_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_attribute_relations_id_seq OWNED BY public.ticket_attribute_relations.id;


--
-- Name: ticket_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_comments (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    author_id integer,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_internal boolean DEFAULT false
);


ALTER TABLE public.ticket_comments OWNER TO postgres;

--
-- Name: TABLE ticket_comments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ticket_comments IS 'Комментарии к тикетам (внутренние, только для агентов)';


--
-- Name: COLUMN ticket_comments.ticket_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_comments.ticket_id IS 'Ссылка на тикет';


--
-- Name: COLUMN ticket_comments.author_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_comments.author_id IS 'Автор комментария (агент)';


--
-- Name: COLUMN ticket_comments.content; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_comments.content IS 'Текст комментария';


--
-- Name: COLUMN ticket_comments.is_internal; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_comments.is_internal IS 'true = внутренний комментарий (только для агентов), false = внешний комментарий (публичный)';


--
-- Name: ticket_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_comments_id_seq OWNER TO postgres;

--
-- Name: ticket_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_comments_id_seq OWNED BY public.ticket_comments.id;


--
-- Name: ticket_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_history (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    changed_by integer,
    field_name character varying(100) NOT NULL,
    old_value text,
    new_value text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_history OWNER TO postgres;

--
-- Name: TABLE ticket_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ticket_history IS 'История изменений тикетов';


--
-- Name: COLUMN ticket_history.field_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_history.field_name IS 'Имя измененного поля';


--
-- Name: COLUMN ticket_history.old_value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_history.old_value IS 'Старое значение';


--
-- Name: COLUMN ticket_history.new_value; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_history.new_value IS 'Новое значение';


--
-- Name: ticket_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_history_id_seq OWNER TO postgres;

--
-- Name: ticket_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_history_id_seq OWNED BY public.ticket_history.id;


--
-- Name: ticket_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_notifications (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ticket_notifications OWNER TO postgres;

--
-- Name: ticket_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_notifications_id_seq OWNER TO postgres;

--
-- Name: ticket_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_notifications_id_seq OWNED BY public.ticket_notifications.id;


--
-- Name: ticket_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_number_seq
    START WITH 1000001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_number_seq OWNER TO postgres;

--
-- Name: ticket_status_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_status_history (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    from_status_id integer,
    to_status_id integer NOT NULL,
    transition_id integer,
    changed_by integer,
    comment text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    transition_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    time_in_previous_status interval,
    action_label character varying(255)
);


ALTER TABLE public.ticket_status_history OWNER TO postgres;

--
-- Name: TABLE ticket_status_history; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ticket_status_history IS 'История переходов статусов тикетов';


--
-- Name: COLUMN ticket_status_history.ticket_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_status_history.ticket_id IS 'ID тикета';


--
-- Name: COLUMN ticket_status_history.from_status_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_status_history.from_status_id IS 'Исходный статус (NULL для начального статуса)';


--
-- Name: COLUMN ticket_status_history.to_status_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_status_history.to_status_id IS 'Новый статус';


--
-- Name: COLUMN ticket_status_history.transition_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_status_history.transition_id IS 'ID перехода из workflow_transitions (для аудита)';


--
-- Name: COLUMN ticket_status_history.changed_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_status_history.changed_by IS 'Кто изменил статус';


--
-- Name: COLUMN ticket_status_history.comment; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ticket_status_history.comment IS 'Комментарий при смене статуса';


--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_status_history_id_seq OWNER TO postgres;

--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_status_history_id_seq OWNED BY public.ticket_status_history.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tickets (
    id integer NOT NULL,
    ticket_number character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    type_id integer,
    priority_id integer,
    queue_id integer,
    state_id integer,
    owner_id integer,
    company_id integer,
    sla_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    description text,
    response_deadline timestamp without time zone,
    resolution_deadline timestamp without time zone,
    first_response_at timestamp without time zone,
    sla_violated boolean DEFAULT false,
    pending_start_at timestamp without time zone,
    service_id integer
);


ALTER TABLE public.tickets OWNER TO postgres;

--
-- Name: TABLE tickets; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tickets IS 'Тикеты системы поддержки';


--
-- Name: COLUMN tickets.ticket_number; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.ticket_number IS 'Номер тикета';


--
-- Name: COLUMN tickets.title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.title IS 'Заголовок тикета';


--
-- Name: COLUMN tickets.type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.type_id IS 'Тип тикета (ссылка на types)';


--
-- Name: COLUMN tickets.priority_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.priority_id IS 'Приоритет (ссылка на priorities)';


--
-- Name: COLUMN tickets.queue_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.queue_id IS 'Очередь (ссылка на queues)';


--
-- Name: COLUMN tickets.state_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.state_id IS 'Статус (ссылка на states)';


--
-- Name: COLUMN tickets.owner_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.owner_id IS 'Владелец/создатель (ссылка на agents)';


--
-- Name: COLUMN tickets.company_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.company_id IS 'Компания (ссылка на customers)';


--
-- Name: COLUMN tickets.sla_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.sla_id IS 'SLA (ссылка на sla)';


--
-- Name: COLUMN tickets.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.description IS 'Описание тикета (rich text)';


--
-- Name: COLUMN tickets.response_deadline; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.response_deadline IS 'Крайний срок первого ответа';


--
-- Name: COLUMN tickets.resolution_deadline; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.resolution_deadline IS 'Крайний срок решения тикета';


--
-- Name: COLUMN tickets.first_response_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.first_response_at IS 'Время первого ответа на тикет';


--
-- Name: COLUMN tickets.sla_violated; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.sla_violated IS 'Нарушен ли SLA';


--
-- Name: COLUMN tickets.pending_start_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tickets.pending_start_at IS 'Начало ожидания от клиента';


--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tickets_id_seq OWNER TO postgres;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: translation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.translation (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.translation OWNER TO postgres;

--
-- Name: translation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.translation_id_seq OWNER TO postgres;

--
-- Name: translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.translation_id_seq OWNED BY public.translation.id;


--
-- Name: types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    workflow_id integer
);


ALTER TABLE public.types OWNER TO postgres;

--
-- Name: COLUMN types.workflow_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.types.workflow_id IS 'ID воркфлоу, определяющего жизненный цикл для этого типа тикетов';


--
-- Name: types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.types_id_seq OWNER TO postgres;

--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.types_id_seq OWNED BY public.types.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    email character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_groups_roles_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_groups_roles_settings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users_groups_roles_settings OWNER TO postgres;

--
-- Name: users_groups_roles_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_groups_roles_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_groups_roles_settings_id_seq OWNER TO postgres;

--
-- Name: users_groups_roles_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_groups_roles_settings_id_seq OWNED BY public.users_groups_roles_settings.id;


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: web_services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.web_services (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    endpoint character varying(255),
    method character varying(255),
    last_tested character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.web_services OWNER TO postgres;

--
-- Name: web_services_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.web_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.web_services_id_seq OWNER TO postgres;

--
-- Name: web_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.web_services_id_seq OWNED BY public.web_services.id;


--
-- Name: workflow_transitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_transitions (
    id integer NOT NULL,
    workflow_id integer NOT NULL,
    source_status_id integer,
    target_status_id integer NOT NULL,
    action_label character varying(255) NOT NULL,
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.workflow_transitions OWNER TO postgres;

--
-- Name: TABLE workflow_transitions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.workflow_transitions IS 'Правила переходов между статусами';


--
-- Name: COLUMN workflow_transitions.workflow_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.workflow_transitions.workflow_id IS 'ID воркфлоу, к которому относится переход';


--
-- Name: COLUMN workflow_transitions.source_status_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.workflow_transitions.source_status_id IS 'Исходный статус (NULL = начальный статус для нового тикета)';


--
-- Name: COLUMN workflow_transitions.target_status_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.workflow_transitions.target_status_id IS 'Целевой статус (обязательно)';


--
-- Name: COLUMN workflow_transitions.action_label; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.workflow_transitions.action_label IS 'Текст кнопки действия (например: "Взять в работу", "Закрыть")';


--
-- Name: COLUMN workflow_transitions.sort_order; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.workflow_transitions.sort_order IS 'Порядок отображения кнопок';


--
-- Name: workflow_transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workflow_transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_transitions_id_seq OWNER TO postgres;

--
-- Name: workflow_transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workflow_transitions_id_seq OWNED BY public.workflow_transitions.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.workflows OWNER TO postgres;

--
-- Name: TABLE workflows; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.workflows IS 'Логические группы правил для управления жизненным циклом тикетов';


--
-- Name: COLUMN workflows.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.workflows.name IS 'Название воркфлоу (например: Bug Workflow, Incident Workflow)';


--
-- Name: COLUMN workflows.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.workflows.description IS 'Описание назначения воркфлоу';


--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO postgres;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: acl id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acl ALTER COLUMN id SET DEFAULT nextval('public.acl_id_seq'::regclass);


--
-- Name: acls id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acls ALTER COLUMN id SET DEFAULT nextval('public.acls_id_seq'::regclass);


--
-- Name: admin_notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_notification ALTER COLUMN id SET DEFAULT nextval('public.admin_notification_id_seq'::regclass);


--
-- Name: admin_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_notifications ALTER COLUMN id SET DEFAULT nextval('public.admin_notifications_id_seq'::regclass);


--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: agents_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups ALTER COLUMN id SET DEFAULT nextval('public.agents_groups_id_seq'::regclass);


--
-- Name: agents_groups_agents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_agents ALTER COLUMN id SET DEFAULT nextval('public.agents_groups_agents_id_seq'::regclass);


--
-- Name: agents_queues id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_queues ALTER COLUMN id SET DEFAULT nextval('public.agents_queues_id_seq'::regclass);


--
-- Name: agents_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_roles ALTER COLUMN id SET DEFAULT nextval('public.agents_roles_id_seq'::regclass);


--
-- Name: appointment_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment_notifications ALTER COLUMN id SET DEFAULT nextval('public.appointment_notifications_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: auto_responses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auto_responses ALTER COLUMN id SET DEFAULT nextval('public.auto_responses_id_seq'::regclass);


--
-- Name: calendar_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar_events ALTER COLUMN id SET DEFAULT nextval('public.calendar_events_id_seq'::regclass);


--
-- Name: calendars id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendars ALTER COLUMN id SET DEFAULT nextval('public.calendars_id_seq'::regclass);


--
-- Name: communication_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_log ALTER COLUMN id SET DEFAULT nextval('public.communication_log_id_seq'::regclass);


--
-- Name: communication_notifications_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_notifications_settings ALTER COLUMN id SET DEFAULT nextval('public.communication_notifications_settings_id_seq'::regclass);


--
-- Name: customer_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users ALTER COLUMN id SET DEFAULT nextval('public.customer_users_id_seq'::regclass);


--
-- Name: customer_users_customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_customers ALTER COLUMN id SET DEFAULT nextval('public.customer_users_customers_id_seq'::regclass);


--
-- Name: customer_users_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_groups ALTER COLUMN id SET DEFAULT nextval('public.customer_users_groups_id_seq'::regclass);


--
-- Name: customer_users_services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_services ALTER COLUMN id SET DEFAULT nextval('public.customer_users_services_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: customers_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_groups ALTER COLUMN id SET DEFAULT nextval('public.customers_groups_id_seq'::regclass);


--
-- Name: customers_services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_services ALTER COLUMN id SET DEFAULT nextval('public.customers_services_id_seq'::regclass);


--
-- Name: dynamic_fields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_fields ALTER COLUMN id SET DEFAULT nextval('public.dynamic_fields_id_seq'::regclass);


--
-- Name: dynamic_fields_screens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_fields_screens ALTER COLUMN id SET DEFAULT nextval('public.dynamic_fields_screens_id_seq'::regclass);


--
-- Name: dynamicfields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamicfields ALTER COLUMN id SET DEFAULT nextval('public.dynamicfields_id_seq'::regclass);


--
-- Name: email_addresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_addresses ALTER COLUMN id SET DEFAULT nextval('public.email_addresses_id_seq'::regclass);


--
-- Name: general_catalog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.general_catalog ALTER COLUMN id SET DEFAULT nextval('public.general_catalog_id_seq'::regclass);


--
-- Name: generic_agent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generic_agent ALTER COLUMN id SET DEFAULT nextval('public.generic_agent_id_seq'::regclass);


--
-- Name: greetings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.greetings ALTER COLUMN id SET DEFAULT nextval('public.greetings_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: oauth2 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth2 ALTER COLUMN id SET DEFAULT nextval('public.oauth2_id_seq'::regclass);


--
-- Name: package_manager id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package_manager ALTER COLUMN id SET DEFAULT nextval('public.package_manager_id_seq'::regclass);


--
-- Name: performance_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_log ALTER COLUMN id SET DEFAULT nextval('public.performance_log_id_seq'::regclass);


--
-- Name: pgp_keys id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pgp_keys ALTER COLUMN id SET DEFAULT nextval('public.pgp_keys_id_seq'::regclass);


--
-- Name: post_master_filters id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_filters ALTER COLUMN id SET DEFAULT nextval('public.post_master_filters_id_seq'::regclass);


--
-- Name: post_master_mail_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_mail_accounts ALTER COLUMN id SET DEFAULT nextval('public.post_master_mail_accounts_id_seq'::regclass);


--
-- Name: priorities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities ALTER COLUMN id SET DEFAULT nextval('public.priorities_id_seq'::regclass);


--
-- Name: process_management id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_management ALTER COLUMN id SET DEFAULT nextval('public.process_management_id_seq'::regclass);


--
-- Name: processes_automation_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processes_automation_settings ALTER COLUMN id SET DEFAULT nextval('public.processes_automation_settings_id_seq'::regclass);


--
-- Name: queue_auto_response id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queue_auto_response ALTER COLUMN id SET DEFAULT nextval('public.queue_auto_response_id_seq'::regclass);


--
-- Name: queues id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues ALTER COLUMN id SET DEFAULT nextval('public.queues_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: roles_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles_groups ALTER COLUMN id SET DEFAULT nextval('public.roles_groups_id_seq'::regclass);


--
-- Name: service_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_attachments ALTER COLUMN id SET DEFAULT nextval('public.service_attachments_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: services_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services_attachments ALTER COLUMN id SET DEFAULT nextval('public.services_attachments_id_seq'::regclass);


--
-- Name: session_management id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_management ALTER COLUMN id SET DEFAULT nextval('public.session_management_id_seq'::regclass);


--
-- Name: signatures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signatures ALTER COLUMN id SET DEFAULT nextval('public.signatures_id_seq'::regclass);


--
-- Name: sla id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla ALTER COLUMN id SET DEFAULT nextval('public.sla_id_seq'::regclass);


--
-- Name: sla_services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla_services ALTER COLUMN id SET DEFAULT nextval('public.sla_services_id_seq'::regclass);


--
-- Name: smime_certificates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smime_certificates ALTER COLUMN id SET DEFAULT nextval('public.smime_certificates_id_seq'::regclass);


--
-- Name: sql_box id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sql_box ALTER COLUMN id SET DEFAULT nextval('public.sql_box_id_seq'::regclass);


--
-- Name: state_transitions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state_transitions ALTER COLUMN id SET DEFAULT nextval('public.state_transitions_id_seq'::regclass);


--
-- Name: states id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.states ALTER COLUMN id SET DEFAULT nextval('public.states_id_seq'::regclass);


--
-- Name: support_data_collector id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_data_collector ALTER COLUMN id SET DEFAULT nextval('public.support_data_collector_id_seq'::regclass);


--
-- Name: system_configuration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_configuration ALTER COLUMN id SET DEFAULT nextval('public.system_configuration_id_seq'::regclass);


--
-- Name: system_file_support id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_file_support ALTER COLUMN id SET DEFAULT nextval('public.system_file_support_id_seq'::regclass);


--
-- Name: system_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_log ALTER COLUMN id SET DEFAULT nextval('public.system_log_id_seq'::regclass);


--
-- Name: system_maintenance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_maintenance ALTER COLUMN id SET DEFAULT nextval('public.system_maintenance_id_seq'::regclass);


--
-- Name: template_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_attachments ALTER COLUMN id SET DEFAULT nextval('public.template_attachments_id_seq'::regclass);


--
-- Name: template_queues id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_queues ALTER COLUMN id SET DEFAULT nextval('public.template_queues_id_seq'::regclass);


--
-- Name: templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- Name: test_entities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_entities ALTER COLUMN id SET DEFAULT nextval('public.test_entities_id_seq'::regclass);


--
-- Name: ticket_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attachments ALTER COLUMN id SET DEFAULT nextval('public.ticket_attachments_id_seq'::regclass);


--
-- Name: ticket_attribute_relations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attribute_relations ALTER COLUMN id SET DEFAULT nextval('public.ticket_attribute_relations_id_seq'::regclass);


--
-- Name: ticket_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_comments ALTER COLUMN id SET DEFAULT nextval('public.ticket_comments_id_seq'::regclass);


--
-- Name: ticket_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_history ALTER COLUMN id SET DEFAULT nextval('public.ticket_history_id_seq'::regclass);


--
-- Name: ticket_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_notifications ALTER COLUMN id SET DEFAULT nextval('public.ticket_notifications_id_seq'::regclass);


--
-- Name: ticket_status_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history ALTER COLUMN id SET DEFAULT nextval('public.ticket_status_history_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: translation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.translation ALTER COLUMN id SET DEFAULT nextval('public.translation_id_seq'::regclass);


--
-- Name: types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types ALTER COLUMN id SET DEFAULT nextval('public.types_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: users_groups_roles_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_groups_roles_settings ALTER COLUMN id SET DEFAULT nextval('public.users_groups_roles_settings_id_seq'::regclass);


--
-- Name: web_services id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_services ALTER COLUMN id SET DEFAULT nextval('public.web_services_id_seq'::regclass);


--
-- Name: workflow_transitions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_transitions ALTER COLUMN id SET DEFAULT nextval('public.workflow_transitions_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: acl; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: acls; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: admin_notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.admin_notification (id, name, message, is_active, created_at, updated_at) VALUES (1, 'екнек', 'некнк', false, '2026-01-18 22:40:16.555182', '2026-01-18 22:43:21.661697');


--
-- Data for Name: admin_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (3, true, '2026-01-29 08:30:29.564632', '2026-01-31 14:57:13.364033', 'Мария', 'Петрова', 'petrova', 'password123', 'petrova@example.com', '+7 (999) 234-56-78', '@petrova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (32, true, '2026-01-30 22:02:39.227825', '2026-01-31 14:57:13.370802', 'Test', 'User', 'uniqueuser1769799759', 'test123', 'unique1769799759@test.com', '+1234567890', '@uniqueuser', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (19, true, '2026-01-30 21:45:14.110552', '2026-01-31 14:57:13.375551', 'Test', 'User', 'testuser2', 'test123', 'test2@test.com', '+1234567890', '@testuser2', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (23, true, '2026-01-30 21:50:52.783191', '2026-01-31 14:57:13.37375', 'Test', 'User', 'testuser1769799052', 'test123', 'test1769799052@test.com', '+1234567890', '@testuser1769799052', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (9, true, '2026-01-29 08:30:29.583532', '2026-01-31 14:57:13.380286', 'Татьяна', 'Федорова', 'fedorova', 'password123', 'fedorova@example.com', '+7 (999) 890-12-34', '@fedorova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (7, true, '2026-01-29 08:30:29.575739', '2026-01-31 14:57:13.383522', 'Ольга', 'Морозова', 'morozova', 'password123', 'morozova@example.com', '+7 (999) 678-90-12', '@morozova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (5, true, '2026-01-29 08:30:29.569848', '2026-01-31 14:57:13.386115', 'Елена', 'Кузнецова', 'kuznetsova', 'password123', 'kuznetsova@example.com', '+7 (999) 456-78-90', '@kuznetsova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (4, true, '2026-01-29 08:30:29.567274', '2026-01-31 14:57:13.39177', 'Алексей', 'Сидоров', 'sidorov', 'password123', 'sidorov@example.com', '+7 (999) 345-67-89', '@sidorov_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (6, true, '2026-01-29 08:30:29.572286', '2026-01-31 14:57:13.394146', 'Дмитрий', 'Васильев', 'vasilev', 'password123', 'vasilev@example.com', '+7 (999) 567-89-01', '@vasilev_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (21, true, '2026-01-30 21:46:58.231262', '2026-01-31 15:19:06.733716', 'Test', 'User', 'testuser1769798818', 'test123', 'test1769798818@test.com', '+1234567890', '@testuser1769798818', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (33, true, '2026-01-31 15:23:48.101295', '2026-01-31 15:23:48.101295', 'Сергей', 'Попов', 'popov', 'password123', 'popov@example.com', '+7 (999) 111-11-11', '@popov_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (34, true, '2026-01-31 15:23:48.109015', '2026-01-31 15:23:48.109015', 'Анна', 'Соколова', 'sokolova', 'password123', 'sokolova@example.com', '+7 (999) 222-22-22', '@sokolova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (35, true, '2026-01-31 15:23:48.112265', '2026-01-31 15:23:48.112265', 'Михаил', 'Лебедев', 'lebedev', 'password123', 'lebedev@example.com', '+7 (999) 333-33-33', '@lebedev_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (36, true, '2026-01-31 15:23:48.119392', '2026-01-31 15:23:48.119392', 'Виктория', 'Козлова', 'kozlova', 'password123', 'kozlova@example.com', '+7 (999) 444-44-44', '@kozlova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (37, true, '2026-01-31 15:23:48.122373', '2026-01-31 15:23:48.122373', 'Николай', 'Новиков', 'novikov_n', 'password123', 'novikov_n@example.com', '+7 (999) 555-55-55', '@novikov_n_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (38, false, '2026-01-31 15:23:48.125526', '2026-01-31 15:23:48.125526', 'Кристина', 'Волкова', 'volkova', 'password123', 'volkova@example.com', '+7 (999) 666-66-66', '@volkova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (39, true, '2026-01-31 15:23:48.128454', '2026-01-31 15:23:48.128454', 'Павел', 'Соловьев', 'soloviev', 'password123', 'soloviev@example.com', '+7 (999) 777-77-77', '@soloviev_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (40, true, '2026-01-31 15:23:48.131279', '2026-01-31 15:23:48.131279', 'Юлия', 'Васильева', 'vasilieva_y', 'password123', 'vasilieva_y@example.com', '+7 (999) 888-88-88', '@vasilieva_y_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (41, true, '2026-01-31 15:23:48.13457', '2026-01-31 15:23:48.13457', 'Артем', 'Зайцев', 'zaitsev', 'password123', 'zaitsev@example.com', '+7 (999) 999-99-99', '@zaitsev_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (42, true, '2026-01-31 15:23:48.13815', '2026-01-31 15:23:48.13815', 'Светлана', 'Павлова', 'pavlova', 'password123', 'pavlova@example.com', '+7 (999) 000-00-00', '@pavlova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (43, true, '2026-01-31 15:26:22.674926', '2026-01-31 15:26:22.674926', 'Владимир', 'Макаров', 'makarov', 'password123', 'makarov@example.com', '+7 (999) 121-21-21', '@makarov_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (44, true, '2026-01-31 15:26:22.682261', '2026-01-31 15:26:22.682261', 'Екатерина', 'Андреева', 'andreeva', 'password123', 'andreeva@example.com', '+7 (999) 232-32-32', '@andreeva_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (45, true, '2026-01-31 15:26:22.686096', '2026-01-31 15:26:22.686096', 'Игорь', 'Морозов', 'morozov_i', 'password123', 'morozov_i@example.com', '+7 (999) 343-43-43', '@morozov_i_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (46, true, '2026-01-31 15:26:22.689276', '2026-01-31 15:26:22.689276', 'Наталья', 'Волкова', 'volkova_n', 'password123', 'volkova_n@example.com', '+7 (999) 454-54-54', '@volkova_n_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (47, false, '2026-01-31 15:26:22.692225', '2026-01-31 15:26:22.692225', 'Александр', 'Лебедев', 'lebedev_a', 'password123', 'lebedev_a@example.com', '+7 (999) 565-65-65', '@lebedev_a_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (48, true, '2026-01-31 15:26:22.695245', '2026-01-31 15:26:22.695245', 'Оксана', 'Семенова', 'semenova', 'password123', 'semenova@example.com', '+7 (999) 676-76-76', '@semenova_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (49, true, '2026-01-31 15:26:22.698071', '2026-01-31 15:26:22.698071', 'Денис', 'Егоров', 'egorov', 'password123', 'egorov@example.com', '+7 (999) 787-87-87', '@egorov_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (50, true, '2026-01-31 15:26:22.70092', '2026-01-31 15:26:22.70092', 'Марина', 'Попова', 'popova_m', 'password123', 'popova_m@example.com', '+7 (999) 898-98-98', '@popova_m_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (51, true, '2026-01-31 15:26:22.703892', '2026-01-31 15:26:22.703892', 'Роман', 'Кузнецов', 'kuznetsov_r', 'password123', 'kuznetsov_r@example.com', '+7 (999) 909-09-09', '@kuznetsov_r_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (52, true, '2026-01-31 15:26:22.707256', '2026-01-31 15:26:22.707256', 'Валерия', 'Николаева', 'nikolaeva', 'password123', 'nikolaeva@example.com', '+7 (999) 010-10-10', '@nikolaeva_agent', NULL);
INSERT INTO public.agents (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, role_id) VALUES (2, true, '2026-01-29 08:30:29.558391', '2026-01-31 20:25:43.70296', 'Иван', 'Иванов', 'ivanov', 'password123', 'ivanov@example.com', '+7 (999) 123-45-67', '@ivanov_agent', NULL);


--
-- Data for Name: agents_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agents_groups (id, name, is_active, created_at, updated_at) VALUES (79, 'dfsdf', true, '2026-02-24 11:40:19.80244', '2026-02-24 14:38:40.72656');


--
-- Data for Name: agents_groups_agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (450, 79, 42, '2026-02-24 14:38:40.771783', '2026-02-24 14:38:40.771783');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (451, 79, 4, '2026-02-24 14:38:40.799061', '2026-02-24 14:38:40.799061');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (452, 79, 34, '2026-02-24 14:38:40.829633', '2026-02-24 14:38:40.829633');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (453, 79, 41, '2026-02-24 14:38:40.858182', '2026-02-24 14:38:40.858182');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (454, 79, 51, '2026-02-24 14:38:40.879904', '2026-02-24 14:38:40.879904');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (455, 79, 40, '2026-02-24 14:38:40.899181', '2026-02-24 14:38:40.899181');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (456, 79, 46, '2026-02-24 14:38:40.93613', '2026-02-24 14:38:40.93613');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (457, 79, 43, '2026-02-24 14:38:40.960996', '2026-02-24 14:38:40.960996');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (458, 79, 52, '2026-02-24 14:38:40.992014', '2026-02-24 14:38:40.992014');
INSERT INTO public.agents_groups_agents (id, agents_group_id, agent_id, created_at, updated_at) VALUES (459, 79, 32, '2026-02-24 14:38:41.027771', '2026-02-24 14:38:41.027771');


--
-- Data for Name: agents_queues; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: agents_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: appointment_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.attachments (id, name, file_name, type, comment, is_active, created_at, updated_at) VALUES (7, 'ПА', 'icons8-docx-file-50.jpg', 1, '', true, '2026-01-23 12:58:43.055493', '2026-01-23 13:02:01.590646');


--
-- Data for Name: auto_responses; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (536, 4, 'Рабочие часы', '2026-01-01 09:00:00', '2026-01-01 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (537, 4, 'Рабочие часы', '2026-01-02 09:00:00', '2026-01-02 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (538, 4, 'Рабочие часы', '2026-01-05 09:00:00', '2026-01-05 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (539, 4, 'Рабочие часы', '2026-01-06 09:00:00', '2026-01-06 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (540, 4, 'Рабочие часы', '2026-01-07 09:00:00', '2026-01-07 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (541, 4, 'Рабочие часы', '2026-01-08 09:00:00', '2026-01-08 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (542, 4, 'Рабочие часы', '2026-01-09 09:00:00', '2026-01-09 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (543, 4, 'Рабочие часы', '2026-01-12 09:00:00', '2026-01-12 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (544, 4, 'Рабочие часы', '2026-01-13 09:00:00', '2026-01-13 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (545, 4, 'Рабочие часы', '2026-01-14 09:00:00', '2026-01-14 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (546, 4, 'Рабочие часы', '2026-01-15 09:00:00', '2026-01-15 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (547, 4, 'Рабочие часы', '2026-01-16 09:00:00', '2026-01-16 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (548, 4, 'Рабочие часы', '2026-01-19 09:00:00', '2026-01-19 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (549, 4, 'Рабочие часы', '2026-01-20 09:00:00', '2026-01-20 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (550, 4, 'Рабочие часы', '2026-01-21 09:00:00', '2026-01-21 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (551, 4, 'Рабочие часы', '2026-01-22 09:00:00', '2026-01-22 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (552, 4, 'Рабочие часы', '2026-01-23 09:00:00', '2026-01-23 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (553, 4, 'Рабочие часы', '2026-01-26 09:00:00', '2026-01-26 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (554, 4, 'Рабочие часы', '2026-01-27 09:00:00', '2026-01-27 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (555, 4, 'Рабочие часы', '2026-01-28 09:00:00', '2026-01-28 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (556, 4, 'Рабочие часы', '2026-01-29 09:00:00', '2026-01-29 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (557, 4, 'Рабочие часы', '2026-01-30 09:00:00', '2026-01-30 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (558, 4, 'Рабочие часы', '2026-02-02 09:00:00', '2026-02-02 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (559, 4, 'Рабочие часы', '2026-02-03 09:00:00', '2026-02-03 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (560, 4, 'Рабочие часы', '2026-02-04 09:00:00', '2026-02-04 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (561, 4, 'Рабочие часы', '2026-02-05 09:00:00', '2026-02-05 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (562, 4, 'Рабочие часы', '2026-02-06 09:00:00', '2026-02-06 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (563, 4, 'Рабочие часы', '2026-02-09 09:00:00', '2026-02-09 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (564, 4, 'Рабочие часы', '2026-02-10 09:00:00', '2026-02-10 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (565, 4, 'Рабочие часы', '2026-02-11 09:00:00', '2026-02-11 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (566, 4, 'Рабочие часы', '2026-02-12 09:00:00', '2026-02-12 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (567, 4, 'Рабочие часы', '2026-02-13 09:00:00', '2026-02-13 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (568, 4, 'Рабочие часы', '2026-02-16 09:00:00', '2026-02-16 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (569, 4, 'Рабочие часы', '2026-02-17 09:00:00', '2026-02-17 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (570, 4, 'Рабочие часы', '2026-02-18 09:00:00', '2026-02-18 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (571, 4, 'Рабочие часы', '2026-02-19 09:00:00', '2026-02-19 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (572, 4, 'Рабочие часы', '2026-02-20 09:00:00', '2026-02-20 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (573, 4, 'Рабочие часы', '2026-02-23 09:00:00', '2026-02-23 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (574, 4, 'Рабочие часы', '2026-02-24 09:00:00', '2026-02-24 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (575, 4, 'Рабочие часы', '2026-02-25 09:00:00', '2026-02-25 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (576, 4, 'Рабочие часы', '2026-02-26 09:00:00', '2026-02-26 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');
INSERT INTO public.calendar_events (id, calendar_id, title, start, event_end, all_day, description, created_at, updated_at) VALUES (577, 4, 'Рабочие часы', '2026-02-27 09:00:00', '2026-02-27 18:00:00', false, '', '2026-01-23 07:47:12.043462', '2026-01-23 07:47:12.043462');


--
-- Data for Name: calendars; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.calendars (id, name, description, timezone, work_hours, is_active, created_at, updated_at, work_hours_from, work_hours_to, work_days_per_week, color, date_from, date_to, include_weekends) VALUES (4, 'Название', 'Описание', 'Europe/Moscow', NULL, true, '2026-01-23 06:32:37.803528', '2026-01-23 08:18:49.766336', '09:00:00', '18:00:00', 5, '#b92222', '2026-01-01', '2026-03-01', false);


--
-- Data for Name: communication_log; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: communication_notifications_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customer_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (33, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Антон', 'Петров', 'ант.петр', NULL, 'антон.петров@corp.io', '8 (946) 916-73-25', '@sergey4497', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (34, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Екатерина', 'Попова', 'ека_попо28', NULL, 'екатерина.попова@mail.com', '8 (591) 931-96-92', '@user4781', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (35, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Виктор', 'Кузнецов', 'вик_кузн55', NULL, 'виктор.кузнецов@org.net', '8 (598) 473-78-94', '@user5964', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (36, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Елена', 'Смирнова', 'елесмир', NULL, 'елена.смирнова@org.net', '+7 (551) 166-52-76', '@admin9601', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (37, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Дмитрий', 'Николаев', 'дми_нико98', NULL, 'дмитрий.николаев@mail.com', '8 (520) 503-72-35', '@dmitry9639', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (38, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Марина', 'Петрова', 'мар.петр', NULL, 'марина.петрова@corp.io', '8 (566) 540-82-93', '@sergey4469', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (40, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Елена', 'Иванова', 'еле_иван34', NULL, 'елена.иванова@mail.com', '8 (114) 176-85-53', '@dev6322', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (41, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Юрий', 'Романов', 'юри_рома11', NULL, 'юрий.романов@example.com', '+7 (724) 157-95-73', '@manager1985', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (42, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Вера', 'Макарова', 'вермака', NULL, 'вера.макарова@corp.io', '+7 (366) 815-18-17', '@manager5349', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (5, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Илья', 'Макаров', 'иль.мака', NULL, 'илья.макаров@corp.io', '+7 (852) 424-96-49', '@sergey5330', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (6, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Юлия', 'Иванова', 'юли.иван', NULL, 'юлия.иванова@org.net', '8 (128) 520-63-10', '@admin8441', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (7, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Иван', 'Павлов', 'ива.павл', NULL, 'иван.павлов@org.net', '8 (897) 468-15-75', '@dev8823', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (8, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Алиса', 'Николаева', 'али_нико9', NULL, 'алиса.николаева@company.ru', '8 (619) 463-77-60', '@ivan1355', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (9, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Иван', 'Кузнецов', 'ивакузн', NULL, 'иван.кузнецов@corp.io', '8 (364) 469-25-71', '@ivan1247', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (10, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Дарья', 'Алексеева', 'даралек', NULL, 'дарья.алексеева@org.net', '8 (405) 614-57-80', '@sergey6137', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (11, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Юрий', 'Кузнецов', 'юри.кузн', NULL, 'юрий.кузнецов@example.com', '8 (997) 483-91-24', '@admin1912', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (12, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Вера', 'Захарова', 'вер.заха', NULL, 'вера.захарова@example.com', '+7 (938) 884-34-30', '@user9142', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (13, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Владимир', 'Захаров', 'влазаха', NULL, 'владимир.захаров@org.net', '8 (537) 215-77-62', '@user9097', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (14, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Вера', 'Петрова', 'вер.петр', NULL, 'вера.петрова@org.net', '+7 (272) 719-27-90', '@admin9196', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (15, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Николай', 'Попов', 'никпопо', NULL, 'николай.попов@org.net', '8 (460) 433-48-92', '@alex9794', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (16, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Екатерина', 'Захарова', 'ека.заха', NULL, 'екатерина.захарова@example.com', '8 (781) 433-28-31', '@user2772', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (17, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Артем', 'Павлов', 'арт.павл', NULL, 'артем.павлов@org.net', '+7 (859) 109-28-82', '@ivan7061', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (18, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Людмила', 'Иванова', 'люд_иван5', NULL, 'людмила.иванова@mail.com', '+7 (689) 800-95-62', '@sergey3830', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (19, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Илья', 'Петров', 'иль.петр', NULL, 'илья.петров@example.com', '+7 (382) 930-30-92', '@dev3966', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (20, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Дарья', 'Андреева', 'дар.андр', NULL, 'дарья.андреева@mail.com', '+7 (450) 183-38-26', '@manager9638', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (21, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Николай', 'Кузнецов', 'ник.кузн', NULL, 'николай.кузнецов@example.com', '8 (531) 730-92-24', '@admin2615', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (22, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Анастасия', 'Кузнецова', 'ана_кузн42', NULL, 'анастасия.кузнецова@company.ru', '8 (280) 372-95-37', '@alex3794', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (23, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Павел', 'Николаев', 'пав.нико', NULL, 'павел.николаев@mail.com', '8 (149) 345-69-76', '@dmitry8992', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (24, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Алиса', 'Михайлова', 'али.миха', NULL, 'алиса.михайлова@org.net', '+7 (104) 480-75-47', '@alex6278', 5, 4);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (25, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Михаил', 'Павлов', 'мих.павл', NULL, 'михаил.павлов@example.com', '+7 (841) 981-82-85', '@ivan5450', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (26, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Ирина', 'Васильева', 'ириваси', NULL, 'ирина.васильева@example.com', '+7 (568) 593-12-97', '@dev1517', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (27, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Антон', 'Андреев', 'ант.андр', NULL, 'антон.андреев@corp.io', '+7 (574) 102-94-64', '@alex9752', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (28, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Татьяна', 'Захарова', 'тат_заха39', NULL, 'татьяна.захарова@example.com', '8 (565) 187-65-50', '@dev7923', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (29, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Кирилл', 'Орлов', 'кир.орло', NULL, 'кирилл.орлов@mail.com', '8 (757) 819-98-80', '@admin8571', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (30, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Мария', 'Сидорова', 'мар.сидо', NULL, 'мария.сидорова@corp.io', '8 (776) 180-37-65', '@dev6321', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (31, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Евгений', 'Петров', 'евг_петр52', NULL, 'евгений.петров@company.ru', '8 (505) 290-38-96', '@user7496', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (32, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Ирина', 'Дмитриева', 'ири.дмит', NULL, 'ирина.дмитриева@example.com', '8 (486) 367-98-20', '@dmitry3042', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (43, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Виктор', 'Орлов', 'вик.орло', NULL, 'виктор.орлов@corp.io', '+7 (331) 732-98-43', '@sergey3633', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (44, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Дарья', 'Павлова', 'дарпавл', NULL, 'дарья.павлова@mail.com', '8 (945) 385-75-58', '@sergey3186', 5, 5);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (45, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Артем', 'Макаров', 'артмака', NULL, 'артем.макаров@mail.com', '+7 (215) 261-99-72', '@dev1299', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (46, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Екатерина', 'Захарова', 'ека_заха20', NULL, 'екатерина.захарова@corp.io', '8 (599) 242-36-20', '@alex2690', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (47, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Сергей', 'Андреев', 'сер.андр', NULL, 'сергей.андреев@company.ru', '+7 (428) 263-26-45', '@user2762', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (1, true, '2026-02-24 14:34:29.362075', '2026-03-05 08:45:12.254192', 'Иван', 'Иванов', 'admin@demo.com', '', 'ivanov@example.com', '', '', NULL, 1);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (48, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Полина', 'Соколова', 'полсоко', NULL, 'полина.соколова@example.com', '+7 (301) 494-40-49', '@admin9861', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (49, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Антон', 'Алексеев', 'ант_алек19', NULL, 'антон.алексеев@org.net', '8 (981) 728-86-99', '@dmitry4876', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (50, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Юлия', 'Васильева', 'юливаси', NULL, 'юлия.васильева@corp.io', '+7 (488) 957-60-67', '@manager6692', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (51, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Андрей', 'Дмитриев', 'анд.дмит', NULL, 'андрей.дмитриев@example.com', '8 (501) 414-60-66', '@user4104', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (52, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Людмила', 'Соколова', 'людсоко', NULL, 'людмила.соколова@example.com', '8 (860) 146-27-90', '@admin9577', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (53, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Михаил', 'Соколов', 'михсоко', NULL, 'михаил.соколов@org.net', '8 (366) 338-24-74', '@admin8718', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (54, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Алиса', 'Павлова', 'али_павл86', NULL, 'алиса.павлова@corp.io', '8 (555) 952-56-25', '@user6105', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (55, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Илья', 'Соколов', 'иль_соко13', NULL, 'илья.соколов@mail.com', '+7 (177) 624-82-97', '@user2295', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (56, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Анастасия', 'Михайлова', 'ана_миха71', NULL, 'анастасия.михайлова@company.ru', '+7 (608) 146-88-78', '@alex5310', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (57, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Григорий', 'Иванов', 'гри.иван', NULL, 'григорий.иванов@example.com', '+7 (743) 826-96-40', '@sergey1408', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (58, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Галина', 'Павлова', 'гал_павл16', NULL, 'галина.павлова@mail.com', '8 (439) 417-33-33', '@ivan5391', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (59, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Павел', 'Романов', 'пав_рома86', NULL, 'павел.романов@mail.com', '8 (209) 488-25-61', '@alex7449', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (60, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Ирина', 'Михайлова', 'иримиха', NULL, 'ирина.михайлова@mail.com', '+7 (276) 112-22-95', '@ivan8332', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (61, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Виктор', 'Романов', 'вик_рома93', NULL, 'виктор.романов@corp.io', '+7 (624) 933-74-17', '@dmitry7267', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (62, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Дарья', 'Михайлова', 'дар.миха', NULL, 'дарья.михайлова@org.net', '8 (762) 380-60-84', '@dmitry3876', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (63, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Борис', 'Михайлов', 'бор.миха', NULL, 'борис.михайлов@mail.com', '+7 (928) 247-34-67', '@alex9406', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (64, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Екатерина', 'Захарова', 'еказаха', NULL, 'екатерина.захарова@mail.com', '8 (300) 515-10-25', '@admin4991', 5, 6);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (65, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Олег', 'Павлов', 'оле_павл75', NULL, 'олег.павлов@org.net', '+7 (329) 514-89-80', '@admin4859', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (66, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Вера', 'Соколова', 'версоко', NULL, 'вера.соколова@org.net', '+7 (712) 350-73-51', '@admin5242', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (67, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Кирилл', 'Захаров', 'кирзаха', NULL, 'кирилл.захаров@company.ru', '8 (636) 458-69-84', '@sergey9333', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (68, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Дарья', 'Кузнецова', 'дар.кузн', NULL, 'дарья.кузнецова@corp.io', '8 (817) 932-55-25', '@alex7972', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (69, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Юрий', 'Зайцев', 'юризайц', NULL, 'юрий.зайцев@org.net', '+7 (201) 983-37-11', '@dmitry7738', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (70, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Анна', 'Смирнова', 'аннсмир', NULL, 'анна.смирнова@org.net', '8 (666) 153-16-60', '@admin6705', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (71, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Павел', 'Захаров', 'пав.заха', NULL, 'павел.захаров@company.ru', '8 (633) 792-37-27', '@alex1016', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (72, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Вера', 'Сидорова', 'версидо', NULL, 'вера.сидорова@org.net', '+7 (601) 148-25-86', '@sergey6366', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (73, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Григорий', 'Макаров', 'гри.мака', NULL, 'григорий.макаров@corp.io', '8 (496) 155-64-52', '@ivan6668', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (74, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Вера', 'Зайцева', 'верзайц', NULL, 'вера.зайцева@mail.com', '+7 (115) 898-59-20', '@dev5156', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (75, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Олег', 'Попов', 'оле.попо', NULL, 'олег.попов@corp.io', '8 (443) 574-94-70', '@user1216', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (76, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Елена', 'Попова', 'елепопо', NULL, 'елена.попова@example.com', '+7 (925) 532-60-75', '@dmitry5067', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (77, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Виктор', 'Смирнов', 'виксмир', NULL, 'виктор.смирнов@org.net', '+7 (216) 137-57-54', '@alex5630', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (78, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Алиса', 'Попова', 'али.попо', NULL, 'алиса.попова@mail.com', '8 (759) 914-76-87', '@dev6343', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (79, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Виктор', 'Иванов', 'викиван', NULL, 'виктор.иванов@org.net', '+7 (532) 222-86-54', '@dmitry4593', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (80, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Екатерина', 'Орлова', 'ека_орло6', NULL, 'екатерина.орлова@company.ru', '8 (425) 539-31-17', '@admin6414', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (81, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Евгений', 'Дмитриев', 'евг_дмит69', NULL, 'евгений.дмитриев@corp.io', '8 (850) 315-51-86', '@admin3487', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (82, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Надежда', 'Павлова', 'над_павл48', NULL, 'надежда.павлова@example.com', '+7 (836) 749-60-59', '@ivan1460', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (83, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Олег', 'Зайцев', 'олезайц', NULL, 'олег.зайцев@org.net', '+7 (274) 217-94-36', '@alex3061', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (84, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Татьяна', 'Алексеева', 'тат.алек', NULL, 'татьяна.алексеева@corp.io', '+7 (629) 542-70-26', '@dev6551', 5, 7);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (85, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Борис', 'Иванов', 'бориван', NULL, 'борис.иванов@mail.com', '+7 (958) 520-15-22', '@user2128', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (86, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Татьяна', 'Васильева', 'тат.васи', NULL, 'татьяна.васильева@org.net', '8 (650) 821-15-68', '@user3385', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (39, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Григорий', 'Николаев', 'гри.нико', NULL, 'григорий.николаев@example.com', '+7 (405) 971-75-41', '@alex5476', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (87, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Юлия', 'Соколова', 'юлисоко', NULL, 'юлия.соколова@corp.io', '+7 (270) 120-47-59', '@manager1814', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (88, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Евгений', 'Кузнецов', 'евг_кузн58', NULL, 'евгений.кузнецов@example.com', '+7 (909) 328-40-76', '@user3305', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (89, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Ольга', 'Орлова', 'ольорло', NULL, 'ольга.орлова@mail.com', '8 (346) 242-10-15', '@dev4141', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (90, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Кирилл', 'Фёдоров', 'кирфёдо', NULL, 'кирилл.фёдоров@company.ru', '8 (756) 521-88-19', '@dmitry1471', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (91, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Вера', 'Захарова', 'верзаха', NULL, 'вера.захарова@org.net', '+7 (387) 495-90-17', '@ivan7785', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (92, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Константин', 'Фёдоров', 'кон.фёдо', NULL, 'константин.фёдоров@org.net', '+7 (901) 337-60-66', '@dev9430', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (93, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Дарья', 'Михайлова', 'дар_миха80', NULL, 'дарья.михайлова@example.com', '+7 (752) 714-20-88', '@alex7526', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (94, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Виктор', 'Николаев', 'викнико', NULL, 'виктор.николаев@example.com', '+7 (905) 358-33-23', '@dmitry2879', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (95, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Анастасия', 'Михайлова', 'ана.миха', NULL, 'анастасия.михайлова@mail.com', '+7 (653) 255-17-13', '@manager1112', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (96, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Павел', 'Петров', 'павпетр', NULL, 'павел.петров@mail.com', '8 (422) 254-96-64', '@sergey5147', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (97, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Анна', 'Дмитриева', 'анндмит', NULL, 'анна.дмитриева@example.com', '+7 (713) 822-51-63', '@manager4755', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (98, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Артем', 'Захаров', 'арт.заха', NULL, 'артем.захаров@company.ru', '8 (374) 844-73-15', '@user4517', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (99, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Ольга', 'Соколова', 'оль.соко', NULL, 'ольга.соколова@company.ru', '+7 (404) 691-79-32', '@admin3812', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (100, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Григорий', 'Андреев', 'гри.андр', NULL, 'григорий.андреев@example.com', '8 (583) 202-93-19', '@sergey7655', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (101, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Марина', 'Смирнова', 'мар_смир80', NULL, 'марина.смирнова@company.ru', '8 (632) 907-74-27', '@admin1750', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (102, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Андрей', 'Зайцев', 'анд.зайц', NULL, 'андрей.зайцев@company.ru', '8 (393) 827-47-15', '@admin4293', 5, 8);
INSERT INTO public.customer_users (id, is_active, created_at, updated_at, first_name, last_name, login, password, email, mobile_phone, telegram_account, customer_id, customers_group_id) VALUES (103, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 'Анна', 'Захарова', 'аннзаха', NULL, 'анна.захарова@mail.com', '+7 (480) 141-96-78', '@manager5887', 5, 8);


--
-- Data for Name: customer_users_customers; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customer_users_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customer_users_services; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.customers (id, name, street, zip, city, comment, is_active, created_at, updated_at) VALUES (5, 'Тестовая компания', NULL, NULL, 'Москва', NULL, true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577');


--
-- Data for Name: customers_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.customers_groups (id, name, message, is_active, created_at, updated_at, customer_id) VALUES (4, 'Отдел продаж', 'Группа Отдел продаж', true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 5);
INSERT INTO public.customers_groups (id, name, message, is_active, created_at, updated_at, customer_id) VALUES (5, 'Техническая поддержка', 'Группа Техническая поддержка', true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 5);
INSERT INTO public.customers_groups (id, name, message, is_active, created_at, updated_at, customer_id) VALUES (6, 'Бухгалтерия', 'Группа Бухгалтерия', true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 5);
INSERT INTO public.customers_groups (id, name, message, is_active, created_at, updated_at, customer_id) VALUES (7, 'Маркетинг', 'Группа Маркетинг', true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 5);
INSERT INTO public.customers_groups (id, name, message, is_active, created_at, updated_at, customer_id) VALUES (8, 'HR', 'Группа HR', true, '2026-03-05 08:36:45.899577', '2026-03-05 08:36:45.899577', 5);
INSERT INTO public.customers_groups (id, name, message, is_active, created_at, updated_at, customer_id) VALUES (1, 'Отдел разработки', '', true, '2026-03-04 15:22:41.6349', '2026-03-05 08:45:12.254192', NULL);
INSERT INTO public.customers_groups (id, name, message, is_active, created_at, updated_at, customer_id) VALUES (3, 'Отдел  разраблтки', '', true, '2026-03-05 00:32:42.680555', '2026-03-05 08:45:12.254192', NULL);


--
-- Data for Name: customers_services; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: dynamic_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: dynamic_fields_screens; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: dynamicfields; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: email_addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.email_addresses (id, name, message, is_active, created_at, updated_at, queue_id) VALUES (1, 'e', '1ww', true, '2026-02-11 14:06:38.366177', '2026-02-11 14:53:25.000716', 1);
INSERT INTO public.email_addresses (id, name, message, is_active, created_at, updated_at, queue_id) VALUES (2, 'fwefw', 'fwefwef', true, '2026-02-11 14:42:45.656827', '2026-02-11 14:53:32.639189', 4);


--
-- Data for Name: general_catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.general_catalog (id, name, message, is_active, created_at, updated_at) VALUES (1, 'ug', '', true, '2026-01-22 20:00:26.009838', '2026-01-22 20:00:26.009838');


--
-- Data for Name: generic_agent; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: greetings; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.greetings (id, name, comment, is_active, created_at, updated_at, content) VALUES (1, 'Добрый день', 'Стандартное приветствие для дневного времени', true, '2026-01-23 08:57:43.771478', '2026-01-23 08:57:43.771478', 'Добрый день!

');
INSERT INTO public.greetings (id, name, comment, is_active, created_at, updated_at, content) VALUES (2, 'Здравствуйте', 'Официальное приветствие', true, '2026-01-23 08:57:43.77386', '2026-01-23 08:57:43.77386', 'Здравствуйте!

');
INSERT INTO public.greetings (id, name, comment, is_active, created_at, updated_at, content) VALUES (3, 'Привет', 'Неформальное приветствие', true, '2026-01-23 08:57:43.774771', '2026-01-23 08:57:43.774771', 'Привет!

');
INSERT INTO public.greetings (id, name, comment, is_active, created_at, updated_at, content) VALUES (4, 'Доброе утро', 'Приветствие для утреннего времени', true, '2026-01-23 08:57:43.77558', '2026-01-23 08:57:43.77558', 'Доброе утро!

');
INSERT INTO public.greetings (id, name, comment, is_active, created_at, updated_at, content) VALUES (5, 'Добрый вечер', 'Приветствие для вечернего времени', true, '2026-01-23 08:57:43.776249', '2026-01-23 08:57:43.776249', 'Добрый вечер!

');
INSERT INTO public.greetings (id, name, comment, is_active, created_at, updated_at, content) VALUES (6, 'Уважаемый клиент', 'Официальное приветствие для клиентов', true, '2026-01-23 08:57:43.776888', '2026-01-23 08:57:43.776888', 'Уважаемый клиент!

');
INSERT INTO public.greetings (id, name, comment, is_active, created_at, updated_at, content) VALUES (7, 'Дорогой пользователь', 'Приветствие для пользователей системы', true, '2026-01-23 08:57:43.777618', '2026-01-23 08:57:43.777618', 'Дорогой пользователь!

');
INSERT INTO public.greetings (id, name, comment, is_active, created_at, updated_at, content) VALUES (8, 'Рады приветствовать', 'Теплое приветствие', true, '2026-01-23 08:57:43.778301', '2026-01-23 08:57:43.778301', 'Рады приветствовать Вас!

');


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: oauth2; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: package_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: performance_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.performance_log (id, name, message, is_active, created_at, updated_at) VALUES (1, 'гшщ', 'гшщ', true, '2026-01-23 08:20:50.645728', '2026-01-23 08:20:50.645728');


--
-- Data for Name: pgp_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: post_master_filters; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: post_master_mail_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.post_master_mail_accounts (id, is_active, created_at, updated_at, type, authentication_type, login, password, host, imap_folder, trusted, dispatching_by, queue_id, comment, oauth2_token_config_id) VALUES (3, true, '2026-02-11 16:38:51.755544', '2026-02-11 17:21:18.260748', 'IMAP', 'password', 'test@example.com', 'test123', 'mail.example.com', 'INBOX', true, 'Queue', 1, 'Test account', 12);


--
-- Data for Name: priorities; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (4, 'Критический', '#dc3545', true, '2026-01-19 11:55:29.571122', '2026-01-19 11:55:29.571122');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (5, 'Очень низкий', '#6c757d', true, '2026-01-19 11:55:29.575383', '2026-01-19 11:55:29.575383');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (6, 'Очень высокий', '#e83e8c', true, '2026-01-19 11:57:26.133467', '2026-01-19 11:57:26.133467');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (7, 'Срочный', '#fd7e14', true, '2026-01-19 11:57:26.139886', '2026-01-19 11:57:26.139886');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (8, 'Блокирующий', '#343a40', true, '2026-01-19 11:57:26.144136', '2026-01-19 11:57:26.144136');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (9, 'Нормальный', '#007bff', true, '2026-01-19 11:57:26.1482', '2026-01-19 11:57:26.1482');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (10, 'Минимальный', '#6c757d', true, '2026-01-19 11:57:26.152191', '2026-01-19 11:57:26.152191');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (1, 'Низкий', '#28a745', true, '2026-01-19 11:55:29.552544', '2026-01-19 11:58:15.124861');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (2, 'Средний', '#ffc107', false, '2026-01-19 11:55:29.561287', '2026-01-19 12:12:44.084324');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (3, 'Высокий', '#fd7e14', false, '2026-01-19 11:55:29.565849', '2026-01-19 12:12:44.130781');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (12, 'у', '', false, '2026-01-19 12:16:26.089023', '2026-01-19 12:16:26.089023');
INSERT INTO public.priorities (id, name, color, is_active, created_at, updated_at) VALUES (13, 'уу', '', false, '2026-01-19 12:16:33.943985', '2026-01-19 12:16:33.943985');


--
-- Data for Name: process_management; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: processes_automation_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: queue_auto_response; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: queues; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (1, 'Очередь первой линии поддержки', '', 0, 0, false, '2026-01-23 08:51:30.453866', '2026-03-02 10:21:46.157501', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '{}', NULL, NULL);
INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (2, 'Очередь первой линии поддержки', '', 0, 0, false, '2026-01-23 10:08:48.325603', '2026-03-02 10:21:46.214113', 1, NULL, NULL, NULL, NULL, NULL, NULL, '{}', NULL, NULL);
INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (3, '=-', '=-', 0, 0, false, '2026-01-23 10:09:01.421092', '2026-03-02 10:21:46.255001', 1, NULL, NULL, NULL, NULL, NULL, NULL, '{}', NULL, NULL);
INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (4, '111', '111', 0, 0, false, '2026-01-27 15:15:48.182211', '2026-03-02 10:21:46.290753', 1, NULL, NULL, NULL, NULL, NULL, NULL, '{}', NULL, NULL);
INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (5, 'wfewfwe', 'ewfew', 0, 0, false, '2026-03-02 10:21:26.567781', '2026-03-02 10:21:46.328898', 1, NULL, NULL, NULL, NULL, NULL, NULL, '{}', NULL, NULL);
INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (6, 'Техническая поддержка', 'Очередь для технических вопросов', 100, 2, true, '2026-03-03 07:42:03.273686', '2026-03-03 07:42:03.273686', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '{}', NULL, NULL);
INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (7, 'Продажи', 'Очередь для вопросов по продажам', 50, 1, true, '2026-03-03 07:42:03.273686', '2026-03-03 07:42:03.273686', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '{}', NULL, NULL);
INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (8, 'Бухгалтерия', 'Очередь для финансовых вопросов', 20, 3, true, '2026-03-03 07:42:03.273686', '2026-03-03 07:42:03.273686', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '{}', NULL, NULL);
INSERT INTO public.queues (id, name, description, max_tickets, priority, is_active, created_at, updated_at, template_id, company_id, service_id, sla_id, workflow_id, agent_group_id, priority_id, email_config, keywords, auto_response_template) VALUES (9, 'Тестовая очередь', 'Тест', 10, 1, true, '2026-03-03 07:44:27.926573', '2026-03-03 07:44:27.926573', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.roles (id, name, message, is_active, created_at, updated_at) VALUES (2, 'Менеджер', 'Управление пользователями и настройками', true, '2026-01-29 16:53:02.181803', '2026-01-29 16:53:02.181803');
INSERT INTO public.roles (id, name, message, is_active, created_at, updated_at) VALUES (3, 'Агент поддержки', 'Работа с тикетами и обращениями клиентов', true, '2026-01-29 16:53:02.184966', '2026-01-29 16:53:02.184966');
INSERT INTO public.roles (id, name, message, is_active, created_at, updated_at) VALUES (4, 'Аналитик', 'Просмотр отчетов и статистики', true, '2026-01-29 16:53:02.188104', '2026-01-29 16:53:02.188104');
INSERT INTO public.roles (id, name, message, is_active, created_at, updated_at) VALUES (5, 'Оператор', 'Базовые операции с тикетами', true, '2026-01-29 16:53:02.192021', '2026-01-29 16:53:02.192021');
INSERT INTO public.roles (id, name, message, is_active, created_at, updated_at) VALUES (6, 'Супервизор', 'Контроль работы агентов поддержки', true, '2026-01-29 16:53:02.195681', '2026-01-29 16:53:02.195681');
INSERT INTO public.roles (id, name, message, is_active, created_at, updated_at) VALUES (8, 'Консультант', 'Консультации клиентов по продуктам', true, '2026-01-29 16:53:02.204276', '2026-01-29 16:53:02.204276');
INSERT INTO public.roles (id, name, message, is_active, created_at, updated_at) VALUES (7, 'Технический специалист', 'Решение технических вопросов', true, '2026-01-29 16:53:02.200285', '2026-01-31 20:44:57.407966');
INSERT INTO public.roles (id, name, message, is_active, created_at, updated_at) VALUES (1, 'Администратор', 'Полный доступ ко всем функциям системы', false, '2026-01-29 16:53:02.176047', '2026-02-24 11:36:10.927644');


--
-- Data for Name: roles_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: service_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.service_attachments (id, service_id, file_name, file_path, file_size, mime_type, uploaded_by, created_at) VALUES (2, 36, '77777.xlsx', 'service-1771961176168-608538746.xlsx', 929577, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', NULL, '2026-02-24 22:26:16.176059');
INSERT INTO public.service_attachments (id, service_id, file_name, file_path, file_size, mime_type, uploaded_by, created_at) VALUES (3, 33, 'Кейс_для_обработки_сводного_отчета_из_ХД.docx', 'service-1772436137961-628614756.docx', 18063, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, '2026-03-02 10:22:17.964312');


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.services (id, name, comment, is_active, created_at, updated_at, type, sla_id) VALUES (33, 'Резервное копирование', 'Услуги по резервному копированию данных', true, '2026-02-24 17:41:22.165981', '2026-03-02 10:22:17.913041', 'Демонстрация', 3);
INSERT INTO public.services (id, name, comment, is_active, created_at, updated_at, type, sla_id) VALUES (36, 'bnm,', '', true, '2026-02-24 19:18:10.685327', '2026-02-24 22:26:16.049061', 'Обучение', 3);
INSERT INTO public.services (id, name, comment, is_active, created_at, updated_at, type, sla_id) VALUES (34, 'Мониторинг', 'Мониторинг систем и приложений', true, '2026-02-24 17:41:22.169307', '2026-03-04 15:11:09.171788', 'Обучение', 3);


--
-- Data for Name: services_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: session_management; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: signatures; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.signatures (id, name, content, is_active, created_at, updated_at, comment) VALUES (1, 'С уважением', '

С уважением,
[Ваше имя]
[Ваша должность]
[Название компании]', true, '2026-01-23 08:57:57.418438', '2026-01-23 08:57:57.418438', 'Стандартная подпись с уважением');
INSERT INTO public.signatures (id, name, content, is_active, created_at, updated_at, comment) VALUES (2, 'Лучшие пожелания', '

С лучшими пожеланиями,
[Ваше имя]
[Ваша должность]', true, '2026-01-23 08:57:57.421207', '2026-01-23 08:57:57.421207', 'Теплая подпись с пожеланиями');
INSERT INTO public.signatures (id, name, content, is_active, created_at, updated_at, comment) VALUES (3, 'Спасибо за обращение', '

Спасибо за Ваше обращение!

С уважением,
[Ваше имя]', true, '2026-01-23 08:57:57.422078', '2026-01-23 08:57:57.422078', 'Подпись с благодарностью');
INSERT INTO public.signatures (id, name, content, is_active, created_at, updated_at, comment) VALUES (4, 'Официальная подпись', '

С уважением,
[Ваше имя]
[Ваша должность]
[Контактная информация]
[Название компании]', true, '2026-01-23 08:57:57.422746', '2026-01-23 08:57:57.422746', 'Полная официальная подпись');
INSERT INTO public.signatures (id, name, content, is_active, created_at, updated_at, comment) VALUES (5, 'Короткая подпись', '

С уважением,
[Ваше имя]', true, '2026-01-23 08:57:57.423351', '2026-01-23 08:57:57.423351', 'Краткая подпись');
INSERT INTO public.signatures (id, name, content, is_active, created_at, updated_at, comment) VALUES (6, 'Поддержка клиентов', '

Команда поддержки
[Название компании]
[Контактная информация]', true, '2026-01-23 08:57:57.424022', '2026-01-23 08:57:57.424022', 'Подпись для службы поддержки');
INSERT INTO public.signatures (id, name, content, is_active, created_at, updated_at, comment) VALUES (7, 'Техническая поддержка', '

Техническая поддержка
[Ваше имя]
[Email]
[Телефон]', true, '2026-01-23 08:57:57.424666', '2026-01-23 08:57:57.424666', 'Подпись для технической поддержки');
INSERT INTO public.signatures (id, name, content, is_active, created_at, updated_at, comment) VALUES (8, 'Менеджер по продажам', '

Менеджер по продажам
[Ваше имя]
[Телефон]
[Email]', true, '2026-01-23 08:57:57.425353', '2026-01-23 08:57:57.425353', 'Подпись для отдела продаж');


--
-- Data for Name: sla; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sla (id, name, description, response_time, resolution_time, is_active, created_at, updated_at, calendar_id, notification_percentage, type, solution_time, min_incident_time, response_notification, update_notification, solution_notification) VALUES (3, 'Основное', 'Описание', 15.00, 4.00, true, '2026-01-27 13:42:30.561839', '2026-01-27 13:42:30.561839', 4, 0, 'relative_solution_speed', 0, 10, 20, 80, 80);
INSERT INTO public.sla (id, name, description, response_time, resolution_time, is_active, created_at, updated_at, calendar_id, notification_percentage, type, solution_time, min_incident_time, response_notification, update_notification, solution_notification) VALUES (4, 'dcasf', '', 15.00, 4.00, true, '2026-03-02 10:23:06.682854', '2026-03-02 10:23:06.682854', 4, 0, 'availability', 0, 10, 20, 80, 80);
INSERT INTO public.sla (id, name, description, response_time, resolution_time, is_active, created_at, updated_at, calendar_id, notification_percentage, type, solution_time, min_incident_time, response_notification, update_notification, solution_notification) VALUES (5, 'Стандартный SLA', 'Стандартное соглашение об уровне сервиса', 4.00, 24.00, true, '2026-03-03 07:42:03.289002', '2026-03-03 07:42:03.289002', NULL, 0, NULL, 0, 10, 20, 80, 80);
INSERT INTO public.sla (id, name, description, response_time, resolution_time, is_active, created_at, updated_at, calendar_id, notification_percentage, type, solution_time, min_incident_time, response_notification, update_notification, solution_notification) VALUES (7, 'Базовый SLA', 'Базовое соглашение для простых запросов', 8.00, 48.00, true, '2026-03-03 07:42:03.289002', '2026-03-03 07:42:03.289002', NULL, 0, NULL, 0, 10, 20, 80, 80);
INSERT INTO public.sla (id, name, description, response_time, resolution_time, is_active, created_at, updated_at, calendar_id, notification_percentage, type, solution_time, min_incident_time, response_notification, update_notification, solution_notification) VALUES (6, 'Премиум SLA', 'Премиум соглашение с быстрым реагированием', 1.00, 8.00, true, '2026-03-03 07:42:03.289002', '2026-03-03 11:38:04.991053', 4, 0, NULL, 60, 10, 20, 80, 80);


--
-- Data for Name: sla_services; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sla_services (id, sla_id, service_id, created_at, updated_at) VALUES (6, 4, 34, '2026-03-02 10:23:06.682854', '2026-03-02 10:23:06.682854');
INSERT INTO public.sla_services (id, sla_id, service_id, created_at, updated_at) VALUES (7, 6, 34, '2026-03-03 11:38:04.991053', '2026-03-03 11:38:04.991053');


--
-- Data for Name: smime_certificates; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sql_box; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: state_transitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.state_transitions (id, type_id, from_state_id, to_state_id, name, is_active, created_at, sort_order) VALUES (1, 1, 2, 4, 'Открыть', true, '2026-02-21 10:44:41.522947+03', 1);


--
-- Data for Name: states; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (2, 'Новый', 'Новое обращение, поступившее в систему', true, '2026-01-19 12:52:09.206925', '2026-01-19 12:53:17.816125', 'Новая', '#007bff', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (11, 'Эскалирован', 'Обращение передано на более высокий уровень поддержки', true, '2026-01-19 12:52:09.241649', '2026-01-19 12:55:09.171725', 'Удалена', '#e83e8c', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (3, 'Открыт', 'Обращение принято в работу', false, '2026-01-19 12:52:09.212393', '2026-01-19 12:56:02.03789', 'Открыта', '#28a745', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (4, 'В работе', 'Обращение находится в процессе обработки', false, '2026-01-19 12:52:09.216973', '2026-01-19 12:56:02.076953', 'Ожидает напоминания', '#ffc107', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (5, 'Ожидание клиента', 'Ожидание дополнительной информации от клиента', false, '2026-01-19 12:52:09.220835', '2026-01-19 12:56:02.116864', 'Ожидает автозакрытия', '#17a2b8', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (6, 'Ожидание поставщика', 'Ожидание ответа от внешнего поставщика услуг', false, '2026-01-19 12:52:09.224527', '2026-01-19 12:56:02.153627', 'Объединенные', '#6f42c1', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (7, 'Решен', 'Проблема решена, ожидание подтверждения от клиента', false, '2026-01-19 12:52:09.228559', '2026-01-19 12:56:02.192753', 'Закрыта', '#20c997', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (8, 'Закрыт', 'Обращение успешно завершено', false, '2026-01-19 12:52:09.232434', '2026-01-19 12:56:02.229811', 'Открыта', '#6c757d', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (9, 'Отклонен', 'Обращение отклонено', false, '2026-01-19 12:52:09.235479', '2026-01-19 12:56:02.266573', 'Ожидает напоминания', '#dc3545', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (10, 'На удержании', 'Обращение временно приостановлено', false, '2026-01-19 12:52:09.238478', '2026-01-19 12:56:02.31052', 'Открыта', '#fd7e14', NULL, false);
INSERT INTO public.states (id, name, comment, is_active, created_at, updated_at, type, color, type_id, is_initial) VALUES (13, 'Отменен', 'Заявка отменена клиентом', true, '2026-01-23 08:57:05.509344', '2026-01-23 08:57:05.509344', 'closed', '#fd7e14', NULL, false);


--
-- Data for Name: support_data_collector; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: system_configuration; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: system_file_support; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: system_log; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: system_maintenance; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: template_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.template_attachments (id, name, message, is_active, created_at, updated_at) VALUES (1, 'мпир', 'ить', true, '2026-02-21 11:56:58.12377', '2026-02-21 11:56:58.12377');


--
-- Data for Name: template_queues; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.templates (id, name, message, is_active, created_at, updated_at) VALUES (1, '=-', '<p>зх</p>', true, '2026-01-23 10:08:38.534362', '2026-01-23 10:08:38.534362');
INSERT INTO public.templates (id, name, message, is_active, created_at, updated_at) VALUES (2, 'Шаблон ответа на инцидент', 'Уважаемый клиент, мы получили ваше обращение и уже работаем над решением проблемы.', true, '2026-03-03 07:42:03.282944', '2026-03-03 07:42:03.282944');
INSERT INTO public.templates (id, name, message, is_active, created_at, updated_at) VALUES (3, 'Шаблон подтверждения', 'Ваше обращение зарегистрировано под номером #ID.', true, '2026-03-03 07:42:03.282944', '2026-03-03 07:42:03.282944');
INSERT INTO public.templates (id, name, message, is_active, created_at, updated_at) VALUES (4, 'Шаблон закрытия', 'Ваше обращение успешно решено. Спасибо за обращение!', true, '2026-03-03 07:42:03.282944', '2026-03-03 07:42:03.282944');


--
-- Data for Name: test_entities; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.ticket_attachments (id, ticket_id, file_name, file_path, file_size, mime_type, uploaded_by, created_at) VALUES (2, 6, 'app.txt', 'ticket-1771613420749-190918309.txt', 14998, 'text/plain', NULL, '2026-02-20 21:50:20.750789+03');
INSERT INTO public.ticket_attachments (id, ticket_id, file_name, file_path, file_size, mime_type, uploaded_by, created_at) VALUES (3, 20, '77777_cleaned.xlsx', 'ticket-1771690189077-871571115.xlsx', 910854, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', NULL, '2026-02-21 19:09:49.079946+03');
INSERT INTO public.ticket_attachments (id, ticket_id, file_name, file_path, file_size, mime_type, uploaded_by, created_at) VALUES (5, 23, 'env', 'ticket-1772482600432-62441597', 58, 'application/octet-stream', NULL, '2026-03-02 23:16:40.439944+03');


--
-- Data for Name: ticket_attribute_relations; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.ticket_comments (id, ticket_id, author_id, content, created_at, updated_at, is_internal) VALUES (5, 6, NULL, 'уацуацу', '2026-02-20 22:40:18.194812+03', '2026-02-20 22:40:18.194812+03', false);
INSERT INTO public.ticket_comments (id, ticket_id, author_id, content, created_at, updated_at, is_internal) VALUES (6, 6, NULL, 'цувцувуц', '2026-02-20 22:40:37.544143+03', '2026-02-20 22:40:37.544143+03', true);
INSERT INTO public.ticket_comments (id, ticket_id, author_id, content, created_at, updated_at, is_internal) VALUES (7, 21, NULL, 'тьб', '2026-02-22 15:42:04.127813+03', '2026-02-22 15:42:04.127813+03', false);
INSERT INTO public.ticket_comments (id, ticket_id, author_id, content, created_at, updated_at, is_internal) VALUES (8, 21, NULL, 'ьтбь', '2026-02-22 15:42:10.898324+03', '2026-02-22 15:42:10.898324+03', true);
INSERT INTO public.ticket_comments (id, ticket_id, author_id, content, created_at, updated_at, is_internal) VALUES (9, 22, NULL, 'ропор', '2026-02-22 17:49:52.999754+03', '2026-02-22 17:49:52.999754+03', false);


--
-- Data for Name: ticket_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (1, 18, NULL, 'stateId', NULL, '2', '2026-02-21 17:18:26.843594+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (2, 19, NULL, 'stateId', NULL, '2', '2026-02-21 17:18:52.01038+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (3, 19, NULL, 'stateId', '2', '4', '2026-02-21 17:19:58.188814+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (4, 20, NULL, 'stateId', NULL, '2', '2026-02-21 19:09:49.01534+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (5, 21, NULL, 'stateId', NULL, '2', '2026-02-22 15:36:39.938736+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (6, 21, NULL, 'stateId', '2', '4', '2026-02-22 15:37:23.172858+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (7, 21, NULL, 'stateId', '4', '9', '2026-02-22 16:14:16.237963+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (8, 22, NULL, 'stateId', NULL, 'Новый', '2026-02-22 17:39:29.293631+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (9, 22, NULL, 'attachment', NULL, 'Добавлен файл: 77777_cleaned.xlsx', '2026-02-22 17:39:29.370147+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (10, 22, NULL, 'stateId', 'Новый', 'В работе', '2026-02-22 17:40:26.639269+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (11, 22, NULL, 'title', 'тест ', 'тест 2', '2026-02-22 17:41:08.615887+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (12, 22, NULL, 'description', '<p>тест</p>', '<p style="text-align: center;">тест ловалдыфоалдоф...', '2026-02-22 17:53:03.444422+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (13, 22, NULL, 'stateId', 'В работе', 'Решен', '2026-02-22 17:53:27.012968+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (14, 22, NULL, 'priorityId', 'Блокирующий', 'Срочный', '2026-02-22 17:56:00.982294+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (15, 22, NULL, 'attachment', 'Файл: 77777_cleaned.xlsx', 'Удалён', '2026-02-22 17:56:04.263751+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (16, 22, NULL, 'description', '<p style="text-align: center;">тест ловалдыфоалдоф...', '<p style="text-align: left;">тест ловалдыфоалдофыв...', '2026-02-22 18:24:40.215322+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (17, 23, NULL, 'stateId', NULL, 'Новый', '2026-03-02 23:16:40.386006+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (18, 23, NULL, 'attachment', NULL, 'Добавлен файл: env', '2026-03-02 23:16:40.446311+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (19, 23, NULL, 'slaId', 'Основное', 'dcasf', '2026-03-03 00:58:41.7523+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (20, 23, NULL, 'slaId', 'dcasf', 'Основное', '2026-03-03 00:58:48.324854+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (21, 25, NULL, 'stateId', NULL, 'Новый', '2026-03-03 09:56:17.620883+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (22, 26, NULL, 'stateId', NULL, 'Новый', '2026-03-03 10:49:24.832495+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (23, 22, NULL, 'title', 'тест 2', 'тест 2уцйвцй', '2026-03-03 11:31:13.560785+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (24, 30, NULL, 'stateId', NULL, 'Новый', '2026-03-03 11:35:31.437725+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (25, 30, NULL, 'slaId', 'Основное', 'Премиум SLA', '2026-03-03 11:36:05.415115+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (26, 30, NULL, 'responseDeadline', 'Wed Mar 04 2026 02:35:31 GMT+0300 (Москва, стандартное время)', '2026-03-03T23:35:31.431Z', '2026-03-03 11:36:05.418213+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (27, 30, NULL, 'responseDeadline', 'Tue Mar 03 2026 12:36:05 GMT+0300 (Москва, стандартное время)', '2026-03-03T09:36:05.407Z', '2026-03-03 12:27:28.78132+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (28, 30, NULL, 'responseDeadline', 'Tue Mar 03 2026 09:36:05 GMT+0300 (Москва, стандартное время)', '2026-03-03T06:36:05.407Z', '2026-03-03 12:28:10.538075+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (29, 30, NULL, 'responseDeadline', 'Tue Mar 03 2026 06:36:05 GMT+0300 (Москва, стандартное время)', '2026-03-03T03:36:05.407Z', '2026-03-03 12:28:20.696994+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (30, 30, NULL, 'responseDeadline', 'Tue Mar 03 2026 03:36:05 GMT+0300 (Москва, стандартное время)', '2026-03-03T00:36:05.407Z', '2026-03-03 12:46:15.505222+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (31, 30, NULL, 'responseDeadline', 'Tue Mar 03 2026 00:36:05 GMT+0300 (Москва, стандартное время)', '2026-03-02T21:36:05.407Z', '2026-03-03 12:46:23.176255+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (32, 30, NULL, 'serviceId', NULL, 'Мониторинг', '2026-03-03 12:51:28.327541+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (33, 30, NULL, 'responseDeadline', 'Mon Mar 02 2026 21:36:05 GMT+0300 (Москва, стандартное время)', '2026-03-02T18:36:05.407Z', '2026-03-03 12:51:28.330516+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (34, 31, NULL, 'stateId', NULL, 'Новый', '2026-03-03 12:52:56.528225+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (35, 31, NULL, 'queueId', 'Очередь первой линии поддержки', 'Техническая поддержка', '2026-03-03 23:37:19.425977+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (36, 31, NULL, 'responseDeadline', 'Tue Mar 03 2026 13:52:56 GMT+0300 (Москва, стандартное время)', '2026-03-03T10:52:56.523Z', '2026-03-03 23:37:19.429023+03');
INSERT INTO public.ticket_history (id, ticket_id, changed_by, field_name, old_value, new_value, created_at) VALUES (37, 31, NULL, 'resolutionDeadline', 'Tue Mar 03 2026 13:52:56 GMT+0300 (Москва, стандартное время)', '2026-03-03T10:52:56.523Z', '2026-03-03 23:37:19.431622+03');


--
-- Data for Name: ticket_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: ticket_status_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.ticket_status_history (id, ticket_id, from_status_id, to_status_id, transition_id, changed_by, comment, created_at, transition_time, time_in_previous_status, action_label) VALUES (1, 22, NULL, 2, NULL, NULL, NULL, '2026-02-22 17:39:29.302718+03', '2026-02-22 17:39:29.302718+03', NULL, 'Создание тикета');
INSERT INTO public.ticket_status_history (id, ticket_id, from_status_id, to_status_id, transition_id, changed_by, comment, created_at, transition_time, time_in_previous_status, action_label) VALUES (2, 22, 2, 4, NULL, NULL, NULL, '2026-02-22 17:40:26.645348+03', '2026-02-22 17:40:26.645348+03', '00:00:57.341', NULL);
INSERT INTO public.ticket_status_history (id, ticket_id, from_status_id, to_status_id, transition_id, changed_by, comment, created_at, transition_time, time_in_previous_status, action_label) VALUES (3, 22, 4, 7, NULL, NULL, NULL, '2026-02-22 17:53:27.020589+03', '2026-02-22 17:53:27.020589+03', '00:13:00.374', NULL);
INSERT INTO public.ticket_status_history (id, ticket_id, from_status_id, to_status_id, transition_id, changed_by, comment, created_at, transition_time, time_in_previous_status, action_label) VALUES (4, 23, NULL, 2, NULL, NULL, NULL, '2026-03-02 23:16:40.394321+03', '2026-03-02 23:16:40.394321+03', NULL, 'Создание тикета');
INSERT INTO public.ticket_status_history (id, ticket_id, from_status_id, to_status_id, transition_id, changed_by, comment, created_at, transition_time, time_in_previous_status, action_label) VALUES (5, 25, NULL, 2, NULL, NULL, NULL, '2026-03-03 09:56:17.625623+03', '2026-03-03 09:56:17.625623+03', NULL, 'Создание тикета');
INSERT INTO public.ticket_status_history (id, ticket_id, from_status_id, to_status_id, transition_id, changed_by, comment, created_at, transition_time, time_in_previous_status, action_label) VALUES (6, 26, NULL, 2, NULL, NULL, NULL, '2026-03-03 10:49:24.839193+03', '2026-03-03 10:49:24.839193+03', NULL, 'Создание тикета');
INSERT INTO public.ticket_status_history (id, ticket_id, from_status_id, to_status_id, transition_id, changed_by, comment, created_at, transition_time, time_in_previous_status, action_label) VALUES (7, 30, NULL, 2, NULL, NULL, NULL, '2026-03-03 11:35:31.445973+03', '2026-03-03 11:35:31.445973+03', NULL, 'Создание тикета');
INSERT INTO public.ticket_status_history (id, ticket_id, from_status_id, to_status_id, transition_id, changed_by, comment, created_at, transition_time, time_in_previous_status, action_label) VALUES (8, 31, NULL, 2, NULL, NULL, NULL, '2026-03-03 12:52:56.535356+03', '2026-03-03 12:52:56.535356+03', NULL, 'Создание тикета');


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (18, '1000011', 'Test Incident', 1, NULL, NULL, 2, NULL, NULL, NULL, false, '2026-02-21 17:18:26.838132+03', '2026-03-03 12:51:56.355996+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (6, '1000006', 'Запрос на возврат средств', 3, 6, 1, 4, 42, NULL, 3, false, '2026-02-12 14:23:19.017887+03', '2026-03-03 12:51:56.392822+03', '<p><em>Запрос на возврат средств</em></p>', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (3, '1000003', 'Запрос на изменение пароля', 3, 6, 3, 3, 19, NULL, 3, false, '2026-02-11 20:59:46.441539+03', '2026-03-03 12:51:56.434926+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (24, '1000017', 'Тестовый тикет', NULL, NULL, 6, NULL, NULL, NULL, NULL, false, '2026-03-03 07:44:57.805821+03', '2026-03-03 11:30:28.808205+03', 'Тестовое описание', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (29, '1000020', 'фыйвйцвц', NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, '2026-03-03 11:34:22.214048+03', '2026-03-03 12:51:47.806825+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (22, '1000015', 'тест 2уцйвцй', 1, 7, 1, 7, 42, NULL, 3, false, '2026-02-22 17:39:29.284701+03', '2026-03-03 12:51:56.152802+03', '<p style="text-align: left;">тест ловалдыфоалдофывлда</p><p style="text-align: left;">фдлвыоадлфоы</p><p style="text-align: left;">щочфлыовфы</p><p style="text-align: left;">офылвофыдвофы</p><p style="text-align: left;">щолод</p>', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (21, '1000014', 'hjhjkhjk', 2, 5, 1, 9, 42, NULL, 3, false, '2026-02-22 15:36:39.929612+03', '2026-03-03 12:51:56.218722+03', '<p></p><p>вмвы</p><p>вым</p><p>ывмыв</p><p></p><p></p><p>лл</p><p></p><p></p>', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (20, '1000013', 'епк', 1, 4, 1, 2, 42, NULL, 3, false, '2026-02-21 19:09:49.00867+03', '2026-03-03 12:51:56.264389+03', '<p>некекн</p>', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (19, '1000012', 'Test Incident', 1, NULL, NULL, 4, NULL, NULL, NULL, false, '2026-02-21 17:18:52.0053+03', '2026-03-03 12:51:56.307857+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (8, '1000008', 'Жалоба на качество обслуживания', 2, 5, 2, 11, 32, NULL, 3, false, '2026-02-11 16:34:46.765366+03', '2026-03-03 23:36:51.280011+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (7, '1000007', 'Техническая проблема с сайтом', 1, 4, 1, 2, 3, NULL, 3, false, '2026-02-11 15:22:07.199657+03', '2026-03-03 23:36:51.324817+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (4, '1000004', 'Проблема с оплатой картой', 1, 4, 1, 2, 3, NULL, 3, false, '2026-02-11 06:54:16.64372+03', '2026-03-03 23:36:51.402458+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (9, '1000009', 'Запрос информации о продукте', 3, 6, 3, 3, 19, NULL, 3, false, '2026-02-10 18:40:51.697864+03', '2026-03-03 23:36:51.455522+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (5, '1000005', 'Вопрос по доставке товара', 2, 5, 2, 11, 32, NULL, 3, false, '2026-02-09 05:46:58.20379+03', '2026-03-03 23:36:51.498517+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (2, '1000002', 'Ошибка при оформлении заказа', 2, 5, 2, 11, 32, NULL, 3, false, '2026-02-08 21:55:15.706642+03', '2026-03-03 23:36:51.531014+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (10, '1000010', 'Предложение по улучшению сервиса', 1, 4, 1, 2, 3, NULL, 3, false, '2026-02-08 15:01:17.868364+03', '2026-03-03 23:36:51.559506+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (1, '1000001', 'Проблема с авторизацией в системе', 1, 4, 1, 2, 3, NULL, 3, false, '2026-02-07 16:19:39.27061+03', '2026-03-03 23:36:51.582754+03', NULL, NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (26, '1000019', 'frgsersd22222', 1, 4, 6, 2, 41, NULL, 6, false, '2026-03-03 10:49:24.786705+03', '2026-03-03 11:30:14.942802+03', '<p>dfsdfsd</p>', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (25, '1000018', 'efews', 1, 6, 1, 2, 46, NULL, 5, false, '2026-03-03 09:56:17.603389+03', '2026-03-03 11:30:25.535189+03', '<p>ewfrew</p>', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (30, '1000021', '34567890-х', 3, 10, 2, 2, 40, NULL, 6, false, '2026-03-03 11:35:31.416169+03', '2026-03-03 23:36:51.221633+03', '<p>кенгшщз</p>', '2026-03-02 18:36:05.407', NULL, NULL, false, NULL, 34);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (23, '1000016', 'уцкцу', 1, 4, 1, 2, 46, NULL, 3, false, '2026-03-02 23:16:40.372257+03', '2026-03-03 12:51:56.078336+03', '<p>куцк</p>', NULL, NULL, NULL, false, NULL, NULL);
INSERT INTO public.tickets (id, ticket_number, title, type_id, priority_id, queue_id, state_id, owner_id, company_id, sla_id, is_active, created_at, updated_at, description, response_deadline, resolution_deadline, first_response_at, sla_violated, pending_start_at, service_id) VALUES (31, '1000022', 'Ghbdtn', 1, 4, 6, 2, 41, NULL, 6, true, '2026-03-03 12:52:56.51421+03', '2026-03-03 23:37:19.419593+03', '<p>Ghbdnt</p>', '2026-03-03 10:52:56.523', '2026-03-03 10:52:56.523', NULL, false, NULL, 33);


--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (2, 'Запрос на обслуживание', 'Стандартный запрос на предоставление информации или услуги', false, '2026-01-19 12:28:17.410974', '2026-01-19 12:33:19.082416', NULL);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (6, 'Уведомление', 'Информационное сообщение', false, '2026-01-19 12:28:17.42482', '2026-01-19 12:33:19.22014', NULL);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (7, 'Жалоба', 'Выражение недовольства качеством обслуживания', false, '2026-01-19 12:28:17.428016', '2026-01-19 12:33:19.253699', NULL);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (8, 'Предложение', 'Предложение по улучшению', false, '2026-01-19 12:28:17.432445', '2026-01-19 12:33:19.288697', NULL);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (9, 'Консультация', 'Запрос на консультацию', false, '2026-01-19 12:28:17.437849', '2026-01-19 12:33:19.326176', NULL);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (10, 'Техническая поддержка', 'Запрос технической помощи', false, '2026-01-19 12:28:17.442147', '2026-01-19 12:33:19.358634', NULL);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (3, 'Проблема', 'Корневая причина инцидентов', false, '2026-01-19 12:28:17.415065', '2026-02-21 17:15:48.025625', 1);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (4, 'Изменение', 'Запрос на изменение в системе', false, '2026-01-19 12:28:17.41824', '2026-02-21 17:15:48.025625', 3);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (5, 'Задача', 'Общая задача или поручение', false, '2026-01-19 12:28:17.421488', '2026-02-21 17:15:48.025625', 1);
INSERT INTO public.types (id, name, comment, is_active, created_at, updated_at, workflow_id) VALUES (1, 'Инцидент', 'Проблема, требующая немедленного решения', false, '2026-01-19 12:28:17.404158', '2026-02-22 13:18:29.017162', 2);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.users (id, login, password, first_name, last_name, email, is_active, created_at, updated_at) VALUES (1, 'admin', '$2b$10$dae2EXFWUdl53VN/ZKMqK.nyMsh99FmabLvaoU1LbTbpyXdY2I1Ii', 'Admin', 'User', 'admin@demo.com', true, '2026-01-18 22:01:34.429222', '2026-01-18 22:01:34.429222');


--
-- Data for Name: users_groups_roles_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: web_services; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: workflow_transitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (1, 1, NULL, 2, 'Создать', 1, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (2, 1, 2, 3, 'Открыть', 2, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (3, 1, 2, 4, 'Взять в работу', 3, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (4, 1, 3, 4, 'Взять в работу', 4, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (7, 1, 7, 8, 'Закрыть', 7, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (8, 1, 7, 4, 'Открыть снова', 8, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (9, 1, 8, 4, 'Переоткрыть', 9, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (12, 2, 4, 7, 'Решить', 3, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (13, 2, 7, 8, 'Закрыть', 4, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (14, 3, NULL, 2, 'Создать запрос', 1, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (15, 3, 2, 3, 'Отправить на рассмотрение', 2, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (16, 3, 3, 4, 'Утвердить и начать', 3, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (17, 3, 3, 8, 'Отклонить', 4, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (18, 3, 4, 7, 'Выполнить', 5, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (19, 3, 7, 8, 'Закрыть', 6, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (10, 2, NULL, 2, 'Зарегистрировать', 1, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 19:13:39.813152+03');
INSERT INTO public.workflow_transitions (id, workflow_id, source_status_id, target_status_id, action_label, sort_order, is_active, created_at, updated_at) VALUES (11, 2, 2, 4, 'Начать расследование', 2, true, '2026-02-21 17:15:48.025625+03', '2026-02-21 19:13:39.835723+03');


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.workflows (id, name, description, is_active, created_at, updated_at) VALUES (2, 'Incident Workflow', 'Линейный процесс обработки инцидентов', true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflows (id, name, description, is_active, created_at, updated_at) VALUES (3, 'Change Request Workflow', 'Процесс согласования изменений', true, '2026-02-21 17:15:48.025625+03', '2026-02-21 17:15:48.025625+03');
INSERT INTO public.workflows (id, name, description, is_active, created_at, updated_at) VALUES (1, 'Bug Workflow', 'Жизненный цикл багов с возможностью возврата на доработку', false, '2026-02-21 17:15:48.025625+03', '2026-02-21 20:52:59.823826+03');


--
-- Name: acl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acl_id_seq', 1, false);


--
-- Name: acls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acls_id_seq', 1, false);


--
-- Name: admin_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_notification_id_seq', 1, true);


--
-- Name: admin_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_notifications_id_seq', 1, false);


--
-- Name: agents_groups_agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_groups_agents_id_seq', 459, true);


--
-- Name: agents_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_groups_id_seq', 79, true);


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_id_seq', 52, true);


--
-- Name: agents_queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_queues_id_seq', 1, false);


--
-- Name: agents_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agents_roles_id_seq', 1, false);


--
-- Name: appointment_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointment_notifications_id_seq', 1, false);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attachments_id_seq', 8, true);


--
-- Name: auto_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auto_responses_id_seq', 1, false);


--
-- Name: calendar_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calendar_events_id_seq', 577, true);


--
-- Name: calendars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calendars_id_seq', 4, true);


--
-- Name: communication_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.communication_log_id_seq', 1, false);


--
-- Name: communication_notifications_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.communication_notifications_settings_id_seq', 1, false);


--
-- Name: customer_users_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_users_customers_id_seq', 1, false);


--
-- Name: customer_users_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_users_groups_id_seq', 1, false);


--
-- Name: customer_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_users_id_seq', 103, true);


--
-- Name: customer_users_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_users_services_id_seq', 1, false);


--
-- Name: customers_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_groups_id_seq', 8, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_id_seq', 5, true);


--
-- Name: customers_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_services_id_seq', 38, true);


--
-- Name: dynamic_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dynamic_fields_id_seq', 1, false);


--
-- Name: dynamic_fields_screens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dynamic_fields_screens_id_seq', 1, false);


--
-- Name: dynamicfields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dynamicfields_id_seq', 1, false);


--
-- Name: email_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_addresses_id_seq', 2, true);


--
-- Name: general_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.general_catalog_id_seq', 1, true);


--
-- Name: generic_agent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.generic_agent_id_seq', 1, false);


--
-- Name: greetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.greetings_id_seq', 8, true);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: oauth2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth2_id_seq', 1, false);


--
-- Name: package_manager_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.package_manager_id_seq', 1, true);


--
-- Name: performance_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.performance_log_id_seq', 1, true);


--
-- Name: pgp_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pgp_keys_id_seq', 1, false);


--
-- Name: post_master_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_master_filters_id_seq', 1, false);


--
-- Name: post_master_mail_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_master_mail_accounts_id_seq', 34, true);


--
-- Name: priorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.priorities_id_seq', 14, true);


--
-- Name: process_management_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.process_management_id_seq', 1, false);


--
-- Name: processes_automation_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.processes_automation_settings_id_seq', 1, false);


--
-- Name: queue_auto_response_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.queue_auto_response_id_seq', 1, false);


--
-- Name: queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.queues_id_seq', 9, true);


--
-- Name: roles_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_groups_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 8, true);


--
-- Name: service_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_attachments_id_seq', 3, true);


--
-- Name: services_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_attachments_id_seq', 5, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.services_id_seq', 36, true);


--
-- Name: session_management_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.session_management_id_seq', 1, false);


--
-- Name: signatures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.signatures_id_seq', 8, true);


--
-- Name: sla_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sla_id_seq', 7, true);


--
-- Name: sla_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sla_services_id_seq', 7, true);


--
-- Name: smime_certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.smime_certificates_id_seq', 1, false);


--
-- Name: sql_box_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sql_box_id_seq', 1, false);


--
-- Name: state_transitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.state_transitions_id_seq', 2, true);


--
-- Name: states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.states_id_seq', 13, true);


--
-- Name: support_data_collector_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_data_collector_id_seq', 1, false);


--
-- Name: system_configuration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_configuration_id_seq', 1, false);


--
-- Name: system_file_support_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_file_support_id_seq', 1, false);


--
-- Name: system_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_log_id_seq', 1, false);


--
-- Name: system_maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_maintenance_id_seq', 1, false);


--
-- Name: template_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.template_attachments_id_seq', 1, true);


--
-- Name: template_queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.template_queues_id_seq', 1, false);


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.templates_id_seq', 4, true);


--
-- Name: test_entities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_entities_id_seq', 1, false);


--
-- Name: ticket_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_attachments_id_seq', 5, true);


--
-- Name: ticket_attribute_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_attribute_relations_id_seq', 1, false);


--
-- Name: ticket_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_comments_id_seq', 9, true);


--
-- Name: ticket_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_history_id_seq', 37, true);


--
-- Name: ticket_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_notifications_id_seq', 1, false);


--
-- Name: ticket_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_number_seq', 1000022, true);


--
-- Name: ticket_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_status_history_id_seq', 8, true);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tickets_id_seq', 31, true);


--
-- Name: translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.translation_id_seq', 1, false);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.types_id_seq', 11, true);


--
-- Name: users_groups_roles_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_groups_roles_settings_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: web_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.web_services_id_seq', 1, false);


--
-- Name: workflow_transitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workflow_transitions_id_seq', 21, true);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workflows_id_seq', 3, true);


--
-- Name: acl acl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acl
    ADD CONSTRAINT acl_pkey PRIMARY KEY (id);


--
-- Name: acls acls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acls
    ADD CONSTRAINT acls_pkey PRIMARY KEY (id);


--
-- Name: admin_notification admin_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_notification
    ADD CONSTRAINT admin_notification_pkey PRIMARY KEY (id);


--
-- Name: admin_notifications admin_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_notifications
    ADD CONSTRAINT admin_notifications_pkey PRIMARY KEY (id);


--
-- Name: agents agents_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_email_key UNIQUE (email);


--
-- Name: agents_groups_agents agents_groups_agents_agents_group_id_agent_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_agents
    ADD CONSTRAINT agents_groups_agents_agents_group_id_agent_id_key UNIQUE (agents_group_id, agent_id);


--
-- Name: agents_groups_agents agents_groups_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_agents
    ADD CONSTRAINT agents_groups_agents_pkey PRIMARY KEY (id);


--
-- Name: agents_groups agents_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups
    ADD CONSTRAINT agents_groups_pkey PRIMARY KEY (id);


--
-- Name: agents agents_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_login_key UNIQUE (login);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: agents_queues agents_queues_agent_id_queue_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_queues
    ADD CONSTRAINT agents_queues_agent_id_queue_id_key UNIQUE (agent_id, queue_id);


--
-- Name: agents_queues agents_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_queues
    ADD CONSTRAINT agents_queues_pkey PRIMARY KEY (id);


--
-- Name: agents_roles agents_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_roles
    ADD CONSTRAINT agents_roles_pkey PRIMARY KEY (id);


--
-- Name: appointment_notifications appointment_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment_notifications
    ADD CONSTRAINT appointment_notifications_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: auto_responses auto_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auto_responses
    ADD CONSTRAINT auto_responses_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: calendars calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendars
    ADD CONSTRAINT calendars_pkey PRIMARY KEY (id);


--
-- Name: communication_log communication_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_log
    ADD CONSTRAINT communication_log_pkey PRIMARY KEY (id);


--
-- Name: communication_notifications_settings communication_notifications_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_notifications_settings
    ADD CONSTRAINT communication_notifications_settings_pkey PRIMARY KEY (id);


--
-- Name: customer_users_customers customer_users_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_customers
    ADD CONSTRAINT customer_users_customers_pkey PRIMARY KEY (id);


--
-- Name: customer_users customer_users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_email_key UNIQUE (email);


--
-- Name: customer_users_groups customer_users_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_groups
    ADD CONSTRAINT customer_users_groups_pkey PRIMARY KEY (id);


--
-- Name: customer_users customer_users_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_login_key UNIQUE (login);


--
-- Name: customer_users customer_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_pkey PRIMARY KEY (id);


--
-- Name: customer_users_services customer_users_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users_services
    ADD CONSTRAINT customer_users_services_pkey PRIMARY KEY (id);


--
-- Name: customers_groups customers_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_groups
    ADD CONSTRAINT customers_groups_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers_services customers_services_customer_id_service_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_services
    ADD CONSTRAINT customers_services_customer_id_service_id_key UNIQUE (customer_id, service_id);


--
-- Name: customers_services customers_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_services
    ADD CONSTRAINT customers_services_pkey PRIMARY KEY (id);


--
-- Name: dynamic_fields dynamic_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_fields
    ADD CONSTRAINT dynamic_fields_pkey PRIMARY KEY (id);


--
-- Name: dynamic_fields_screens dynamic_fields_screens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_fields_screens
    ADD CONSTRAINT dynamic_fields_screens_pkey PRIMARY KEY (id);


--
-- Name: dynamicfields dynamicfields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamicfields
    ADD CONSTRAINT dynamicfields_pkey PRIMARY KEY (id);


--
-- Name: email_addresses email_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_addresses
    ADD CONSTRAINT email_addresses_pkey PRIMARY KEY (id);


--
-- Name: general_catalog general_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.general_catalog
    ADD CONSTRAINT general_catalog_pkey PRIMARY KEY (id);


--
-- Name: generic_agent generic_agent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generic_agent
    ADD CONSTRAINT generic_agent_pkey PRIMARY KEY (id);


--
-- Name: greetings greetings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.greetings
    ADD CONSTRAINT greetings_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: oauth2 oauth2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth2
    ADD CONSTRAINT oauth2_pkey PRIMARY KEY (id);


--
-- Name: package_manager package_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package_manager
    ADD CONSTRAINT package_manager_pkey PRIMARY KEY (id);


--
-- Name: performance_log performance_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.performance_log
    ADD CONSTRAINT performance_log_pkey PRIMARY KEY (id);


--
-- Name: pgp_keys pgp_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pgp_keys
    ADD CONSTRAINT pgp_keys_pkey PRIMARY KEY (id);


--
-- Name: post_master_filters post_master_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_filters
    ADD CONSTRAINT post_master_filters_pkey PRIMARY KEY (id);


--
-- Name: post_master_mail_accounts post_master_mail_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_mail_accounts
    ADD CONSTRAINT post_master_mail_accounts_pkey PRIMARY KEY (id);


--
-- Name: priorities priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT priorities_pkey PRIMARY KEY (id);


--
-- Name: process_management process_management_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.process_management
    ADD CONSTRAINT process_management_pkey PRIMARY KEY (id);


--
-- Name: processes_automation_settings processes_automation_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processes_automation_settings
    ADD CONSTRAINT processes_automation_settings_pkey PRIMARY KEY (id);


--
-- Name: queue_auto_response queue_auto_response_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queue_auto_response
    ADD CONSTRAINT queue_auto_response_pkey PRIMARY KEY (id);


--
-- Name: queues queues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_pkey PRIMARY KEY (id);


--
-- Name: roles_groups roles_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles_groups
    ADD CONSTRAINT roles_groups_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: service_attachments service_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_attachments
    ADD CONSTRAINT service_attachments_pkey PRIMARY KEY (id);


--
-- Name: services_attachments services_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services_attachments
    ADD CONSTRAINT services_attachments_pkey PRIMARY KEY (id);


--
-- Name: services_attachments services_attachments_service_id_attachment_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services_attachments
    ADD CONSTRAINT services_attachments_service_id_attachment_id_key UNIQUE (service_id, attachment_id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: session_management session_management_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session_management
    ADD CONSTRAINT session_management_pkey PRIMARY KEY (id);


--
-- Name: signatures signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signatures
    ADD CONSTRAINT signatures_pkey PRIMARY KEY (id);


--
-- Name: sla sla_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla
    ADD CONSTRAINT sla_pkey PRIMARY KEY (id);


--
-- Name: sla_services sla_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla_services
    ADD CONSTRAINT sla_services_pkey PRIMARY KEY (id);


--
-- Name: sla_services sla_services_sla_id_service_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla_services
    ADD CONSTRAINT sla_services_sla_id_service_id_key UNIQUE (sla_id, service_id);


--
-- Name: smime_certificates smime_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smime_certificates
    ADD CONSTRAINT smime_certificates_pkey PRIMARY KEY (id);


--
-- Name: sql_box sql_box_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sql_box
    ADD CONSTRAINT sql_box_pkey PRIMARY KEY (id);


--
-- Name: state_transitions state_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state_transitions
    ADD CONSTRAINT state_transitions_pkey PRIMARY KEY (id);


--
-- Name: states states_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.states
    ADD CONSTRAINT states_pkey PRIMARY KEY (id);


--
-- Name: support_data_collector support_data_collector_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_data_collector
    ADD CONSTRAINT support_data_collector_pkey PRIMARY KEY (id);


--
-- Name: system_configuration system_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_configuration
    ADD CONSTRAINT system_configuration_pkey PRIMARY KEY (id);


--
-- Name: system_file_support system_file_support_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_file_support
    ADD CONSTRAINT system_file_support_pkey PRIMARY KEY (id);


--
-- Name: system_log system_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_log
    ADD CONSTRAINT system_log_pkey PRIMARY KEY (id);


--
-- Name: system_maintenance system_maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_maintenance
    ADD CONSTRAINT system_maintenance_pkey PRIMARY KEY (id);


--
-- Name: template_attachments template_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_attachments
    ADD CONSTRAINT template_attachments_pkey PRIMARY KEY (id);


--
-- Name: template_queues template_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_queues
    ADD CONSTRAINT template_queues_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: test_entities test_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_entities
    ADD CONSTRAINT test_entities_pkey PRIMARY KEY (id);


--
-- Name: ticket_attachments ticket_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attachments
    ADD CONSTRAINT ticket_attachments_pkey PRIMARY KEY (id);


--
-- Name: ticket_attribute_relations ticket_attribute_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attribute_relations
    ADD CONSTRAINT ticket_attribute_relations_pkey PRIMARY KEY (id);


--
-- Name: ticket_comments ticket_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_pkey PRIMARY KEY (id);


--
-- Name: ticket_history ticket_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_pkey PRIMARY KEY (id);


--
-- Name: ticket_notifications ticket_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_notifications
    ADD CONSTRAINT ticket_notifications_pkey PRIMARY KEY (id);


--
-- Name: ticket_status_history ticket_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_ticket_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_ticket_number_key UNIQUE (ticket_number);


--
-- Name: translation translation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.translation
    ADD CONSTRAINT translation_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: workflow_transitions unique_transition; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_transitions
    ADD CONSTRAINT unique_transition UNIQUE (workflow_id, source_status_id, target_status_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users_groups_roles_settings users_groups_roles_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_groups_roles_settings
    ADD CONSTRAINT users_groups_roles_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_login_key UNIQUE (login);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: web_services web_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_services
    ADD CONSTRAINT web_services_pkey PRIMARY KEY (id);


--
-- Name: workflow_transitions workflow_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_transitions
    ADD CONSTRAINT workflow_transitions_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_acl_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acl_is_active ON public.acl USING btree (is_active);


--
-- Name: idx_acl_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acl_name ON public.acl USING btree (name);


--
-- Name: idx_acls_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acls_is_active ON public.acls USING btree (is_active);


--
-- Name: idx_acls_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acls_name ON public.acls USING btree (name);


--
-- Name: idx_admin_notification_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admin_notification_is_active ON public.admin_notification USING btree (is_active);


--
-- Name: idx_admin_notification_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admin_notification_name ON public.admin_notification USING btree (name);


--
-- Name: idx_admin_notifications_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admin_notifications_is_active ON public.admin_notifications USING btree (is_active);


--
-- Name: idx_admin_notifications_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admin_notifications_name ON public.admin_notifications USING btree (name);


--
-- Name: idx_agents_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_email ON public.agents USING btree (email);


--
-- Name: idx_agents_groups_agents_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_groups_agents_agent_id ON public.agents_groups_agents USING btree (agent_id);


--
-- Name: idx_agents_groups_agents_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_groups_agents_group_id ON public.agents_groups_agents USING btree (agents_group_id);


--
-- Name: idx_agents_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_groups_is_active ON public.agents_groups USING btree (is_active);


--
-- Name: idx_agents_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_groups_name ON public.agents_groups USING btree (name);


--
-- Name: idx_agents_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_is_active ON public.agents USING btree (is_active);


--
-- Name: idx_agents_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_login ON public.agents USING btree (login);


--
-- Name: idx_agents_queues_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_queues_agent_id ON public.agents_queues USING btree (agent_id);


--
-- Name: idx_agents_queues_queue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_queues_queue_id ON public.agents_queues USING btree (queue_id);


--
-- Name: idx_agents_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_role_id ON public.agents USING btree (role_id);


--
-- Name: idx_agents_roles_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_roles_is_active ON public.agents_roles USING btree (is_active);


--
-- Name: idx_agents_roles_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_roles_name ON public.agents_roles USING btree (name);


--
-- Name: idx_appointment_notifications_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointment_notifications_is_active ON public.appointment_notifications USING btree (is_active);


--
-- Name: idx_appointment_notifications_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_appointment_notifications_name ON public.appointment_notifications USING btree (name);


--
-- Name: idx_attachments_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attachments_is_active ON public.attachments USING btree (is_active);


--
-- Name: idx_attachments_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attachments_name ON public.attachments USING btree (name);


--
-- Name: idx_auto_responses_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auto_responses_is_active ON public.auto_responses USING btree (is_active);


--
-- Name: idx_auto_responses_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auto_responses_name ON public.auto_responses USING btree (name);


--
-- Name: idx_calendar_events_calendar_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendar_events_calendar_id ON public.calendar_events USING btree (calendar_id);


--
-- Name: idx_calendar_events_event_end; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendar_events_event_end ON public.calendar_events USING btree (event_end);


--
-- Name: idx_calendar_events_start; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendar_events_start ON public.calendar_events USING btree (start);


--
-- Name: idx_calendars_color; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_color ON public.calendars USING btree (color);


--
-- Name: idx_calendars_date_from; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_date_from ON public.calendars USING btree (date_from);


--
-- Name: idx_calendars_date_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_date_to ON public.calendars USING btree (date_to);


--
-- Name: idx_calendars_include_weekends; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_include_weekends ON public.calendars USING btree (include_weekends);


--
-- Name: idx_calendars_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_is_active ON public.calendars USING btree (is_active);


--
-- Name: idx_calendars_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_name ON public.calendars USING btree (name);


--
-- Name: idx_calendars_work_days_per_week; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_work_days_per_week ON public.calendars USING btree (work_days_per_week);


--
-- Name: idx_calendars_work_hours_from; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_work_hours_from ON public.calendars USING btree (work_hours_from);


--
-- Name: idx_calendars_work_hours_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_calendars_work_hours_to ON public.calendars USING btree (work_hours_to);


--
-- Name: idx_communication_log_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_log_is_active ON public.communication_log USING btree (is_active);


--
-- Name: idx_communication_log_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_log_name ON public.communication_log USING btree (name);


--
-- Name: idx_communication_notifications_settings_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_notifications_settings_is_active ON public.communication_notifications_settings USING btree (is_active);


--
-- Name: idx_communication_notifications_settings_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_notifications_settings_name ON public.communication_notifications_settings USING btree (name);


--
-- Name: idx_customer_users_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_customer_id ON public.customer_users USING btree (customer_id);


--
-- Name: idx_customer_users_customers_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_customers_group_id ON public.customer_users USING btree (customers_group_id);


--
-- Name: idx_customer_users_customers_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_customers_is_active ON public.customer_users_customers USING btree (is_active);


--
-- Name: idx_customer_users_customers_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_customers_name ON public.customer_users_customers USING btree (name);


--
-- Name: idx_customer_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_email ON public.customer_users USING btree (email);


--
-- Name: idx_customer_users_first_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_first_name ON public.customer_users USING btree (first_name);


--
-- Name: idx_customer_users_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_groups_is_active ON public.customer_users_groups USING btree (is_active);


--
-- Name: idx_customer_users_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_groups_name ON public.customer_users_groups USING btree (name);


--
-- Name: idx_customer_users_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_is_active ON public.customer_users USING btree (is_active);


--
-- Name: idx_customer_users_last_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_last_name ON public.customer_users USING btree (last_name);


--
-- Name: idx_customer_users_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_login ON public.customer_users USING btree (login);


--
-- Name: idx_customer_users_services_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_services_is_active ON public.customer_users_services USING btree (is_active);


--
-- Name: idx_customer_users_services_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customer_users_services_name ON public.customer_users_services USING btree (name);


--
-- Name: idx_customers_groups_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_groups_customer_id ON public.customers_groups USING btree (customer_id);


--
-- Name: idx_customers_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_groups_is_active ON public.customers_groups USING btree (is_active);


--
-- Name: idx_customers_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_groups_name ON public.customers_groups USING btree (name);


--
-- Name: idx_customers_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_is_active ON public.customers USING btree (is_active);


--
-- Name: idx_customers_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_name ON public.customers USING btree (name);


--
-- Name: idx_customers_services_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_services_customer_id ON public.customers_services USING btree (customer_id);


--
-- Name: idx_customers_services_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_services_service_id ON public.customers_services USING btree (service_id);


--
-- Name: idx_dynamic_fields_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_fields_is_active ON public.dynamic_fields USING btree (is_active);


--
-- Name: idx_dynamic_fields_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_fields_name ON public.dynamic_fields USING btree (name);


--
-- Name: idx_dynamic_fields_screens_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_fields_screens_is_active ON public.dynamic_fields_screens USING btree (is_active);


--
-- Name: idx_dynamic_fields_screens_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_fields_screens_name ON public.dynamic_fields_screens USING btree (name);


--
-- Name: idx_email_addresses_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_addresses_is_active ON public.email_addresses USING btree (is_active);


--
-- Name: idx_email_addresses_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_addresses_name ON public.email_addresses USING btree (name);


--
-- Name: idx_email_addresses_queue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_email_addresses_queue_id ON public.email_addresses USING btree (queue_id);


--
-- Name: idx_general_catalog_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_general_catalog_is_active ON public.general_catalog USING btree (is_active);


--
-- Name: idx_general_catalog_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_general_catalog_name ON public.general_catalog USING btree (name);


--
-- Name: idx_generic_agent_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_generic_agent_is_active ON public.generic_agent USING btree (is_active);


--
-- Name: idx_generic_agent_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_generic_agent_name ON public.generic_agent USING btree (name);


--
-- Name: idx_greetings_content; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_greetings_content ON public.greetings USING btree (content);


--
-- Name: idx_greetings_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_greetings_is_active ON public.greetings USING btree (is_active);


--
-- Name: idx_greetings_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_greetings_name ON public.greetings USING btree (name);


--
-- Name: idx_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_groups_is_active ON public.groups USING btree (is_active);


--
-- Name: idx_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_groups_name ON public.groups USING btree (name);


--
-- Name: idx_oauth2_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_oauth2_is_active ON public.oauth2 USING btree (is_active);


--
-- Name: idx_oauth2_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_oauth2_name ON public.oauth2 USING btree (name);


--
-- Name: idx_package_manager_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_package_manager_is_active ON public.package_manager USING btree (is_active);


--
-- Name: idx_package_manager_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_package_manager_name ON public.package_manager USING btree (name);


--
-- Name: idx_performance_log_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_performance_log_is_active ON public.performance_log USING btree (is_active);


--
-- Name: idx_performance_log_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_performance_log_name ON public.performance_log USING btree (name);


--
-- Name: idx_pgp_keys_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pgp_keys_is_active ON public.pgp_keys USING btree (is_active);


--
-- Name: idx_pgp_keys_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pgp_keys_name ON public.pgp_keys USING btree (name);


--
-- Name: idx_post_master_filters_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_post_master_filters_is_active ON public.post_master_filters USING btree (is_active);


--
-- Name: idx_post_master_filters_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_post_master_filters_name ON public.post_master_filters USING btree (name);


--
-- Name: idx_post_master_mail_accounts_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_post_master_mail_accounts_is_active ON public.post_master_mail_accounts USING btree (is_active);


--
-- Name: idx_priorities_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_priorities_is_active ON public.priorities USING btree (is_active);


--
-- Name: idx_priorities_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_priorities_name ON public.priorities USING btree (name);


--
-- Name: idx_process_management_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_process_management_is_active ON public.process_management USING btree (is_active);


--
-- Name: idx_process_management_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_process_management_name ON public.process_management USING btree (name);


--
-- Name: idx_processes_automation_settings_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_processes_automation_settings_is_active ON public.processes_automation_settings USING btree (is_active);


--
-- Name: idx_processes_automation_settings_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_processes_automation_settings_name ON public.processes_automation_settings USING btree (name);


--
-- Name: idx_queue_auto_response_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queue_auto_response_is_active ON public.queue_auto_response USING btree (is_active);


--
-- Name: idx_queue_auto_response_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queue_auto_response_name ON public.queue_auto_response USING btree (name);


--
-- Name: idx_queues_agent_group; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_agent_group ON public.queues USING btree (agent_group_id);


--
-- Name: idx_queues_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_company ON public.queues USING btree (company_id);


--
-- Name: idx_queues_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_is_active ON public.queues USING btree (is_active);


--
-- Name: idx_queues_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_name ON public.queues USING btree (name);


--
-- Name: idx_queues_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_priority ON public.queues USING btree (priority_id);


--
-- Name: idx_queues_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_service ON public.queues USING btree (service_id);


--
-- Name: idx_queues_sla; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_sla ON public.queues USING btree (sla_id);


--
-- Name: idx_queues_template_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_template_id ON public.queues USING btree (template_id);


--
-- Name: idx_queues_workflow; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_queues_workflow ON public.queues USING btree (workflow_id);


--
-- Name: idx_roles_groups_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_roles_groups_is_active ON public.roles_groups USING btree (is_active);


--
-- Name: idx_roles_groups_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_roles_groups_name ON public.roles_groups USING btree (name);


--
-- Name: idx_roles_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_roles_is_active ON public.roles USING btree (is_active);


--
-- Name: idx_roles_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_roles_name ON public.roles USING btree (name);


--
-- Name: idx_service_attachments_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_attachments_service_id ON public.service_attachments USING btree (service_id);


--
-- Name: idx_service_attachments_uploaded_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_attachments_uploaded_by ON public.service_attachments USING btree (uploaded_by);


--
-- Name: idx_services_attachments_attachment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_attachments_attachment_id ON public.services_attachments USING btree (attachment_id);


--
-- Name: idx_services_attachments_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_attachments_service_id ON public.services_attachments USING btree (service_id);


--
-- Name: idx_services_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_is_active ON public.services USING btree (is_active);


--
-- Name: idx_services_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_name ON public.services USING btree (name);


--
-- Name: idx_services_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_type ON public.services USING btree (type);


--
-- Name: idx_session_management_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_management_is_active ON public.session_management USING btree (is_active);


--
-- Name: idx_signatures_comment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_signatures_comment ON public.signatures USING btree (comment);


--
-- Name: idx_signatures_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_signatures_is_active ON public.signatures USING btree (is_active);


--
-- Name: idx_signatures_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_signatures_name ON public.signatures USING btree (name);


--
-- Name: idx_sla_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sla_is_active ON public.sla USING btree (is_active);


--
-- Name: idx_sla_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sla_name ON public.sla USING btree (name);


--
-- Name: idx_sla_services_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sla_services_service_id ON public.sla_services USING btree (service_id);


--
-- Name: idx_sla_services_sla_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sla_services_sla_id ON public.sla_services USING btree (sla_id);


--
-- Name: idx_smime_certificates_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_smime_certificates_is_active ON public.smime_certificates USING btree (is_active);


--
-- Name: idx_smime_certificates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_smime_certificates_name ON public.smime_certificates USING btree (name);


--
-- Name: idx_sql_box_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sql_box_is_active ON public.sql_box USING btree (is_active);


--
-- Name: idx_sql_box_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sql_box_name ON public.sql_box USING btree (name);


--
-- Name: idx_state_transitions_from; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_state_transitions_from ON public.state_transitions USING btree (from_state_id);


--
-- Name: idx_state_transitions_from_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_state_transitions_from_state ON public.state_transitions USING btree (from_state_id);


--
-- Name: idx_state_transitions_to; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_state_transitions_to ON public.state_transitions USING btree (to_state_id);


--
-- Name: idx_state_transitions_to_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_state_transitions_to_state ON public.state_transitions USING btree (to_state_id);


--
-- Name: idx_state_transitions_type_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_state_transitions_type_id ON public.state_transitions USING btree (type_id);


--
-- Name: idx_states_color; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_states_color ON public.states USING btree (color);


--
-- Name: idx_states_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_states_is_active ON public.states USING btree (is_active);


--
-- Name: idx_states_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_states_name ON public.states USING btree (name);


--
-- Name: idx_states_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_states_type ON public.states USING btree (type);


--
-- Name: idx_states_type_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_states_type_id ON public.states USING btree (type_id);


--
-- Name: idx_support_data_collector_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_support_data_collector_is_active ON public.support_data_collector USING btree (is_active);


--
-- Name: idx_support_data_collector_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_support_data_collector_name ON public.support_data_collector USING btree (name);


--
-- Name: idx_system_configuration_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_configuration_is_active ON public.system_configuration USING btree (is_active);


--
-- Name: idx_system_configuration_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_configuration_name ON public.system_configuration USING btree (name);


--
-- Name: idx_system_file_support_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_file_support_is_active ON public.system_file_support USING btree (is_active);


--
-- Name: idx_system_file_support_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_file_support_name ON public.system_file_support USING btree (name);


--
-- Name: idx_system_log_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_log_is_active ON public.system_log USING btree (is_active);


--
-- Name: idx_system_log_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_log_name ON public.system_log USING btree (name);


--
-- Name: idx_system_maintenance_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_maintenance_is_active ON public.system_maintenance USING btree (is_active);


--
-- Name: idx_system_maintenance_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_maintenance_name ON public.system_maintenance USING btree (name);


--
-- Name: idx_template_attachments_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_template_attachments_is_active ON public.template_attachments USING btree (is_active);


--
-- Name: idx_template_attachments_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_template_attachments_name ON public.template_attachments USING btree (name);


--
-- Name: idx_template_queues_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_template_queues_is_active ON public.template_queues USING btree (is_active);


--
-- Name: idx_template_queues_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_template_queues_name ON public.template_queues USING btree (name);


--
-- Name: idx_templates_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_templates_is_active ON public.templates USING btree (is_active);


--
-- Name: idx_templates_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_templates_name ON public.templates USING btree (name);


--
-- Name: idx_test_entities_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_test_entities_is_active ON public.test_entities USING btree (is_active);


--
-- Name: idx_test_entities_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_test_entities_name ON public.test_entities USING btree (name);


--
-- Name: idx_ticket_attachments_ticket_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_attachments_ticket_id ON public.ticket_attachments USING btree (ticket_id);


--
-- Name: idx_ticket_attachments_uploaded_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_attachments_uploaded_by ON public.ticket_attachments USING btree (uploaded_by);


--
-- Name: idx_ticket_attribute_relations_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_attribute_relations_is_active ON public.ticket_attribute_relations USING btree (is_active);


--
-- Name: idx_ticket_attribute_relations_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_attribute_relations_name ON public.ticket_attribute_relations USING btree (name);


--
-- Name: idx_ticket_comments_author_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_comments_author_id ON public.ticket_comments USING btree (author_id);


--
-- Name: idx_ticket_comments_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_comments_created_at ON public.ticket_comments USING btree (created_at);


--
-- Name: idx_ticket_comments_is_internal; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_comments_is_internal ON public.ticket_comments USING btree (is_internal);


--
-- Name: idx_ticket_comments_ticket_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_comments_ticket_id ON public.ticket_comments USING btree (ticket_id);


--
-- Name: idx_ticket_history_changed_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_history_changed_by ON public.ticket_history USING btree (changed_by);


--
-- Name: idx_ticket_history_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_history_created_at ON public.ticket_history USING btree (created_at);


--
-- Name: idx_ticket_history_ticket_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_history_ticket_id ON public.ticket_history USING btree (ticket_id);


--
-- Name: idx_ticket_notifications_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_notifications_is_active ON public.ticket_notifications USING btree (is_active);


--
-- Name: idx_ticket_notifications_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_notifications_name ON public.ticket_notifications USING btree (name);


--
-- Name: idx_ticket_status_history_changed_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_status_history_changed_by ON public.ticket_status_history USING btree (changed_by);


--
-- Name: idx_ticket_status_history_ticket_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_status_history_ticket_id ON public.ticket_status_history USING btree (ticket_id);


--
-- Name: idx_ticket_status_history_to_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ticket_status_history_to_status_id ON public.ticket_status_history USING btree (to_status_id);


--
-- Name: idx_tickets_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_company_id ON public.tickets USING btree (company_id);


--
-- Name: idx_tickets_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_created_at ON public.tickets USING btree (created_at);


--
-- Name: idx_tickets_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_is_active ON public.tickets USING btree (is_active);


--
-- Name: idx_tickets_owner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_owner_id ON public.tickets USING btree (owner_id);


--
-- Name: idx_tickets_pending_start; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_pending_start ON public.tickets USING btree (pending_start_at);


--
-- Name: idx_tickets_priority_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_priority_id ON public.tickets USING btree (priority_id);


--
-- Name: idx_tickets_queue_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_queue_id ON public.tickets USING btree (queue_id);


--
-- Name: idx_tickets_resolution_deadline; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_resolution_deadline ON public.tickets USING btree (resolution_deadline);


--
-- Name: idx_tickets_response_deadline; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_response_deadline ON public.tickets USING btree (response_deadline);


--
-- Name: idx_tickets_sla_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_sla_id ON public.tickets USING btree (sla_id);


--
-- Name: idx_tickets_sla_violated; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_sla_violated ON public.tickets USING btree (sla_violated);


--
-- Name: idx_tickets_state_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_state_id ON public.tickets USING btree (state_id);


--
-- Name: idx_tickets_ticket_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_ticket_number ON public.tickets USING btree (ticket_number);


--
-- Name: idx_tickets_title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_title ON public.tickets USING btree (title);


--
-- Name: idx_tickets_type_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_type_id ON public.tickets USING btree (type_id);


--
-- Name: idx_translation_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_translation_is_active ON public.translation USING btree (is_active);


--
-- Name: idx_translation_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_translation_name ON public.translation USING btree (name);


--
-- Name: idx_types_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_types_is_active ON public.types USING btree (is_active);


--
-- Name: idx_types_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_types_name ON public.types USING btree (name);


--
-- Name: idx_types_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_types_workflow_id ON public.types USING btree (workflow_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_groups_roles_settings_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_groups_roles_settings_is_active ON public.users_groups_roles_settings USING btree (is_active);


--
-- Name: idx_users_groups_roles_settings_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_groups_roles_settings_name ON public.users_groups_roles_settings USING btree (name);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_login ON public.users USING btree (login);


--
-- Name: idx_web_services_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_web_services_is_active ON public.web_services USING btree (is_active);


--
-- Name: idx_web_services_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_web_services_name ON public.web_services USING btree (name);


--
-- Name: idx_workflow_transitions_source_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_transitions_source_status ON public.workflow_transitions USING btree (source_status_id);


--
-- Name: idx_workflow_transitions_target_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_transitions_target_status ON public.workflow_transitions USING btree (target_status_id);


--
-- Name: idx_workflow_transitions_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_transitions_workflow_id ON public.workflow_transitions USING btree (workflow_id);


--
-- Name: customers_services trigger_customers_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_customers_services_updated_at BEFORE UPDATE ON public.customers_services FOR EACH ROW EXECUTE FUNCTION public.update_customers_services_updated_at();


--
-- Name: services_attachments trigger_services_attachments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_services_attachments_updated_at BEFORE UPDATE ON public.services_attachments FOR EACH ROW EXECUTE FUNCTION public.update_services_attachments_updated_at();


--
-- Name: acl trigger_update_acl_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_acl_updated_at BEFORE UPDATE ON public.acl FOR EACH ROW EXECUTE FUNCTION public.update_acl_updated_at();


--
-- Name: acls trigger_update_acls_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_acls_updated_at BEFORE UPDATE ON public.acls FOR EACH ROW EXECUTE FUNCTION public.update_acls_updated_at();


--
-- Name: admin_notification trigger_update_admin_notification_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_admin_notification_updated_at BEFORE UPDATE ON public.admin_notification FOR EACH ROW EXECUTE FUNCTION public.update_admin_notification_updated_at();


--
-- Name: admin_notifications trigger_update_admin_notifications_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_admin_notifications_updated_at BEFORE UPDATE ON public.admin_notifications FOR EACH ROW EXECUTE FUNCTION public.update_admin_notifications_updated_at();


--
-- Name: agents_groups_agents trigger_update_agents_groups_agents_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_agents_groups_agents_updated_at BEFORE UPDATE ON public.agents_groups_agents FOR EACH ROW EXECUTE FUNCTION public.update_agents_groups_agents_updated_at();


--
-- Name: agents_groups trigger_update_agents_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_agents_groups_updated_at BEFORE UPDATE ON public.agents_groups FOR EACH ROW EXECUTE FUNCTION public.update_agents_groups_updated_at();


--
-- Name: agents_roles trigger_update_agents_roles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_agents_roles_updated_at BEFORE UPDATE ON public.agents_roles FOR EACH ROW EXECUTE FUNCTION public.update_agents_roles_updated_at();


--
-- Name: agents trigger_update_agents_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_agents_updated_at();


--
-- Name: appointment_notifications trigger_update_appointment_notifications_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_appointment_notifications_updated_at BEFORE UPDATE ON public.appointment_notifications FOR EACH ROW EXECUTE FUNCTION public.update_appointment_notifications_updated_at();


--
-- Name: attachments trigger_update_attachments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_attachments_updated_at BEFORE UPDATE ON public.attachments FOR EACH ROW EXECUTE FUNCTION public.update_attachments_updated_at();


--
-- Name: auto_responses trigger_update_auto_responses_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_auto_responses_updated_at BEFORE UPDATE ON public.auto_responses FOR EACH ROW EXECUTE FUNCTION public.update_auto_responses_updated_at();


--
-- Name: calendar_events trigger_update_calendar_events_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_calendar_events_updated_at BEFORE UPDATE ON public.calendar_events FOR EACH ROW EXECUTE FUNCTION public.update_calendar_events_updated_at();


--
-- Name: calendars trigger_update_calendars_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_calendars_updated_at BEFORE UPDATE ON public.calendars FOR EACH ROW EXECUTE FUNCTION public.update_calendars_updated_at();


--
-- Name: communication_log trigger_update_communication_log_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_communication_log_updated_at BEFORE UPDATE ON public.communication_log FOR EACH ROW EXECUTE FUNCTION public.update_communication_log_updated_at();


--
-- Name: communication_notifications_settings trigger_update_communication_notifications_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_communication_notifications_settings_updated_at BEFORE UPDATE ON public.communication_notifications_settings FOR EACH ROW EXECUTE FUNCTION public.update_communication_notifications_settings_updated_at();


--
-- Name: customer_users_customers trigger_update_customer_users_customers_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customer_users_customers_updated_at BEFORE UPDATE ON public.customer_users_customers FOR EACH ROW EXECUTE FUNCTION public.update_customer_users_customers_updated_at();


--
-- Name: customer_users_groups trigger_update_customer_users_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customer_users_groups_updated_at BEFORE UPDATE ON public.customer_users_groups FOR EACH ROW EXECUTE FUNCTION public.update_customer_users_groups_updated_at();


--
-- Name: customer_users_services trigger_update_customer_users_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customer_users_services_updated_at BEFORE UPDATE ON public.customer_users_services FOR EACH ROW EXECUTE FUNCTION public.update_customer_users_services_updated_at();


--
-- Name: customer_users trigger_update_customer_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customer_users_updated_at BEFORE UPDATE ON public.customer_users FOR EACH ROW EXECUTE FUNCTION public.update_customer_users_updated_at();


--
-- Name: customers_groups trigger_update_customers_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customers_groups_updated_at BEFORE UPDATE ON public.customers_groups FOR EACH ROW EXECUTE FUNCTION public.update_customers_groups_updated_at();


--
-- Name: customers trigger_update_customers_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_customers_updated_at();


--
-- Name: dynamic_fields_screens trigger_update_dynamic_fields_screens_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_dynamic_fields_screens_updated_at BEFORE UPDATE ON public.dynamic_fields_screens FOR EACH ROW EXECUTE FUNCTION public.update_dynamic_fields_screens_updated_at();


--
-- Name: dynamic_fields trigger_update_dynamic_fields_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_dynamic_fields_updated_at BEFORE UPDATE ON public.dynamic_fields FOR EACH ROW EXECUTE FUNCTION public.update_dynamic_fields_updated_at();


--
-- Name: email_addresses trigger_update_email_addresses_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_email_addresses_updated_at BEFORE UPDATE ON public.email_addresses FOR EACH ROW EXECUTE FUNCTION public.update_email_addresses_updated_at();


--
-- Name: general_catalog trigger_update_general_catalog_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_general_catalog_updated_at BEFORE UPDATE ON public.general_catalog FOR EACH ROW EXECUTE FUNCTION public.update_general_catalog_updated_at();


--
-- Name: generic_agent trigger_update_generic_agent_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_generic_agent_updated_at BEFORE UPDATE ON public.generic_agent FOR EACH ROW EXECUTE FUNCTION public.update_generic_agent_updated_at();


--
-- Name: greetings trigger_update_greetings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_greetings_updated_at BEFORE UPDATE ON public.greetings FOR EACH ROW EXECUTE FUNCTION public.update_greetings_updated_at();


--
-- Name: groups trigger_update_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_groups_updated_at BEFORE UPDATE ON public.groups FOR EACH ROW EXECUTE FUNCTION public.update_groups_updated_at();


--
-- Name: oauth2 trigger_update_oauth2_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_oauth2_updated_at BEFORE UPDATE ON public.oauth2 FOR EACH ROW EXECUTE FUNCTION public.update_oauth2_updated_at();


--
-- Name: package_manager trigger_update_package_manager_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_package_manager_updated_at BEFORE UPDATE ON public.package_manager FOR EACH ROW EXECUTE FUNCTION public.update_package_manager_updated_at();


--
-- Name: performance_log trigger_update_performance_log_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_performance_log_updated_at BEFORE UPDATE ON public.performance_log FOR EACH ROW EXECUTE FUNCTION public.update_performance_log_updated_at();


--
-- Name: pgp_keys trigger_update_pgp_keys_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_pgp_keys_updated_at BEFORE UPDATE ON public.pgp_keys FOR EACH ROW EXECUTE FUNCTION public.update_pgp_keys_updated_at();


--
-- Name: post_master_filters trigger_update_post_master_filters_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_post_master_filters_updated_at BEFORE UPDATE ON public.post_master_filters FOR EACH ROW EXECUTE FUNCTION public.update_post_master_filters_updated_at();


--
-- Name: post_master_mail_accounts trigger_update_post_master_mail_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_post_master_mail_accounts_updated_at BEFORE UPDATE ON public.post_master_mail_accounts FOR EACH ROW EXECUTE FUNCTION public.update_post_master_mail_accounts_updated_at();


--
-- Name: priorities trigger_update_priorities_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_priorities_updated_at BEFORE UPDATE ON public.priorities FOR EACH ROW EXECUTE FUNCTION public.update_priorities_updated_at();


--
-- Name: process_management trigger_update_process_management_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_process_management_updated_at BEFORE UPDATE ON public.process_management FOR EACH ROW EXECUTE FUNCTION public.update_process_management_updated_at();


--
-- Name: processes_automation_settings trigger_update_processes_automation_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_processes_automation_settings_updated_at BEFORE UPDATE ON public.processes_automation_settings FOR EACH ROW EXECUTE FUNCTION public.update_processes_automation_settings_updated_at();


--
-- Name: queue_auto_response trigger_update_queue_auto_response_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_queue_auto_response_updated_at BEFORE UPDATE ON public.queue_auto_response FOR EACH ROW EXECUTE FUNCTION public.update_queue_auto_response_updated_at();


--
-- Name: queues trigger_update_queues_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_queues_updated_at BEFORE UPDATE ON public.queues FOR EACH ROW EXECUTE FUNCTION public.update_queues_updated_at();


--
-- Name: roles_groups trigger_update_roles_groups_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_roles_groups_updated_at BEFORE UPDATE ON public.roles_groups FOR EACH ROW EXECUTE FUNCTION public.update_roles_groups_updated_at();


--
-- Name: roles trigger_update_roles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_roles_updated_at BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.update_roles_updated_at();


--
-- Name: services trigger_update_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_services_updated_at();


--
-- Name: session_management trigger_update_session_management_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_session_management_updated_at BEFORE UPDATE ON public.session_management FOR EACH ROW EXECUTE FUNCTION public.update_session_management_updated_at();


--
-- Name: signatures trigger_update_signatures_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_signatures_updated_at BEFORE UPDATE ON public.signatures FOR EACH ROW EXECUTE FUNCTION public.update_signatures_updated_at();


--
-- Name: sla_services trigger_update_sla_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_sla_services_updated_at BEFORE UPDATE ON public.sla_services FOR EACH ROW EXECUTE FUNCTION public.update_sla_services_updated_at();


--
-- Name: sla trigger_update_sla_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_sla_updated_at BEFORE UPDATE ON public.sla FOR EACH ROW EXECUTE FUNCTION public.update_sla_updated_at();


--
-- Name: smime_certificates trigger_update_smime_certificates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_smime_certificates_updated_at BEFORE UPDATE ON public.smime_certificates FOR EACH ROW EXECUTE FUNCTION public.update_smime_certificates_updated_at();


--
-- Name: sql_box trigger_update_sql_box_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_sql_box_updated_at BEFORE UPDATE ON public.sql_box FOR EACH ROW EXECUTE FUNCTION public.update_sql_box_updated_at();


--
-- Name: states trigger_update_states_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_states_updated_at BEFORE UPDATE ON public.states FOR EACH ROW EXECUTE FUNCTION public.update_states_updated_at();


--
-- Name: support_data_collector trigger_update_support_data_collector_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_support_data_collector_updated_at BEFORE UPDATE ON public.support_data_collector FOR EACH ROW EXECUTE FUNCTION public.update_support_data_collector_updated_at();


--
-- Name: system_configuration trigger_update_system_configuration_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_system_configuration_updated_at BEFORE UPDATE ON public.system_configuration FOR EACH ROW EXECUTE FUNCTION public.update_system_configuration_updated_at();


--
-- Name: system_file_support trigger_update_system_file_support_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_system_file_support_updated_at BEFORE UPDATE ON public.system_file_support FOR EACH ROW EXECUTE FUNCTION public.update_system_file_support_updated_at();


--
-- Name: system_log trigger_update_system_log_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_system_log_updated_at BEFORE UPDATE ON public.system_log FOR EACH ROW EXECUTE FUNCTION public.update_system_log_updated_at();


--
-- Name: system_maintenance trigger_update_system_maintenance_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_system_maintenance_updated_at BEFORE UPDATE ON public.system_maintenance FOR EACH ROW EXECUTE FUNCTION public.update_system_maintenance_updated_at();


--
-- Name: template_attachments trigger_update_template_attachments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_template_attachments_updated_at BEFORE UPDATE ON public.template_attachments FOR EACH ROW EXECUTE FUNCTION public.update_template_attachments_updated_at();


--
-- Name: template_queues trigger_update_template_queues_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_template_queues_updated_at BEFORE UPDATE ON public.template_queues FOR EACH ROW EXECUTE FUNCTION public.update_template_queues_updated_at();


--
-- Name: templates trigger_update_templates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_templates_updated_at BEFORE UPDATE ON public.templates FOR EACH ROW EXECUTE FUNCTION public.update_templates_updated_at();


--
-- Name: test_entities trigger_update_test_entities_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_test_entities_updated_at BEFORE UPDATE ON public.test_entities FOR EACH ROW EXECUTE FUNCTION public.update_test_entities_updated_at();


--
-- Name: ticket_attribute_relations trigger_update_ticket_attribute_relations_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_ticket_attribute_relations_updated_at BEFORE UPDATE ON public.ticket_attribute_relations FOR EACH ROW EXECUTE FUNCTION public.update_ticket_attribute_relations_updated_at();


--
-- Name: ticket_notifications trigger_update_ticket_notifications_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_ticket_notifications_updated_at BEFORE UPDATE ON public.ticket_notifications FOR EACH ROW EXECUTE FUNCTION public.update_ticket_notifications_updated_at();


--
-- Name: translation trigger_update_translation_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_translation_updated_at BEFORE UPDATE ON public.translation FOR EACH ROW EXECUTE FUNCTION public.update_translation_updated_at();


--
-- Name: types trigger_update_types_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_types_updated_at BEFORE UPDATE ON public.types FOR EACH ROW EXECUTE FUNCTION public.update_types_updated_at();


--
-- Name: users_groups_roles_settings trigger_update_users_groups_roles_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_users_groups_roles_settings_updated_at BEFORE UPDATE ON public.users_groups_roles_settings FOR EACH ROW EXECUTE FUNCTION public.update_users_groups_roles_settings_updated_at();


--
-- Name: web_services trigger_update_web_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_web_services_updated_at BEFORE UPDATE ON public.web_services FOR EACH ROW EXECUTE FUNCTION public.update_web_services_updated_at();


--
-- Name: workflow_transitions update_workflow_transitions_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_workflow_transitions_updated_at BEFORE UPDATE ON public.workflow_transitions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: workflows update_workflows_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_workflows_updated_at BEFORE UPDATE ON public.workflows FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agents_groups_agents agents_groups_agents_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_agents
    ADD CONSTRAINT agents_groups_agents_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agents_groups_agents agents_groups_agents_agents_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_groups_agents
    ADD CONSTRAINT agents_groups_agents_agents_group_id_fkey FOREIGN KEY (agents_group_id) REFERENCES public.agents_groups(id) ON DELETE CASCADE;


--
-- Name: agents_queues agents_queues_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_queues
    ADD CONSTRAINT agents_queues_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agents_queues agents_queues_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents_queues
    ADD CONSTRAINT agents_queues_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.queues(id) ON DELETE CASCADE;


--
-- Name: agents agents_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: calendar_events calendar_events_calendar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_calendar_id_fkey FOREIGN KEY (calendar_id) REFERENCES public.calendars(id) ON DELETE CASCADE;


--
-- Name: customer_users customer_users_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: customer_users customer_users_customers_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_users
    ADD CONSTRAINT customer_users_customers_group_id_fkey FOREIGN KEY (customers_group_id) REFERENCES public.customers_groups(id) ON DELETE SET NULL;


--
-- Name: customers_groups customers_groups_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_groups
    ADD CONSTRAINT customers_groups_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: customers_services customers_services_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_services
    ADD CONSTRAINT customers_services_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customers_services customers_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers_services
    ADD CONSTRAINT customers_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: email_addresses email_addresses_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_addresses
    ADD CONSTRAINT email_addresses_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.queues(id) ON DELETE SET NULL;


--
-- Name: post_master_mail_accounts post_master_mail_accounts_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_master_mail_accounts
    ADD CONSTRAINT post_master_mail_accounts_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.queues(id) ON DELETE SET NULL;


--
-- Name: queues queues_agent_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_agent_group_id_fkey FOREIGN KEY (agent_group_id) REFERENCES public.agents_groups(id);


--
-- Name: queues queues_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.customers(id);


--
-- Name: queues queues_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.priorities(id);


--
-- Name: queues queues_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: queues queues_sla_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_sla_id_fkey FOREIGN KEY (sla_id) REFERENCES public.sla(id);


--
-- Name: queues queues_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.templates(id) ON DELETE SET NULL;


--
-- Name: queues queues_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- Name: service_attachments service_attachments_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_attachments
    ADD CONSTRAINT service_attachments_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: services_attachments services_attachments_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services_attachments
    ADD CONSTRAINT services_attachments_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.attachments(id) ON DELETE CASCADE;


--
-- Name: services_attachments services_attachments_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services_attachments
    ADD CONSTRAINT services_attachments_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: services services_sla_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_sla_id_fkey FOREIGN KEY (sla_id) REFERENCES public.sla(id);


--
-- Name: sla sla_calendar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla
    ADD CONSTRAINT sla_calendar_id_fkey FOREIGN KEY (calendar_id) REFERENCES public.calendars(id);


--
-- Name: sla_services sla_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla_services
    ADD CONSTRAINT sla_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: sla_services sla_services_sla_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sla_services
    ADD CONSTRAINT sla_services_sla_id_fkey FOREIGN KEY (sla_id) REFERENCES public.sla(id) ON DELETE CASCADE;


--
-- Name: state_transitions state_transitions_from_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state_transitions
    ADD CONSTRAINT state_transitions_from_state_id_fkey FOREIGN KEY (from_state_id) REFERENCES public.states(id) ON DELETE CASCADE;


--
-- Name: state_transitions state_transitions_to_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state_transitions
    ADD CONSTRAINT state_transitions_to_state_id_fkey FOREIGN KEY (to_state_id) REFERENCES public.states(id) ON DELETE CASCADE;


--
-- Name: state_transitions state_transitions_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state_transitions
    ADD CONSTRAINT state_transitions_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.types(id) ON DELETE CASCADE;


--
-- Name: states states_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.states
    ADD CONSTRAINT states_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.types(id) ON DELETE SET NULL;


--
-- Name: ticket_attachments ticket_attachments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attachments
    ADD CONSTRAINT ticket_attachments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_attachments ticket_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_attachments
    ADD CONSTRAINT ticket_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: ticket_comments ticket_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: ticket_comments ticket_comments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_history ticket_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: ticket_history ticket_history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_status_history ticket_status_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: ticket_status_history ticket_status_history_from_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_from_status_id_fkey FOREIGN KEY (from_status_id) REFERENCES public.states(id) ON DELETE SET NULL;


--
-- Name: ticket_status_history ticket_status_history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_status_history ticket_status_history_to_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_to_status_id_fkey FOREIGN KEY (to_status_id) REFERENCES public.states(id) ON DELETE SET NULL;


--
-- Name: ticket_status_history ticket_status_history_transition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_status_history
    ADD CONSTRAINT ticket_status_history_transition_id_fkey FOREIGN KEY (transition_id) REFERENCES public.workflow_transitions(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.priorities(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.queues(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: tickets tickets_sla_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_sla_id_fkey FOREIGN KEY (sla_id) REFERENCES public.sla(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_state_id_fkey FOREIGN KEY (state_id) REFERENCES public.states(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.types(id) ON DELETE SET NULL;


--
-- Name: types types_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE SET NULL;


--
-- Name: workflow_transitions workflow_transitions_source_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_transitions
    ADD CONSTRAINT workflow_transitions_source_status_id_fkey FOREIGN KEY (source_status_id) REFERENCES public.states(id) ON DELETE CASCADE;


--
-- Name: workflow_transitions workflow_transitions_target_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_transitions
    ADD CONSTRAINT workflow_transitions_target_status_id_fkey FOREIGN KEY (target_status_id) REFERENCES public.states(id) ON DELETE CASCADE;


--
-- Name: workflow_transitions workflow_transitions_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_transitions
    ADD CONSTRAINT workflow_transitions_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict gg3LptHnxWywPbFVaej3EEFtuhTqzopBEXhJnuXQI4cn8ef1aBtsoe5FZASxtXx

